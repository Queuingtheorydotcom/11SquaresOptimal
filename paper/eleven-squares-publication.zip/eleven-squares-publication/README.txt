Eleven squares: revised proof and reproducible verification

The manuscript is paper/eleven-squares-synthesis.tex. This package contains
displayed mathematical proofs, exact Python checkers, and their required
certificate inputs. No saved run outputs, conversation transcripts, private
audit receipts, or execution logs are supplied. Tested with CPython 3.12.4,
using only its standard library; no network, Lean, solver, or download is
needed. The optional geometric foundations are in
paper/eleven-squares-geometric-foundations.tex.

  python3 verify.py --check-inputs
  python3 verify.py --quick --jobs 2
  python3 verify.py --early --jobs 2
  python3 verify.py --ownership --jobs 2
  python3 verify.py --full --jobs 2

Quick mode runs the original thirteen foundational/local checks. Early mode
freshly checks the new root corridor, wider-strip/scalar-row arithmetic, one
row propagation round, the column interface, and one further propagation
round. Its PASS is explicitly CONDITIONAL: source root/angle/corner ancestry
has not been established by early mode alone.

Ownership mode freshly checks the selected 12-point case-3 table and
65-point case-5 table from the established initial compulsory hulls.
Case 3 has eight exact owner checks plus one displayed elementary floor
bridge; case 5 has 31 exact owner checks. Their common-point contradictions
exclude those cases, subject to the displayed marker-cover, initial-hull,
and exact-pose soundness proofs. The exact point recipes are
work/readability-research/ownership-simplification/cases35/case3-points.json
and case5-points.json. No original propagation journal is read for these
two selected exclusions.

This mode also freshly checks the six case-0 terminal promotions, four
convex memberships, and scalar inequalities in its displayed all-angle
segment-trap proof. The source hull H12 is an explicit assumption in this
component mode: its ancestry is established only by the full baseline
replay. Case 0 retains 760 promotions and 135 positive owner checks; its
final empty-pose check is replaced by the displayed geometric argument.
The component output is verification/revised-ownership/result.json.
Ownership mode alone does not certify the whole optimality theorem.

Full mode first executes the unchanged 61-command original full runner, then
the new ownership checks, early checks and revised 103-node case-6 assembler.
This portable implementation uses the original computation as a redundant
superset; it does not claim the shorter semantic proof already yields a
shorter full runtime. The older case-0 terminal check and case-3/5 chains
are redundant verification work; the selected proof uses the new endings
and point tables. The new graph discards 20 old nodes and adds 4, retaining
92 original own-rule recipes and 11 revised recipes. Only two new propagation
rounds are premises. The later exploratory continuation rounds are absent.
If --early has already completed in the same extraction, --full automatically
rechecks and reuses that manifest-bound conditional result after the baseline
finishes. Its validity does not depend on which of those two runs came first.

After a complete baseline full run, ownership run and early run in the same
immutable packet, --revised revalidates and composes the 103-node graph. It refuses to
claim global acceptance without the baseline execution ledger and fresh
component outputs, including the selected ownership receipts. The graph in
revised/graph.json is a recipe only, with no saved acceptance flags.
The unchanged fifth-prefix ending and all
other ownership exclusions remain part of the proof. The case-0 source
prefix is discharged by that freshly replayed baseline ancestry.

New logs and ledgers are written during execution. --full --resume resumes
the baseline's own manifest-bound run and revalidates all assemblers. A
completed unchanged early run can be reused with --early --resume. An
unchanged ownership run can be reused with --ownership --resume; --full
also rechecks and reuses a completed ownership run from this extraction.
An interrupted component run should be restarted in a fresh extraction. Full replay
can require substantial time; the new two-round component replay is much
smaller. Use 1--4 requested workers, with at most 2 for each new early round.

The trust model is ordinary displayed geometry plus exact rational Python,
not a Lean proof-kernel replay. Individual components and the semantic
recomposition were checked during development. The revised portable full
orchestration has not yet been executed end to end from this archive.

Some immutable inherited inputs end in .verified-prefix.json or
.verified-exclusion.json. These are mathematical reference records; fresh
checkers recompute their implications. They never substitute for this
packet's execution ledger. Keep the internal work/ layout intact.
