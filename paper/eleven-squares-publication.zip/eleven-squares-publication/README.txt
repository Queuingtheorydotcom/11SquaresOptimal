Eleven squares: proof and reproducible verification

The manuscript is paper/eleven-squares-synthesis.tex. This package contains
the proof, exact checker code, and required mathematical certificate inputs.
It contains no conversation transcript, saved execution logs, observed-run
receipts, device information, or prepopulated fresh verification outputs.

Tested with CPython 3.12.4 using only its standard library. No network access,
Lean installation, solver, or additional download is required.

  python3 verify.py --check-inputs
  python3 verify.py --quick --jobs 2
  python3 verify.py --full --jobs 2

Quick mode executes thirteen foundational, local, and conditional checks.
It does not establish the global ancestry. Full mode executes the selected
ownership exclusions, corner and angle reductions, spatial and shared
journals, exact seed transformations, and the five-round support ending.
Both acceptance assemblers must close before a full run reports success.

The proof combines ordinary displayed mathematical arguments and exact
rational Python verification. This is not a Lean proof-kernel replay.
The underlying workspace computations and all required ancestry were
checked; the portable full-run orchestration has not been executed end to
end from this publication archive. Its input bindings and a clean extracted
quick run are checked separately. A new full replay creates its own ledger.

Some required inherited files have names such as .verified-prefix.json or
.verified-exclusion.json. They are immutable mathematical reference records
or dependency identities, not optional saved evidence of this publication's
execution. Fresh checkers recompute the geometric implications; reference
records support exact comparison and provenance bindings, never replace a
new execution. Their bytes and the reviewed mathematical hashes are retained.

Inherited source documents describe historical stages, and some say global
optimality remained open at that stage. Those pinned historical descriptions
remain unchanged. The current argument and its verification boundary are in
the manuscript and this README.

Full mode can take substantial time. It uses the requested 1--4 workers per
checker. New logs and the execution ledger go into verification/ and the
designated fresh-output directories. After interruption, --full --resume
reuses only unchanged results from the same input-manifest-bound run and
revalidates both assemblers. Do not move files inside the work/ layout.
