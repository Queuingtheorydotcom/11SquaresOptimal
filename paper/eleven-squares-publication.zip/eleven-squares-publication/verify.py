#!/usr/bin/env python3
"""Portable proof checks, with the revised103-node semantic assembly."""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Do not run with Python -O')
from pathlib import Path
import argparse,importlib.util,os,subprocess
ROOT=Path(__file__).resolve().parent
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 modes=ap.add_mutually_exclusive_group()
 for mode in ['check-inputs','quick','early','revised','full']:modes.add_argument('--'+mode,action='store_true')
 ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--resume',action='store_true');a=ap.parse_args()
 if not 1<=a.jobs<=4:raise RuntimeError('jobs must be1..4')
 spec=importlib.util.spec_from_file_location('baseline',ROOT/'verify_baseline.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.verify_inputs()
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONOPTIMIZE':'0'};env.pop('PYTHONPATH',None)
 def run(script,*args):subprocess.run([sys.executable,'-B',script,*args],cwd=ROOT,env=env,check=True)
 if a.quick:run('verify_baseline.py','--quick','--jobs',str(a.jobs));return
 if a.full:run('verify_baseline.py','--full','--jobs',str(a.jobs),*(['--resume'] if a.resume else []))
 if a.early or a.full:
  # A completed earlier conditional run is valid after the baseline closes.
  # The child rechecks its manifest and every generated output before reuse.
  reuse=(a.resume or a.full) and (ROOT/'verification/revised-early/result.json').exists()
  run('revised/replay_early.py','--jobs',str(a.jobs),*(['--resume'] if reuse else []))
 if a.revised or a.full:run('revised/accept_revised.py')
 if not any([a.quick,a.early,a.revised,a.full]):print('PASS: all immutable packet inputs match')
 if a.full:print('PASS_FRESH_COMPLETE_REVISED_PROOF: all ownership cases and103-node case6 ancestry')
if __name__=='__main__':main()
