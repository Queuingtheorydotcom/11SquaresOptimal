#!/usr/bin/env python3
"""Branch-free local isolation via mean-angle contacts and sparse rational duals.

Exact replay needs only the Python standard library and pinned exact_local.py.
Discovery imports scipy only to propose nonnegative weights.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import argparse,hashlib,importlib.util,json,time
SCALE=10**35;Q=10**12;GRID=10**12;R=F(1,280)
GEOMETRY_HASH='e3dc78cf3452e865cf89f1956d3007d330ef54658ffcd6a14eccf417fa5d74cf'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ceil(q):return -((-q.numerator)//q.denominator)
def upper(q):return F(ceil(q*GRID),GRID)
def kabs(x):
 a,b=x.interval();return upper(max(abs(a),abs(b)))
def lower_positive(x):
 a,b=x.interval();need(a>0,'Strict positive algebraic margin required');return F((a*GRID).__floor__(),GRID)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 need(__debug__,'Do not run with Python -O')
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--geometry',type=Path,required=True);ap.add_argument('--certificate',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--discover',action='store_true');args=ap.parse_args();started=time.time()
 need(not args.discover,'Discovery is disabled in this replay bundle')
 need(sha(args.geometry)==GEOMETRY_HASH,'Geometry hash mismatch')
 spec=importlib.util.spec_from_file_location('merged_exact_geometry',args.geometry);e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
 walls,contacts=e.geometry();rows=walls.copy();costs=[F(1,2)]*len(walls);labels=[['wall',i] for i in range(len(walls))];inactive=[];means=[];skipped=[]
 for i,j,opts in contacts:
  if len({b%2 for b,rr in opts})!=1 and len(opts)>1:
   skipped.append([i,j]);continue
  dd=tuple(e.centers[j][k]-e.centers[i][k] for k in range(2));d1=sum(kabs(x) for x in dd)
  need(d1<=8,'Inactive-axis 10r^2 remainder requires D1<=8')
  available=[]
  # Complete all eight signed edge choices; each discarded choice has a
  # strictly negative corner gap throughout the full radius-R neighbourhood.
  for owner,axis,sg in product((i,j),(0,1),(-1,1)):
   other=j if owner==i else i;n=e.cs[owner] if axis==0 else e.rot(e.cs[owner]);candidates=[]
   for vertex,v in enumerate(e.offsets(other)):
    gap=sg*e.dot(dd,n)-F(1,2)-e.dot(v,n)
    if gap.sign()>=0:continue
    gaplo=lower_positive(-gap)
    grad=2*sum(kabs(x) for x in n)+kabs(sg*e.dot(dd,e.rot(n))-e.dot(v,e.rot(n)))+kabs(e.dot(e.rot(v),n))
    candidates.append((gaplo-grad*R-10*R*R,vertex,gaplo,grad))
   if not candidates:
    available.append((2*(owner==j)+axis,sg));continue
   margin,vertex,gaplo,grad=max(candidates)
   need(margin>0,'Inactive axis not excluded')
   inactive.append({'pair':[i,j],'owner':owner,'axis':axis,'sign':sg,'vertex':vertex,'margin':str(margin)})
  need(sorted(b for b,sg in available)==sorted(b for b,rr in opts),'Available edge family mismatch')
  if len(opts)==1:
   b,rr=opts[0];owner=j if b>=2 else i;n=e.cs[owner] if b%2==0 else e.rot(e.cs[owner]);sg=e.dot(dd,n).sign();n1=sum(kabs(x) for x in n);v=kabs(sg*e.dot(dd,n)-F(1,2))
   # Existing analytic product bound, explicitly rechecked below five.
   sharp=2*n1+F(1,4)+F(3,2)*v+R*(7+n1+d1/2)+2*R*R
   need(sharp<=F(9,2),'Mixed-pair remainder insufficient')
   for k,row in enumerate(rr):rows.append(row);costs.append(F(9,2));labels.append(['single',i,j,b,k])
   continue
  need(all((x-y).zero() for x,y in zip(e.cs[i],e.cs[j])),'Mean merge requires equal reference orientation')
  ax=opts[0][0]%2;n=e.cs[i] if ax==0 else e.rot(e.cs[i]);sg=e.dot(n,dd).sign();n=tuple(sg*x for x in n);nn=e.rot(n)
  need(all(s==sg for b,s in available),'Mean normal signs disagree')
  need((e.dot(n,dd)-1).zero(),'Merged contact not active at reference')
  eta=1-R*R/2-kabs(e.dot(nn,dd))-(4+d1)*R;need(eta>0,'No certified tangential overlap')
  remainder=F(9,2)+d1/2
  for ss in [-1,1]:
   row=e.row()
   for k in range(2):row[3*i+k]=-n[k];row[3*j+k]=n[k]
   v=e.dot(nn,dd)/2;row[3*i+2]=v+ss*eta/2;row[3*j+2]=v-ss*eta/2
   rows.append(row);costs.append(remainder);labels.append(['mean',i,j,ax,ss,str(eta)])
  means.append({'pair':[i,j],'eta':str(eta),'quadratic_coefficient':str(remainder)})
 row=e.row();row[-1]=e.K(-1);rows.append(row);costs.append(F(0));labels.append(['container_side_at_most_T'])
 need(len(rows)==41 and len(means)==7 and skipped==[[4,5]],'Unexpected constraint inventory')
 J=[[e.integer_enclosure(x) for x in row] for row in rows]
 rowhash=hashlib.sha256(json.dumps([J,list(map(str,costs)),labels],separators=(',',':')).encode()).hexdigest()
 if args.discover:
  import numpy as np
  from scipy.optimize import linprog
  A=np.array(J,dtype=float)/SCALE;M=np.array([float(x) for x in costs]);entries=[]
  for k,sg in product(range(34),[-1,1]):
   target=np.zeros(34);target[k]=-sg;sol=linprog(M,A_eq=A.T,b_eq=target,bounds=[(0,None)]*len(rows),method='highs');need(sol.success,'No numerical multiplier proposal')
   entries.append({'coordinate':k,'sign':sg,'multipliers':[[i,max(0,round(float(v)*Q))] for i,v in enumerate(sol.x) if v>1e-13]})
  cert={'geometry_sha256':GEOMETRY_HASH,'radius':str(R),'row_sha256':rowhash,'denominator':Q,'entries':entries};args.certificate.write_text(json.dumps(cert,indent=2)+'\n')
 else:cert=json.loads(args.certificate.read_text())
 need(cert['geometry_sha256']==GEOMETRY_HASH and cert['radius']==str(R) and cert['row_sha256']==rowhash and cert['denominator']==Q,'Certificate header mismatch')
 seen=set();checks=[]
 for entry in cert['entries']:
  k,sg,duals=entry['coordinate'],entry['sign'],entry['multipliers'];need(type(k)==int and 0<=k<34 and sg in [-1,1] and (k,sg) not in seen,'Bad coordinate objective');seen.add((k,sg))
  need(all(type(i)==int and 0<=i<len(rows) and type(v)==int and v>=0 for i,v in duals),'Bad nonnegative multiplier');need(len({i for i,v in duals})==len(duals),'Duplicate multiplier index')
  residual=F(0);mass=sum(v for i,v in duals)
  for j in range(34):
   raw=(sg*Q*SCALE if k==j else 0)+sum(v*J[i][j] for i,v in duals)
   residual+=F(abs(raw)+mass,Q*SCALE)
  quadratic=sum(F(v,Q)*costs[i] for i,v in duals)
  need(residual+quadratic*R<1,'No contraction on entire radius')
  checks.append({'coordinate':k,'sign':sg,'residual_l1':str(residual),'quadratic_bound':str(quadratic),'contraction':str(residual+quadratic*R),'support':len(duals)})
 need(seen==set(product(range(34),[-1,1])),'Missing signed coordinate')
 maxeps=max(F(x['residual_l1']) for x in checks);maxC=max(F(x['quadratic_bound']) for x in checks)
 report={'status':'PASS branch-free local isolation','radius':str(R),'rows':len(rows),'mean_pairs':means,'omitted_contact_pairs':skipped,'signed_coordinate_certificates':len(checks),'multiplier_nonzeros':sum(c['support'] for c in checks),'max_support':max(c['support'] for c in checks),'max_residual_l1':str(maxeps),'max_quadratic_bound':str(maxC),'max_residual_display':float(maxeps),'max_quadratic_display':float(maxC),'contraction_display':float(maxeps+maxC*R),'checks':checks,'inactive_axes':inactive,'scope':'Arbitrary independent rotations and legal contacts within radius1/280 of the exact record, and L<=T. No normalized corners, virtual supports, global capture, or prior contact graph is assumed. Geometry, Taylor, mean-angle and inactive-feature lemmas are the analytic premises.','geometry_sha256':GEOMETRY_HASH,'certificate_sha256':sha(args.certificate),'checker_sha256':sha(Path(__file__)),'seconds':time.time()-started}
 args.output.write_text(json.dumps(report,indent=2)+'\n');print(report['status'],'rows',len(rows),'nonzeros',report['multiplier_nonzeros'],'C',float(maxC),'eps',float(maxeps),'ratio',float(maxeps+maxC*R),flush=True)
if __name__=='__main__':main()
