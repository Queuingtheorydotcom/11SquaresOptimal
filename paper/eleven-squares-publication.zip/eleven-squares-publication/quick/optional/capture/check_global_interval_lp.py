#!/usr/bin/env python3
"""Exact interval relaxation and sparse rational dual replay for a global pose cover.

Discovery uses scipy only to propose multipliers. Verification uses the standard
library and accepts only exact rational inequalities. The input pose cover's
geometric completeness is an explicit upstream premise.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product, combinations
import argparse, hashlib, json, time

G=10**12                 # Linear coefficient grid.
BOXGRID=10**10           # Outward coordinate bounds.
TRIGGRID=10**35
DUALGRID=10**12
ALO=F(4003,4000); AHI=F(25019,25000); SIDE=F(97,25)
BASE_T=F(73,200)
BASE_N=((1-BASE_T*BASE_T)/(1+BASE_T*BASE_T),2*BASE_T/(1+BASE_T*BASE_T))
TILTED={0,7,8,9,10}

SPARSE_ROW_LABELS = [['corner', 3, 0, 1], ['corner', 3, 1, 1], ['corner', 4, 0, -1], ['corner', 4, 1, 1], ['pair_mean', 0, 10, 1, 1, -1], ['pair_mean', 0, 10, 1, 1, 1], ['pair_mean', 0, 9, 0, 1, -1], ['pair_mean', 0, 9, 0, 1, 1], ['pair_mean', 2, 5, 0, -1, -1], ['pair_mean', 2, 5, 0, -1, 1], ['pair_mean', 2, 6, 1, 1, -1], ['pair_mean', 2, 6, 1, 1, 1], ['pair_mean', 7, 10, 0, -1, -1], ['pair_mean', 7, 10, 0, -1, 1], ['pair_mean', 7, 9, 1, -1, -1], ['pair_mean', 7, 9, 1, -1, 1], ['pair_mean', 8, 10, 0, 1, -1], ['pair_mean', 8, 10, 0, 1, 1], ['pair_single', 0, 1, [0, 0, -1], '1/2', '1/2'], ['pair_single', 0, 5, [0, 1, -1], '-1/2', '1/2'], ['pair_single', 1, 8, [8, 1, 1], '-1/2', '1/2'], ['pair_single', 3, 9, [9, 0, -1], '1/2', '1/2'], ['pair_single', 4, 10, [10, 1, -1], '-1/2', '1/2'], ['pair_single', 6, 9, [9, 1, 1], '-1/2', '1/2'], ['virtual', 0], ['virtual', 9], ['wall', 1, 1, 1, '-1/2', '-1/2'], ['wall', 1, 1, 1, '1/2', '-1/2'], ['wall', 2, 0, -1, '1/2', '-1/2'], ['wall', 2, 0, -1, '1/2', '1/2'], ['wall', 2, 1, 1, '-1/2', '-1/2'], ['wall', 2, 1, 1, '1/2', '-1/2'], ['wall', 3, 0, -1, '1/2', '-1/2'], ['wall', 3, 1, -1, '-1/2', '1/2'], ['wall', 4, 0, 1, '-1/2', '-1/2'], ['wall', 4, 1, -1, '-1/2', '1/2'], ['wall', 5, 1, 1, '-1/2', '-1/2'], ['wall', 5, 1, 1, '1/2', '-1/2'], ['wall', 6, 0, -1, '1/2', '-1/2'], ['wall', 6, 0, -1, '1/2', '1/2'], ['wall', 7, 1, -1, '1/2', '1/2'], ['wall', 8, 0, 1, '-1/2', '1/2']]
SELECTED_PAIRS = {(0, 1), (4, 10), (0, 10), (7, 10), (1, 8), (0, 9), (8, 10), (7, 9), (2, 6), (3, 9), (0, 5), (2, 5), (6, 9)}

def need(test,message):
 if not test:raise ValueError(message)
def floor(q):return q.numerator//q.denominator
def ceil(q):return -floor(-q)
def down(q,g=BOXGRID):return F(floor(q*g),g)
def up(q,g=BOXGRID):return F(ceil(q*g),g)

class I:
 __slots__=('lo','hi')
 def __init__(self,a=0,b=None):self.lo=F(a);self.hi=F(a if b is None else b)
 def __add__(a,b):
  b=iv(b);return I(a.lo+b.lo,a.hi+b.hi)
 __radd__=__add__
 def __neg__(a):return I(-a.hi,-a.lo)
 def __sub__(a,b):return a+-iv(b)
 def __rsub__(a,b):return iv(b)+-a
 def __mul__(a,b):
  b=iv(b);v=[a.lo*b.lo,a.lo*b.hi,a.hi*b.lo,a.hi*b.hi];return I(min(v),max(v))
 __rmul__=__mul__
 def ab(a):return max(abs(a.lo),abs(a.hi))
 def mid(a):return (a.lo+a.hi)/2

def iv(x):return x if isinstance(x,I) else I(x)
def dot(a,b):return sum((iv(x)*y for x,y in zip(a,b)),I(0))
def rot(v):return (-v[1],v[0])
def scale(a,v):return tuple(a*x for x in v)
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def norm1(v):return sum(abs(x) for x in v)
def sincos(x):
 """Rational enclosures via Taylor remainder; only |x|<=1/2 is needed."""
 need(abs(x)<=F(1,2),'Trigonometric chart exceeded')
 # Taylor polynomials through degree24; Lagrange error <= |x|^25/25!.
 term=F(1);c=F(1);s=F(0)
 for k in range(1,25):
  term*=x/k
  if k%4==0:c+=term
  elif k%4==2:c-=term
  elif k%4==1:s+=term
  else:s-=term
 error=abs(term*x/25)
 return I(down(s-error,TRIGGRID),up(s+error,TRIGGRID)),I(down(c-error,TRIGGRID),up(c+error,TRIGGRID))
def normal(phi,tilted):
 s,c=sincos(phi);n=BASE_N if tilted else (F(1),F(0))
 return (c*n[0]-s*n[1],s*n[0]+c*n[1])
def atan_small(x):
 need(abs(x)<F(1,2),'arctan chart exceeded')
 total=sum(((-1)**k*x**(2*k+1)/F(2*k+1) for k in range(18)),F(0))
 error=abs(x)**37/37
 return I(total-error,total+error)
def lifted_angle(t,owner):
 if owner in TILTED:w=(t-BASE_T)/(1+t*BASE_T)
 else:w=(t-1)/(1+t) if t>F(1,2) else t
 return 2*atan_small(w)

def initial_box(d):
 need(d['case']==6 and d['normalized_corners']==[3,4],'Wrong global geometry')
 need(d['groups']==[[8,9],[0],[1],[2],[3],[4],[5],[6],[7],[10],[11]],'Wrong ownership labels')
 if d.get('method')=='rational_capture_box':
  lo,hi=[[F(x) for x in values] for values in d['box']]
  need(len(lo)==len(hi)==34 and all(a<=b for a,b in zip(lo,hi)),'Invalid rational capture box')
  need(lo[33]>=ALO and hi[33]<=AHI,'Square side outside global interval')
  need(all(abs(v)<=F(1,4) for side in [lo,hi] for v in side[2:33:3]),'Lifted angle chart exceeded')
  need(all(lo[k]==hi[k]==0 for k in [11,14]),'Normalized corner angle not zero')
  return lo,hi
 lo=[];hi=[];N=d['bins']
 need(type(N) is int and N>0,'Angle-bin denominator must be a positive integer')
 for owner,rows in enumerate(d['owners']):
  need(bool(rows),'Empty input owner')
  xy=[];angles=[]
  for p in rows:
   need(type(p['k']) is int and 0<=p['k']<p['k']+1<=N,'Angle bin outside [0,1]')
   tlo,thi=F(p['k'],N),F(p['k']+1,N)
   if owner not in TILTED:
    need(thi<F(1,2) or tlo>F(1,2),'Axis-angle bin crosses a lifting-chart discontinuity')
   c,s=F(p['c']),F(p['s']);need(c*c+s*s==1,'Pose frame not orthonormal')
   xy.extend((c*F(x)-s*F(y),s*F(x)+c*F(y)) for x,y in p['poly'])
   for t in [F(p['k'],N),F(p['k']+1,N)]:angles.append(lifted_angle(t,owner))
  lo.extend([down(min(x for x,y in xy)),down(min(y for x,y in xy)),
             F(0) if owner in [3,4] else down(min(v.lo for v in angles))])
  hi.extend([up(max(x for x,y in xy)),up(max(y for x,y in xy)),
             F(0) if owner in [3,4] else up(max(v.hi for v in angles))])
 lo.append(ALO);hi.append(AHI)
 return lo,hi

def build_rows(d,lo,hi):
 sparse=d.get('constraint_profile')=='sparse42'
 allowed={json.dumps(x,separators=(',',':')) for x in SPARSE_ROW_LABELS}
 ref=[(a+b)/2 for a,b in zip(lo,hi)];r=[(b-a)/2 for a,b in zip(lo,hi)]
 ns=[normal(ref[3*i+2],i in TILTED) for i in range(11)]
 aa=ref[33];ra=r[33];rows=[];rhs=[];labels=[];inventory=[]
 def zero():return [I(0) for k in range(34)]
 def row(g,J,remainder,label):
  key=label[:6] if label[0]=='pair_mean' else label
  if sparse and json.dumps(key,separators=(',',':')) not in allowed:return
  # f(h)>=0 and f(h)<=g+J*delta+remainder imply this outward linear row.
  g=iv(g);ints=[];error=F(0)
  for x,radius in zip(J,r):
   x=iv(x);v=floor(x.mid()*G);ints.append(-v)
   error+=max(abs(x.lo-F(v,G)),abs(x.hi-F(v,G)))*radius
  rows.append(ints);rhs.append(ceil((g.hi+remainder+error)*G));labels.append(label)
 # Walls for every actual corner.
 for i in range(11):
  R=r[3*i+2];n=ns[i]
  for qx,qy in product([F(-1,2),F(1,2)],repeat=2):
   V=add(scale(qx,n),scale(qy,rot(n)))
   for axis,sign in product([0,1],[-1,1]):
    J=zero();J[3*i+axis]=I(sign);J[3*i+2]=sign*aa*rot(V)[axis];J[33]=sign*V[axis]
    g=sign*(ref[3*i+axis]+aa*V[axis])+(SIDE if sign==-1 else 0)
    row(g,J,aa*R*R/2+ra*R,['wall',i,axis,sign,str(qx),str(qy)])
 # Exactly normalized corners, with the same common square side a.
 for i,axis in product([3,4],[0,1]):
  coeff=F(1,2) if i==3 or axis==1 else F(-1,2);target=SIDE if coeff>0 else F(0)
  J=zero();J[3*i+axis]=I(1);J[33]=I(coeff);g=ref[3*i+axis]+coeff*aa-target
  row(g,J,0,['corner',i,axis,1]);row(-g,[-v for v in J],0,['corner',i,axis,-1])
 # The two globally proved virtual obstacles.
 for i,m,ncoef in [(0,2,1),(9,1,2)]:
  c,s=ns[i];D=[SIDE-ref[3*i]-m*aa,ref[3*i+1]-ncoef*aa];v=(s,c);vp=(c,-s);R=r[3*i+2]
  J=zero();J[3*i]=-s;J[3*i+1]=c;J[3*i+2]=dot(vp,D);J[33]=-m*s-ncoef*c-F(1,2)
  rem=(r[3*i]+r[3*i+1]+(m+ncoef)*ra)*R+norm1(D)*R*R/2
  row(dot(v,D)-aa/2,J,rem,['virtual',i])
 # Exhaustive actual feature selection, with interval-certified exclusions.
 for i,j in combinations(range(11),2):
  if sparse and (i,j) not in SELECTED_PAIRS:continue
  dd=[ref[3*j+k]-ref[3*i+k] for k in range(2)]
  dR=sum(r[3*i+k]+r[3*j+k] for k in range(2));available=[];data={};exclusions=[]
  for owner,axis,sign in product([i,j],[0,1],[-1,1]):
   other=j if owner==i else i;n=ns[owner] if axis==0 else rot(ns[owner]);Ro=r[3*owner+2];Rp=r[3*other+2]
   rem=dR*Ro+norm1(dd)*Ro*Ro/2+aa*(Ro+Rp)**2/2+ra*(Ro+Rp)
   gaps=[];exclude=None
   for qx,qy in product([F(-1,2),F(1,2)],repeat=2):
    V=add(scale(qx,ns[other]),scale(qy,rot(ns[other])));J=zero()
    for k in range(2):J[3*i+k]=-sign*n[k];J[3*j+k]=sign*n[k]
    J[3*owner+2]=J[3*owner+2]+sign*dot(rot(n),dd)-aa*dot(V,rot(n))
    J[3*other+2]=J[3*other+2]-aa*dot(rot(V),n);J[33]=-F(1,2)-dot(V,n)
    g=sign*dot(dd,n)-aa/2-aa*dot(V,n)
    upper=g.hi+sum(iv(x).ab()*radius for x,radius in zip(J,r))+rem
    if upper<0:exclude=(str(qx),str(qy),str(upper))
    gaps.append((g,J,rem,str(qx),str(qy)))
   feature=(owner,axis,sign)
   if exclude is not None:exclusions.append((feature,exclude));continue
   available.append(feature);data[feature]=gaps
  need(bool(available),f'All features excluded at pair {(i,j)}')
  used='omitted';extra=None
  if len(available)==1:
   for g,J,rem,qx,qy in data[available[0]]:row(g,J,rem,['pair_single',i,j,list(available[0]),qx,qy])
   used='single'
  elif (i in TILTED)==(j in TILTED) and len({(axis,sign) for own,axis,sign in available})==1:
   axis,sign=available[0][1:];mean=(ref[3*i+2]+ref[3*j+2])/2;n=normal(mean,i in TILTED)
   if axis:n=rot(n)
   n=scale(sign,n);Rm=(r[3*i+2]+r[3*j+2])/2
   ymax=dot(rot(n),dd).ab()+dR+norm1(dd)*Rm
   rel=(ref[3*j+2]-ref[3*i+2])/2;D=abs(rel)+Rm
   need(D<F(1,2),'Mean-angle difference chart exceeded')
   # cos(delta)>=1-D^2/2, exactly; this also enforces the corrected overlap condition.
   mismatch=ALO*(1-D*D/2)-ymax
   if mismatch>=0:
    sr,cr=sincos(rel);J=zero()
    for k in range(2):J[3*i+k]=-n[k];J[3*j+k]=n[k]
    J[3*i+2]=dot(rot(n),dd)*F(1,2)-aa*sr*F(1,2)
    J[3*j+2]=dot(rot(n),dd)*F(1,2)+aa*sr*F(1,2);J[33]=-cr
    rem=dR*Rm+norm1(dd)*Rm*Rm/2+aa*Rm*Rm/2+ra*Rm
    for sg in [-1,1]:
     JJ=list(J);JJ[3*i+2]=JJ[3*i+2]+sg*mismatch/2;JJ[3*j+2]=JJ[3*j+2]-sg*mismatch/2
     row(dot(n,dd)-aa*cr-sg*mismatch*rel,JJ,rem,['pair_mean',i,j,axis,sign,sg,str(mismatch),str(ymax)])
    used='mean';extra={'tangential_upper':str(ymax),'angle_half_difference_upper':str(D),'mismatch_lower':str(mismatch)}
  inventory.append({'pair':[i,j],'available':available,'used':used,'mean_bounds':extra,'excluded_count':len(exclusions)})
 return rows,rhs,labels,inventory,ref,r

def row_hash(rows,rhs,labels):
 return hashlib.sha256(json.dumps([rows,rhs,labels],separators=(',',':')).encode()).hexdigest()
def exact_bound(rows,rhs,ref,r,k,sign,dual):
 need(all(isinstance(i,int) and 0<=i<len(rows) and isinstance(v,int) and v>=0 for i,v in dual),'Bad sparse nonnegative multiplier')
 need(len({i for i,v in dual})==len(dual),'Duplicate dual row')
 dotrhs=sum(v*rhs[i] for i,v in dual)
 residual=[(sign*DUALGRID*G if j==k else 0)+sum(v*rows[i][j] for i,v in dual) for j in range(34)]
 lower=-F(dotrhs,DUALGRID*G)-sum(F(abs(v),DUALGRID*G)*radius for v,radius in zip(residual,r))
 endpoint=ref[k]+sign*lower
 return down(endpoint) if sign==1 else up(endpoint)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',required=True,type=Path);ap.add_argument('--certificate',required=True,type=Path);ap.add_argument('--discover',action='store_true');ap.add_argument('--rounds',type=int,default=8);ap.add_argument('--report',type=Path);args=ap.parse_args()
 need(not args.discover,'Discovery is disabled in this replay bundle')
 started=time.time();raw=args.source.read_bytes();d=json.loads(raw);sha=hashlib.sha256(raw).hexdigest();lo,hi=initial_box(d)
 if args.discover:
  import numpy as np
  from scipy.optimize import linprog
  cert={'status':'exact rational certificates, conditional on complete input pose cover','source_sha256':sha,'source_name':args.source.name,'rounds':[],'angle_reference_half_tangent':str(BASE_T),'grids':{'linear':G,'box':BOXGRID,'dual':DUALGRID}}
  rounds=range(args.rounds)
 else:
  cert=json.loads(args.certificate.read_text());need(cert['source_sha256']==sha,'Source hash mismatch');rounds=range(len(cert['rounds']))
 summaries=[]
 for rnd in rounds:
  rows,rhs,labels,inventory,ref,r=build_rows(d,lo,hi);rhash=row_hash(rows,rhs,labels)
  if args.discover:
   A=np.array(rows,dtype=float)/G;b=np.array(rhs,dtype=float)/G;record={'rows_sha256':rhash,'duals':[]}
   for k in range(34):
    if r[k]==0:continue
    for sign in [1,-1]:
     c=np.zeros(34);c[k]=sign;sol=linprog(c,A_ub=A,b_ub=b,bounds=[(-float(x),float(x)) for x in r],method='highs')
     need(sol.success,f'LP proposal failed: {sol.message}')
     dual=[[i,max(0,round(-float(v)*DUALGRID))] for i,v in enumerate(sol.ineqlin.marginals) if v<-1e-13]
     record['duals'].append({'coordinate':k,'sign':sign,'multipliers':dual})
   cert['rounds'].append(record)
  else:
   record=cert['rounds'][rnd];need(record['rows_sha256']==rhash,f'Linear-row hash mismatch at round {rnd}')
  beforelo,beforehi=lo,hi;freshlo=list(lo);freshhi=list(hi);seen=set()
  for entry in record['duals']:
   k=entry['coordinate'];sign=entry['sign'];need(isinstance(k,int) and 0<=k<34 and sign in [-1,1],'Bad objective')
   need((k,sign) not in seen,'Duplicate objective');seen.add((k,sign))
   endpoint=exact_bound(rows,rhs,ref,r,k,sign,entry['multipliers'])
   if sign==1:freshlo[k]=max(lo[k],endpoint)
   else:freshhi[k]=min(hi[k],endpoint)
  expected={(k,s) for k in range(34) if r[k]>0 for s in [-1,1]}
  need(seen==expected,'Missing objective bound')
  need(all(a<=b for a,b in zip(freshlo,freshhi)),'Inconsistent enclosure')
  lo,hi=freshlo,freshhi
  summary={'round':rnd,'linear_rows':len(rows),'before':[[str(v) for v in beforelo],[str(v) for v in beforehi]],'after':[[str(v) for v in lo],[str(v) for v in hi]],'pair_inventory':inventory,'max_dual_support':max(len(x['multipliers']) for x in record['duals']),'total_dual_nonzeros':sum(len(x['multipliers']) for x in record['duals'])}
  summaries.append(summary)
  print('EXACT round',rnd,'centre width',float(max(hi[3*i+k]-lo[3*i+k] for i in range(11) for k in [0,1])),'angle width',float(max(hi[3*i+2]-lo[3*i+2] for i in range(11))),'elapsed',round(time.time()-started,1),flush=True)
  if args.discover:args.certificate.write_text(json.dumps(cert,indent=2)+'\n')
 report={'verdict':'PASS: exact global interval-box implications verified','scope':'Conditional on the complete globally valid input coordinate box, normalized corners, and two virtual-support inequalities. This replay proves each stated box implication, not upstream completeness or global optimality.','source_sha256':sha,'source_name':args.source.name,'certificate_sha256':hashlib.sha256(args.certificate.read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rounds':summaries,'final_box':[[str(v) for v in lo],[str(v) for v in hi]],'angle_coordinate':'Angle minus 2*atan(73/200) for owners0,7,8,9,10; lifted angle near0 for other owners.','elapsed_seconds':time.time()-started}
 if args.report:args.report.write_text(json.dumps(report,indent=2)+'\n')
 print(report['verdict'],flush=True)
if __name__=='__main__':main()
