#!/usr/bin/env python3
"""Replay the global LP certificate, then compare all 34 unit-frame coordinates.

No saved PASS label is a premise: this command reruns the exact implication
checker before performing the algebraic comparison.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,importlib.util,json,subprocess,time
from check_global_interval_lp import need,atan_small,BASE_T,SIDE,TILTED,I
POINTS=[(F(1),F(1)),(F(72,25),F(1)),(F(72,25),F(72,25)),(F(1),F(72,25)),(F(97,50),F(3,4)),(F(313,100),F(97,50)),(F(97,50),F(313,100)),(F(3,4),F(97,50)),(F(159,100),F(159,100)),(F(229,100),F(159,100)),(F(229,100),F(229,100)),(F(159,100),F(229,100))]
GROUPS=[[8,9],[0],[1],[2],[3],[4],[5],[6],[7],[10],[11]]
GEOMETRY_HASH='e3dc78cf3452e865cf89f1956d3007d330ef54658ffcd6a14eccf417fa5d74cf'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',required=True,type=Path);ap.add_argument('--certificate',required=True,type=Path);ap.add_argument('--replay',required=True,type=Path,help='Fresh implication receipt destination');ap.add_argument('--geometry',required=True,type=Path);ap.add_argument('--output',required=True,type=Path);args=ap.parse_args()
 started=time.time();checker=Path(__file__).parent/'check_global_interval_lp.py'
 subprocess.run([sys.executable,str(checker),'--source',str(args.source),'--certificate',str(args.certificate),'--report',str(args.replay)],check=True)
 replay=json.loads(args.replay.read_text())
 need(replay['checker_sha256']==sha(checker),'Executed checker binding mismatch')
 need(replay['source_sha256']==sha(args.source),'Executed source binding mismatch')
 need(replay['certificate_sha256']==sha(args.certificate),'Executed certificate binding mismatch')
 need(sha(args.geometry)==GEOMETRY_HASH,'Unreviewed geometry module')
 spec=importlib.util.spec_from_file_location('capture_exact_geometry',args.geometry);e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
 a=e.K(SIDE)/e.L;target={}
 for idx,(center,cs) in enumerate(zip(e.centers,e.cs)):
  x=e.K(SIDE)-a*center[0];y=e.K(SIDE)-a*center[1];c,s=cs;owned=[]
  for j,(px,py) in enumerate(POINTS):
   dx=e.K(px)-x;dy=e.K(py)-y;u=c*dx+s*dy;v=-s*dx+c*dy
   if all(z.sign()>0 for z in [a/2-u,a/2+u,a/2-v,a/2+v]):owned.append(j)
  target[tuple(owned)]=(idx,x,y)
 need(set(target)==set(map(tuple,GROUPS)),'Record ownership mismatch')
 left=2*atan_small((e.UL-BASE_T)/(1+e.UL*BASE_T));right=2*atan_small((e.UH-BASE_T)/(1+e.UH*BASE_T));angle=I(left.lo,right.hi)
 summaries=[];STRONG=F(1,2000);LOCAL=F(1,280)
 def enclosed(lo,hi,reference,radius):
  return (e.K(lo)+radius-reference).sign()>=0 and (reference+radius-hi).sign()>=0
 for entry in replay['rounds']:
  lo,hi=[[F(x) for x in side] for side in entry['after']];checks=[]
  need(lo[33]>0,'Nonpositive square side')
  for owner,group in enumerate(GROUPS):
   idx,x,y=target[tuple(group)];refangle=angle if owner in TILTED else I(0)
   err=max(abs(lo[3*owner+2]-refangle.hi),abs(hi[3*owner+2]-refangle.lo))
   normalized_centers=enclosed(lo[3*owner],hi[3*owner],x,STRONG) and enclosed(lo[3*owner+1],hi[3*owner+1],y,STRONG)
   norm_error=max(abs(float(lo[3*owner])-float(x)),abs(float(hi[3*owner])-float(x)),abs(float(lo[3*owner+1])-float(y)),abs(float(hi[3*owner+1])-float(y)))
   unit_intervals=[]
   for axis in [0,1]:
    need(hi[3*owner+axis]<SIDE,'Center outside positive inverse chart')
    unit_intervals.append(((SIDE-hi[3*owner+axis])/hi[33],(SIDE-lo[3*owner+axis])/lo[33]))
   unit_strong=all(enclosed(p,q,e.centers[idx][axis],STRONG) for axis,(p,q) in enumerate(unit_intervals))
   unit_local=all(enclosed(p,q,e.centers[idx][axis],LOCAL) for axis,(p,q) in enumerate(unit_intervals))
   unit_error=max(abs(float(z)-float(e.centers[idx][axis])) for axis,pair in enumerate(unit_intervals) for z in pair)
   checks.append({'owner':owner,'record_index':idx,'normalized_centers_within_1_2000':normalized_centers,'angle_error_upper':str(err),'angle_within_1_2000':err<=STRONG,'angle_within_1_280':err<=LOCAL,'unit_center_intervals':[[str(z) for z in pair] for pair in unit_intervals],'unit_centers_within_1_2000':unit_strong,'unit_centers_within_1_280':unit_local,'normalized_center_error_display':norm_error,'unit_center_error_display':unit_error,'angle_error_display':float(err)})
  unit_side=(SIDE/hi[33],SIDE/lo[33]);side_strong=enclosed(*unit_side,e.L,STRONG);side_local=enclosed(*unit_side,e.L,LOCAL)
  normalized_a=enclosed(lo[33],hi[33],a,STRONG)
  summaries.append({'round':entry['round'],'all_normalized_34_within_1_2000':normalized_a and all(x['normalized_centers_within_1_2000'] and x['angle_within_1_2000'] for x in checks),'all_unit_34_within_1_2000':side_strong and all(x['unit_centers_within_1_2000'] and x['angle_within_1_2000'] for x in checks),'all_unit_34_within_1_280':side_local and all(x['unit_centers_within_1_280'] and x['angle_within_1_280'] for x in checks),'checks':checks,'unit_container_side_interval':[str(z) for z in unit_side],'unit_side_within_1_2000':side_strong,'unit_side_within_1_280':side_local,'normalized_square_side_within_1_2000':normalized_a,'max_normalized_center_error_display':max(x['normalized_center_error_display'] for x in checks),'max_unit_center_error_display':max(x['unit_center_error_display'] for x in checks),'max_angle_error_display':max(x['angle_error_display'] for x in checks),'max_unit_side_error_display':max(abs(float(z)-float(e.L)) for z in unit_side)})
 final=summaries[-1];passed=final['all_unit_34_within_1_280'];strong=final['all_unit_34_within_1_2000']
 result={'verdict':'PASS: all 34 unit-frame coordinates captured within 1/280' if passed else 'FAIL: local target not captured','stronger_all_unit_34_within_1_2000':strong,'stronger_all_normalized_34_within_1_2000':final['all_normalized_34_within_1_2000'],'first_unit_1_280_round':next((x['round'] for x in summaries if x['all_unit_34_within_1_280']),None),'round_checks':summaries,'coordinate_transform':'For owner mapped to record index i, unit center=((S-X)/a,(S-Y)/a), unit container side=S/a; undo common half-turn and use quarter-turn-equivalent lifted angles. Local side<=T follows separately from a>=a*=S/T.','scope':'This command freshly replays the rational LP certificate and checks the exact algebraic capture. Upstream coordinate-box completeness, normalized corners, virtual-support inequalities, and stated elementary analytic bounds remain explicit premises. No fresh Lean verification.','source_sha256':{'global_lp_replay':sha(args.replay),'global_pose_seed':sha(args.source),'global_lp_certificate':sha(args.certificate),'exact_local.py':GEOMETRY_HASH,'check_lp_capture.py':sha(Path(__file__)),'check_global_interval_lp.py':sha(checker)},'elapsed_seconds':time.time()-started}
 args.output.write_text(json.dumps(result,indent=2)+'\n')
 for summary in summaries:print('CAPTURE',summary['round'],summary['all_unit_34_within_1_280'],summary['max_unit_center_error_display'],summary['max_angle_error_display'],flush=True)
 print(result['verdict'],flush=True);need(passed,'Capture failed')
if __name__=='__main__':main()
