#!/usr/bin/env python3
"""Verify immutable inputs before running exact, standard-library checks."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import argparse, hashlib, json, os, subprocess, time

ROOT = Path(__file__).resolve().parent
def need(ok, message):
    if not ok: raise RuntimeError(message)
def verify():
    manifest = json.loads((ROOT/'manifest.json').read_text())
    need(manifest['schema']=='eleven-squares-paper-bundle-v2', 'Unknown manifest schema')
    expected = manifest['files']
    observed = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
                and p.relative_to(ROOT).parts[0] != 'results' and p != ROOT/'manifest.json'}
    need(observed == set(expected), 'Manifest file inventory differs')
    for name, item in expected.items():
        p = ROOT/name
        need(p.is_file() and not p.is_symlink(), 'Missing or symbolic input: '+name)
        raw = p.read_bytes()
        need(len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],
             'Manifest hash mismatch: '+name)
    return hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest()

def main():
    need(__debug__, 'Run without Python -O')
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--optional', action='store_true', help='Also replay the local/capture backup route')
    ap.add_argument('--verify-only', action='store_true')
    ap.add_argument('--only', help='Run one named check; write a separate run summary')
    ap.add_argument('--jobs',type=int,default=2,help='Workers for the two short ownership cases')
    args=ap.parse_args(); need(args.jobs>0, 'jobs must be positive')
    manifest_sha=verify()
    print('PASS manifest: all immutable files match', flush=True)
    if args.verify_only: return
    out=ROOT/'results'; out.mkdir(exist_ok=True)
    def p(name):return str(ROOT/name)
    commands=[
      ('foundation', ['scripts/check_foundation.py','--source','source','--output','results/foundation.json'], 'foundation.json','verdict','PASS_FRESH_FOUNDATIONAL_ARITHMETIC_AND_CONSTRUCTION'),
      ('geometric_premises', ['scripts/check_geometric_prefix.py','--seed','data/prefix-05.json','--expected-seed-sha256','bfc0cc47c5752ba2e182174110182b785106450129af8f024ac88d7ab3e01ba4','--box','data/prefix05-box-1000.json','--output','results/geometric-premises.json'], 'geometric-premises.json','verdict','PASS_EXACT_MIXED_SUPPORT_GEOMETRIC_PREMISES'),
      ('direct_mixed_bound', ['scripts/check_mixed_prefix.py','--seed','data/prefix05-box-1000.json','--splits','4','--output','results/mixed-four-intervals.json'], 'mixed-four-intervals.json','verdict','PASS_MIXED_GLOBAL_ALIGNMENT'),
      ('printed_rational_bounds', ['scripts/check_printed_bounds.py','--input','results/mixed-four-intervals.json','--output','results/printed-bounds.json'], 'printed-bounds.json','verdict','PASS_PRINTED_RATIONAL_BOUNDS'),
      ('block_equalities', ['scripts/check_block_equalities_prefix.py'], 'block-equalities.json','verdict','PASS_SIX_SQUARE_EQUALITY_COROLLARY'),
      ('case0_conditional_terminal', ['scripts/check_case0_nine_point_terminal.py','--source','source','--output','results/case0-terminal.json'], 'case0-terminal.json','status','PASS: CONDITIONAL NINE-POINT CASE-0 TERMINAL'),
      ('case3_short_exclusion', ['scripts/replay_case3.py','--source','source','--output','results/case3.json','--jobs',str(args.jobs)], 'case3.json','status','PASS: SHORTENED CASE-3 EXCLUSION FROM SOURCE INITIAL OWNED POINTS'),
      ('case5_short_exclusion', ['scripts/sparse_chain.py','--source','source','--case','5','--mode','replay','--plan','data/case5-plan.json','--output','results/case5.json','--jobs',str(args.jobs)], 'case5.json','status','PASS: SHORTENED OWNERSHIP CASE EXCLUSION FROM SOURCE INITIAL PREMISES'),
      ('compact_column_and_second_corner', ['scripts/check_compact_envelopes.py','--source','source','--output','results/compact-envelopes.json'], 'compact-envelopes.json','verdict','PASS compact envelope and scalar checks'),
      ('early_bottom_row', ['scripts/check_bottom_row_envelope.py'], 'bottom-row-envelope-result.json','verdict','PASS exact compact bottom-row interface'),
      ('strip_positive_identities', ['scripts/check_strip_factorizations.py'], 'strip-factorizations-result.json','verdict','PASS')
    ]
    if args.optional:
        commands += [
          ('optional_local_41_rows',['optional/local/check_merged_local.py','--geometry','source/local_data/exact_local.py','--certificate','data/merged-local-certificate.json','--output','results/optional-local.json'],'optional-local.json','status','PASS branch-free local isolation'),
          ('optional_capture_42_rows',['optional/capture/check_lp_capture.py','--source','data/sparse-capture-box.json','--certificate','data/sparse-capture-certificate.json','--replay','results/optional-capture-lp.json','--geometry','source/local_data/exact_local.py','--output','results/optional-capture.json'],'optional-capture.json','verdict','PASS: all 34 unit-frame coordinates captured within 1/280')
        ]
    if args.only:
        commands=[row for row in commands if row[0]==args.only]
        need(len(commands)==1, 'Unknown selected check')
        need(args.only!='printed_rational_bounds', 'Run the direct theorem and its printed bounds together using the default command')
    records=[]; start=time.monotonic()
    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    for name, argv, receipt, key, expected in commands:
        began=time.monotonic(); print('CHECK',name,flush=True)
        (out/receipt).unlink(missing_ok=True)
        with (out/(name+'.log')).open('w') as log:
            child=subprocess.run([sys.executable,*argv],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        if child.returncode:
            print((out/(name+'.log')).read_text()[-6000:],flush=True)
        need(child.returncode==0, 'Checker failed: '+name)
        result=json.loads((out/receipt).read_text())
        need(result.get(key)==expected, 'Unexpected receipt status: '+name)
        if name=='optional_capture_42_rows':
            need(result['stronger_all_unit_34_within_1_2000'], 'Strong capture target failed')
        records.append({'check':name,'verdict':result[key],'seconds':round(time.monotonic()-began,3),
                        'receipt':receipt,'receipt_sha256':hashlib.sha256((out/receipt).read_bytes()).hexdigest()})
        print('PASS',name,records[-1]['seconds'],'seconds',flush=True)
    summary={'verdict':'PASS_ALL_REQUESTED_CHECKS','optional_checks_run':args.optional,
             'manifest_sha256':manifest_sha,'checks':records,'seconds':round(time.monotonic()-start,3),
             'scope':'Fresh exact foundational arithmetic and local/conditional implications only. The nonavoidance lemmas and ownership argument remain mathematical premises; remaining ownership cases, normalization and full pose-cover ancestry are not replayed. The direct ending uses the fifth prefix, whose ancestry is an explicit external input. No Lean proof-kernel replay.'}
    summary['selection']=args.only
    (out/('run-summary-'+args.only+'.json' if args.only else 'run-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
    print(summary['verdict'],len(records),'checks;',summary['seconds'],'seconds',flush=True)
if __name__=='__main__':main()
