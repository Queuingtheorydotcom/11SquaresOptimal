#!/usr/bin/env python3
"""Check a compact virtual-bottom-row interface with exact rational arithmetic.

The input is an archived pose cover, not an independently established global
theorem. No source code is imported, no pruning/search is performed, and no
source file is changed. See COMPACT_BOTTOM_ROW.md for the geometric proof.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

if not __debug__:
    raise RuntimeError("Do not run this proof checker with Python -O")

BASE = Path(__file__).resolve().parents[1] / "source"
SOURCE = BASE / "exploration/virtual-column-global-N192-certified-seed.json"
OUT = Path(__file__).resolve().parents[1]/"results/bottom-row-envelope-result.json"
ALO, AHI, S = F(4003, 4000), F(25019, 25000), F(97, 25)


def normal(t):
    return (1-t*t)/(1+t*t), 2*t/(1+t*t)


def dot(n, p):
    return n[0]*p[0]+n[1]*p[1]


def centers(p, bins):
    c, s = F(p["c"]), F(p["s"])
    assert (c, s) == normal(F(2*p["k"]+1, 2*bins))
    return [(c*F(u)-s*F(v), s*F(u)+c*F(v)) for u, v in p["poly"]]


def outer_vertices(p, bins):
    c, s = F(p["c"]), F(p["s"])
    h = AHI*(1+F(1, bins))/2
    return [(x+h*(i*c-j*s), y+h*(i*s+j*c))
            for x, y in centers(p, bins) for i in (-1, 1) for j in (-1, 1)]


def main():
    data = json.loads(SOURCE.read_text())
    bins = data["bins"]
    assert bins == 192
    assert data["case"] == 6 and data["normalized_corners"] == [3, 4]
    assert data["groups"] == [[8, 9], [0], [1], [2], [3], [4], [5], [6], [7], [10], [11]]
    checks = []

    def nonnegative(label, margin):
        assert margin >= 0, (label, margin)
        checks.append({"name": label, "margin": str(margin)})

    def positive(label, margin):
        assert margin > 0, (label, margin)
        checks.append({"name": label, "positive_margin": str(margin)})

    cp = {i: [z for p in data["owners"][i] for z in centers(p, bins)]
          for i in (0, 2, 5)}
    wp = {i: [z for p in data["owners"][i] for z in outer_vertices(p, bins)]
          for i in (2, 5)}
    boxes = {0: tuple(map(F, ("1.880", "1.931", "1.655", "1.703"))),
             5: tuple(map(F, ("2.297", "2.381", ".500", ".552")))}
    for owner, (xl, xu, yl, yu) in boxes.items():
        nonnegative(f"owner {owner} center box", min(
            min(x-xl, xu-x, y-yl, yu-y) for x, y in cp[owner]))
    for owner in (2, 5):
        nonnegative(f"owner {owner} whole-square height <= 1.08",
                    F("1.08")-max(y for x, y in wp[owner]))
    nonnegative("owner 2 whole square x >= 2.78",
                min(x for x, y in wp[2])-F("2.78"))

    for owner, lo, hi in ((0, F(1, 3), F(3, 8)),
                          (5, -F(3, 125), F(1, 26))):
        for p in data["owners"][owner]:
            a, b = F(p["k"], bins), F(p["k"]+1, bins)
            if owner == 5 and a >= F(1, 2):
                a, b = (a-1)/(a+1), (b-1)/(b+1)
            assert lo <= a <= b <= hi

    C, T = normal(F(1, 26))
    ng = (-T, C)
    bstar = (F("1.844"), F(".9968"))
    bottom_checks = []
    for p in data["owners"][0]:
        pts = centers(p, bins)
        c, s = normal(F(p["k"], bins))
        # Both c+s and (C-T)c+(C+T)s increase for theta in [0,pi/4].
        ymax = max(y for x, y in pts)-ALO*(c+s)/2
        ngmax = max(dot(ng, z) for z in pts)-ALO*((C-T)*c+(C+T)*s)/2
        my, mn = bstar[1]-ymax, dot(ng, bstar)-ngmax
        positive(f"bottom vertex height, angle bin {p['k']}", my)
        positive(f"bottom vertex slanted support, angle bin {p['k']}", mn)
        bottom_checks.append({"bin": p["k"], "height_margin": str(my),
                              "slanted_support_margin": str(mn)})

    e1 = normal(F(3, 8))
    nonnegative("R-center support along e1 <= 2.568",
                F("2.568")-max(dot(e1, z) for z in cp[0]))

    # The remaining scalar inequalities appearing in the proof.
    cb, sb = normal(F(3, 125))
    positive("R edge projections < 1", 1-max(F(".501"), F("1.203")*e1[1]))
    positive("Q positive edge projections < 1", 1-max(F(".501"), F("1.203")*T))
    positive("Q negative edge projections < 1", 1-F(".501")-F("1.203")*sb)
    positive("Q NW normal has positive center projection",
             F("1.103")*cb-F(".501")*sb)
    positive("positive-angle quartic bound",
             F(".0032")-F(".074")/26-F("2.074")/26**3)
    positive("P separates in every R NW normal",
             F(3, 5)*F(".849")+e1[0]*F(".575")-AHI/2)
    positive("whole-square strip height", 3*ALO/2-F("1.08"))
    positive("corner horizontal displacement positive", F("1.880")-(S-2*ALO))
    positive("corner vertical displacement exceeds horizontal",
             F("1.655")-AHI-(F("1.931")-S+2*AHI))
    positive("corner edge projection increases with side", 2*e1[0]-e1[1]-F(1, 2))
    positive("corner lies inside R edge strip",
             e1[0]*S-AHI*(2*e1[0]-e1[1]-F(1, 2))-F("2.568"))
    positive("corner is below R in its NW normal",
             e1[0]*F(".654")-e1[1]*F(".053"))

    result = {
        "verdict": "PASS exact compact bottom-row interface",
        "source": str(SOURCE.relative_to(BASE)),
        "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "pose_counts": {str(i): len(data["owners"][i]) for i in (0, 2, 5)},
        "bottom_vertex_checks": bottom_checks,
        "checks": checks,
        "scope": "Exact extraction and scalar checks only. Source ancestry, "
                 "global capture, and the input pose-cover theorem were not replayed. "
                 "The continuous geometric argument is in COMPACT_BOTTOM_ROW.md."
    }
    OUT.write_text(json.dumps(result, indent=2)+"\n")
    print(result["verdict"])
    print(len(checks), "rational inequalities;", OUT.name)


if __name__ == "__main__":
    main()
