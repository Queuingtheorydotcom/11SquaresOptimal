"""Exact reference-block equalities and rational stability constants."""
import sys
if not __debug__:
    raise RuntimeError('Run without python -O.')
sys.dont_write_bytecode = True
from pathlib import Path
from fractions import Fraction as F
import importlib.util, json, hashlib
HERE=Path(__file__).resolve().parent
EXACT=HERE.parent/'source/local_data/exact_local.py'
spec=importlib.util.spec_from_file_location('exact_block',EXACT)
x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)
A,B,C,D,E=[x.centers[k] for k in range(6,11)];Z=x.centers[2]
e=(x.C,x.S);n=x.rot(e);L=x.L;w=x.C+x.S;h=(1+w)/2
sub=lambda p,q:tuple(a-b for a,b in zip(p,q))
gaps={
 'Acorner':x.dot(e,sub(A,(1,1)))-F(1,2),
 'Dcorner':x.dot(n,sub(D,(L-1,1)))-F(1,2),
 'Avirtual':x.dot(n,sub((1,L-2),A))-F(1,2),
 'Cvirtual':x.dot(n,sub((2,L-1),C))-F(1,2),
 'Bwall':B[1]-w/2,'Ewall':L-E[0]-w/2,'Fwall':L-Z[1]-F(1,2),
 'CF':x.dot(e,sub(Z,C))-h,'EF':x.dot(n,sub(Z,E))-h,
 'AB':x.dot(n,sub(A,B))-1,'AC':x.dot(e,sub(C,A))-1,
 'BD':x.dot(e,sub(D,B))-1,'DE':x.dot(e,sub(E,D))-1,
 'CD':x.dot(n,sub(C,D))-1}
assert all(g.zero() for g in gaps.values())
assert x.C.sign()>0 and x.S.sign()>0
beta=[F(1,10),F(1,20),F(7,100),F(1,10)]
gamma=[F(11,200),F(9,200),F(3,50),F(49,500)]
assert [b-g for b,g in zip(beta,gamma)]==[F(9,200),F(1,200),F(1,100),F(1,500)]
bridge_margin=F(3,40)*(1-F(21,1000)**2/6)-F(7,100)
assert bridge_margin>0
out={'verdict':'PASS_SIX_SQUARE_EQUALITY_COROLLARY','exact_construction_sha256':hashlib.sha256(EXACT.read_bytes()).hexdigest(),
 'vanishing_gaps':list(gaps),'positive_determinant_factors':['1','sin(theta*)'],
 'tree_gain_coefficients':['9/200','1/200','1/100','1/500'],
 'bridge_gain_coefficient':'7/100','bridge_sine_lower_bound_margin':str(bridge_margin),
 'scope':'Only the named six-square block, with the support-envelope and fixed-corner premises of the mixed support theorem. No global or full eleven-square uniqueness claim.'}
(HERE.parent/'results/block-equalities.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['verdict'])
