"""Replay a shortened case-3 exclusion, with no writes to original sources."""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from fractions import Fraction as F
import argparse
import hashlib
import json
import sys
import time

sys.dont_write_bytecode=True
if not __debug__:
    raise RuntimeError('Do not run with Python -O')

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,default=HERE.parent/'source',help='Read-only directory containing the three source modules and exploration journal.')
parser.add_argument('--output',type=Path,default=HERE/'case3-compact-certificate.json',help='Receipt filename outside the source directory.')
parser.add_argument('--jobs',type=int,default=4)
ARGS=parser.parse_args()
SOURCE=ARGS.source.resolve()
OUTPUT=ARGS.output.resolve()
if OUTPUT.is_relative_to(SOURCE):
    raise ValueError('The output must not be inside the read-only source directory')
sys.path.insert(0,str(SOURCE))
from marker_cases import all_cases,groups,A_LO,A_HI,S
from forced_markers import owned_points,hull
from exact_poses import verify_owner,contains

def task(args):
    return verify_owner(*args)

def serial(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [serial(v) for v in x]
    return x

if __name__=='__main__':
    start=time.monotonic()
    path=SOURCE/'exploration/journal-case-3-N96.json'
    d=json.loads(path.read_text())
    gs=groups(all_cases()[0][3]);N=96
    assert d['case']==3 and d['bins']==N and d['groups']==[list(g) for g in gs]
    assert all_cases()[0][3]=={'kind':'pair','indices':[0,4]}
    assert S==F(97,25) and A_LO==F(4003,4000) and A_HI==F(25019,25000)
    initial={g:hull(owned_points(g)) for g in gs}
    first_targets=((0,4),(8,),(9,),(10,),(11,))
    second_targets=((2,),(8,),(10,),(11,))
    updates=[{g:hull([tuple(map(F,p)) for p in d['history'][r]['hulls'][gs.index(g)]]) for g in tg} for r,tg in enumerate((first_targets,second_targets))]
    hs=initial.copy();stages=[]
    with ProcessPoolExecutor(max_workers=ARGS.jobs) as pool:
        for r,new in enumerate(updates):
            tasks=[(g,[p for p in h if not contains(hs[g],p)],N,gs,hs,None) for g,h in new.items()]
            checks=list(pool.map(task,tasks))
            stages.append({'stage':r,'promoted_hulls':new,'checks':checks})
            hs.update(new)
        # Forget unneeded strengthened owners; this weakens the premises.
        terminal_hs={g:hs[g] if g in second_targets else initial[g] for g in gs}
        shared=(F(49,25),F(73,25))
        terminal_checks=list(pool.map(task,[(g,[shared],N,gs,terminal_hs,None) for g in ((11,),(6,))]))
    files=[path,SOURCE/'marker_cases.py',SOURCE/'forced_markers.py',SOURCE/'exact_poses.py',Path(__file__)]
    receipt={'status':'PASS: SHORTENED CASE-3 EXCLUSION FROM SOURCE INITIAL OWNED POINTS',
        'scope':'All62ownership promotions replayed with exact source rational pose kernel. Source initial marker ownership/coverage and mathematical soundness of the kernel remain explicit premises. No other ownership case or global capture is proved.',
        'container_side':S,'square_side_open_interval':[A_LO,A_HI],
        'case':all_cases()[0][3],'angle_bins':N,'groups':gs,'stages':stages,
        'terminal':{'point':shared,'distinct_owners':[(11,),(6,)],'checks':terminal_checks,'reason':'The same point lies strictly inside two distinct packing squares.'},
        'new_point_count':sum(c['points'] for s in stages for c in s['checks'])+sum(c['points'] for c in terminal_checks),
        'owner_checks':sum(len(s['checks']) for s in stages)+len(terminal_checks),
        'elapsed_seconds':time.monotonic()-start,
        'source_sha256':{str(p.relative_to(SOURCE)) if p.is_relative_to(SOURCE) else p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    OUTPUT.write_text(json.dumps(serial(receipt),indent=2)+'\n')
    print(json.dumps({k:serial(receipt[k]) for k in ('status','new_point_count','owner_checks','elapsed_seconds')}),flush=True)
