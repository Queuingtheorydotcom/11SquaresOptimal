"""Exact interval probe of moving-angle support-cycle/tree dominance.

This is research, not a full packing theorem. Upstream pose-cover completeness,
virtual supports, and the selected edge families remain explicit hypotheses.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import importlib.util,json,hashlib,argparse,time
from itertools import product

CHECK=Path(__file__).with_name('interval_core.py')
spec=importlib.util.spec_from_file_location('global_interval',CHECK)
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
I=g.I
def div(a,b):
 a=g.iv(a);b=g.iv(b)
 if not b.lo>0:raise ValueError('Nonpositive denominator')
 return a*I(1/b.hi,1/b.lo)
def center(iv):return (iv.lo+iv.hi)/2
def interval_angle_normal(phi):
 nl=g.normal(phi.lo,True);nh=g.normal(phi.hi,True)
 return I(nh[0].lo,nl[0].hi),I(nl[1].lo,nh[1].hi)
def arc_project(phi,box,axis=0):
 # An interval over all centers in the rectangle and every angle in phi.
 vals=[]
 for v in product(*[(x.lo,x.hi) for x in box]):
  for t in [phi.lo,phi.hi]:
   n=g.normal(t,True)
   if axis:n=g.rot(n)
   vals.append(g.dot(n,v))
 # Linear-interpolation error at each rectangle vertex.
 error=sum(x.ab() for x in box)*(phi.hi-phi.lo)**2/8
 return I(min(x.lo for x in vals)-error,max(x.hi for x in vals)+error)
def hull(a,b):return I(min(a.lo,b.lo),max(a.hi,b.hi))
def angle_sin(phi):
 l=g.sincos(phi.lo)[0];h=g.sincos(phi.hi)[0]
 return I(l.lo,h.hi)
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def vadd(a,b):return tuple(x+y for x,y in zip(a,b))
def vscale(a,b):return tuple(a*x for x in b)
def nderiv_vector(v,axis):
 # n_axis'(theta).v = e(theta).nderiv_vector(v,axis).
 return tuple(-x for x in (g.rot(v) if axis==0 else v))
def encode(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,I):return [str(x.lo),str(x.hi)]
 if isinstance(x,dict):return {str(k):encode(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [encode(v) for v in x]
 return x

OWN={'A':9,'B':7,'C':0,'D':10,'E':8,'F':1}
EDGES=[('AB','B','A',1),('AC','A','C',0),('BD','B','D',0),('DE','D','E',0)]
CUTS={'AC':set('ABDE'),'AB':set('BDE'),'BD':set('DE'),'DE':set('E')}

def load(seed):
 data=json.loads(seed.read_text())
 if data.get('method')=='rational_capture_box':
  g.need(data['case']==6 and data['normalized_corners']==[3,4],'Wrong global geometry')
  g.need(data['groups']==[[8,9],[0],[1],[2],[3],[4],[5],[6],[7],[10],[11]],'Wrong ownership labels')
  lo,hi=[list(map(F,row)) for row in data['box']]
  g.need(len(lo)==len(hi)==34 and all(x<=y for x,y in zip(lo,hi)),'Malformed rational box')
  g.need(lo[33]==g.ALO and hi[33]==g.AHI,'Unexpected square-side bounds')
 else:lo,hi=g.initial_box(data)
 a=I(g.ALO,g.AHI);L=div(g.SIDE,a);boxes={};angles={}
 for name,owner in OWN.items():
  boxes[name]=tuple(div(I(g.SIDE-hi[3*owner+k],g.SIDE-lo[3*owner+k]),a) for k in range(2))
  angles[name]=I(lo[3*owner+2],hi[3*owner+2])
 return boxes,angles,L,data

