#!/usr/bin/env python3
"""Bind fresh prefix, feature and analytic receipts; check all printed constants."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json
if not __debug__:raise RuntimeError('Run without Python -O')
ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
root=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads(a.input.read_text())
geo=json.loads((root/'results/geometric-premises.json').read_text())
box=root/'data/prefix05-box-1000.json'
seed=root/'data/prefix-05.json'
seed_sha='bfc0cc47c5752ba2e182174110182b785106450129af8f024ac88d7ab3e01ba4'
assert sha(seed)==seed_sha==geo['source_sha256']['input_pose_cover']
assert sha(box)==geo['source_sha256']['envelope']==d['seed_sha256']
assert geo['verdict']=='PASS_EXACT_MIXED_SUPPORT_GEOMETRIC_PREMISES'
assert sum(len(q['excluded_features']) for q in geo['pair_checks'].values())==58
assert min(-F(x['gap_upper']) for q in geo['pair_checks'].values() for x in q['excluded_features'])>F(3,1000)
assert d['verdict']=='PASS_MIXED_GLOBAL_ALIGNMENT' and d['anchor_splits']==4 and len(d['checks'])==4
assert all(F('-.1')<F(lo)<=F(hi)<F('.1') for lo,hi in d['angle_offsets'].values())
assert F(d['angle_offsets']['F'][0])>=F('-.014') and F(d['angle_offsets']['F'][1])<=F('.021')
beta=dict(zip(('AB','DE','BD','CD'),map(F,('1/10','1/20','7/100','1/10'))))
deriv=dict(zip(('AB','DE','BD','CD'),map(F,('11/200','9/200','3/50','49/500'))))
gains={k:beta[k]-deriv[k] for k in beta}
assert list(gains.values())==list(map(F,('9/200','1/200','1/100','1/500')))
rows=[]
for i,part in enumerate(d['checks']):
    for edge in beta:
        row=part['stages'][edge];cap=F(row['capacity']);actual=max(abs(F(x)) for x in row['derivative'])
        assert cap>=beta[edge] and actual<=deriv[edge]
        rows.append({'slice':i,'edge':edge,'capacity_margin':str(cap-beta[edge]),'derivative_margin':str(deriv[edge]-actual)})
    assert F(part['bridge_margin'])>F(3,20)
rho=list(map(F,d['mixture_weight_interval']));assert F('.3127')<rho[0]<=rho[1]<F('.3128')
bridge_gain_margin=F(3,40)*(1-F(21,1000)**2/6)-F(7,100)
assert bridge_gain_margin>0
out={'verdict':'PASS_PRINTED_RATIONAL_BOUNDS','tree_checks':rows,'beta':{k:str(v) for k,v in beta.items()},'derivative_upper':{k:str(v) for k,v in deriv.items()},'tree_gains':{k:str(v) for k,v in gains.items()},'bridge_lower_bound':'3/20','bridge_gain':'7/100','bridge_gain_margin':str(bridge_gain_margin),'rho_open_interval':['.3127','.3128'],'original_point_one_chart_satisfied':True,'prefix_rounds':5,'source_sha256':{'prefix':sha(seed),'readable_box':sha(box),'geometric_receipt':sha(root/'results/geometric-premises.json'),'mixed_receipt':sha(a.input)},'scope':'Fresh comparisons with just-replayed feature and four-slice interval checks; the input prefix ancestry remains an external premise.'}
a.output.write_text(json.dumps(out,indent=2)+'\n');print(out['verdict'])
