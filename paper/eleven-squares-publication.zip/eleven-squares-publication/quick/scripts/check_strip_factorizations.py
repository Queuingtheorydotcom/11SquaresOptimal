#!/usr/bin/env python3
"""Check exactly the three positive polynomial forms in strip_section.tex.

Python standard library only; integer coefficients in the independent
variables b and t. This checks identities, not the whole geometric proof.
Run: python3 check_strip_factorizations.py
"""
import hashlib
import json
from pathlib import Path


class Poly:
    """Sparse Z[b,t]; keys are pairs (power of b, power of t)."""

    def __init__(self, value=0):
        terms = value if isinstance(value, dict) else {(0, 0): value}
        self.terms = {key: coefficient for key, coefficient in terms.items()
                      if coefficient != 0}

    @staticmethod
    def coerce(value):
        return value if isinstance(value, Poly) else Poly(value)

    def __add__(self, other):
        terms = self.terms.copy()
        for key, coefficient in self.coerce(other).terms.items():
            terms[key] = terms.get(key, 0) + coefficient
        return Poly(terms)

    __radd__ = __add__

    def __neg__(self):
        return Poly({key: -value for key, value in self.terms.items()})

    def __sub__(self, other):
        return self + (-self.coerce(other))

    def __rsub__(self, other):
        return self.coerce(other) + (-self)

    def __mul__(self, other):
        terms = {}
        for (i, j), x in self.terms.items():
            for (k, l), y in self.coerce(other).terms.items():
                key = (i + k, j + l)
                terms[key] = terms.get(key, 0) + x * y
        return Poly(terms)

    __rmul__ = __mul__

    def __pow__(self, exponent):
        if not isinstance(exponent, int) or exponent < 0:
            raise ValueError("Only nonnegative integer powers are supported")
        result = Poly(1)
        for _ in range(exponent):
            result = result * self
        return result


def main():
    b, t = Poly({(1, 0): 1}), Poly({(0, 1): 1})
    originals = {
        "G": 1 + b**2 + 2*(b-1)*t - (1+2*b-b**2)*t**2,
        "F_plus": (1-b**2)*(b+t) + (2+7*b+6*b**2+b**3)*t**2
                  - (1+2*b)*(1-b**2)*t**3,
        "F_minus": -b*(1-b**2) + (1+b)**3*t
                   - (1+2*b)*(1-b**2)*t**2,
    }
    positive_forms = {
        "G": (1+b**2)*(1-b)**2
             + (b-t)*((1+b**2)*(2-b)+(1+2*b-b**2)*t),
        "F_plus": (1-b**2)*(b+t) + (1+5*b+7*b**2+3*b**3)*t**2
                  + (1+2*b)*(1-b**2)*t**2*(1-t),
        "F_minus": 2*b**2*(1+b)*(1-b+(1+b)*t)
                   + (1+2*b)*(1-b**2)*(t-b)*(1-t),
    }
    domains = {"G": "0 < b < 1 and 0 <= t <= b",
               "F_plus": "0 < b < 1 and 0 <= t <= b",
               "F_minus": "0 < b < 1 and b <= t <= 1"}
    checks = []
    for name, original in originals.items():
        residual = original - positive_forms[name]
        if residual.terms:
            raise ArithmeticError(f"Identity failed: {name}: {residual.terms}")
        checks.append({"name": name, "nonzero_residual_coefficients": 0,
                       "domain_for_positive_form": domains[name]})
    script = Path(__file__).resolve()
    result = {
        "verdict": "PASS", "identities_checked": len(checks),
        "arithmetic": "Exact integer coefficients in Z[b,t]",
        "checks": checks,
        "scope": "Only the three displayed polynomial identities. Positivity on "
                 "the listed domains is explained in the manuscript; the "
                 "geometric reduction and global packing certificates are not "
                 "checked by this script.",
        "checker_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
    }
    output = script.parents[1]/"results/strip-factorizations-result.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(f"PASS: {len(checks)} exact polynomial identities; {output.name}")


if __name__ == "__main__":
    main()
