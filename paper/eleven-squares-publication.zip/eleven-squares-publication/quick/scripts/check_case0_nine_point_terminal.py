"""Check the case-0 nine-point terminal, conditional on stated H12 hulls.

This does not replay those hulls' ancestry and does not read a PASS receipt.
The full fresh ancestry is a separate computation. Standard library only.
"""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Do not run with Python -O')


def serial(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [serial(v) for v in value]
    return value


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    if output.is_relative_to(source):
        raise ValueError('Output must be outside the read-only source')
    sys.path.insert(0, str(source))
    from marker_cases import A_LO, A_HI, S, SYMMETRY_OWNER, all_cases, groups
    from forced_markers import hull, owned_points
    from exact_poses import contains, verify_owner
    start = time.monotonic()
    journal = source/'exploration/journal-case-0-N96.json'
    data = json.loads(journal.read_bytes())
    gs = groups(all_cases()[0][0])
    assert data['case'] == 0 and data['bins'] == 96
    assert data['groups'] == [list(g) for g in gs]
    assert data['symmetry_restricted']
    hs = {g: hull([tuple(map(F, p)) for p in row])
          for g, row in zip(gs, data['history'][12]['hulls'])}
    limits = {SYMMETRY_OWNER[0]: F(5, 12)}
    segment = [(F(97, 50), F(1, 10)), (F(97, 50), F(99, 100))]
    polygon = hull([(F(x, 1000), F(y, 1000)) for x, y in
                    [(1901, 1899), (2103, 1897), (2835, 1926), (2856, 2405),
                     (2835, 2833), (1925, 2833), (1897, 2235)]])
    assert len(polygon) == 7
    assert all(contains(hs[(4,)], p) for p in segment)
    added = [p for p in polygon if not contains(hs[(10,)], p)]
    assert len(added) == 6
    promotion = verify_owner((10,), added, 96, gs, hs, limits)
    reduced = {g: hull(owned_points(g)) for g in gs}
    reduced[(4,)] = segment
    reduced[(10,)] = polygon
    terminal = verify_owner((9,), [], 96, gs, reduced, limits)
    assert terminal['poses'] == 0
    files = [journal, source/'marker_cases.py', source/'forced_markers.py',
             source/'exact_poses.py', Path(__file__)]
    result = {
        'status': 'PASS: CONDITIONAL NINE-POINT CASE-0 TERMINAL',
        'scope': 'Assuming the journal H12 hulls are strictly owned, plus the initial marker ownership/hull premises and specified symmetry normalization, six I2 promotions force a reduced empty I1 pose cover. No H12 ancestry is replayed and no historical PASS record is used. This alone is not a complete case-0 or global proof.',
        'assumed_hull_round_zero_based': 12,
        'assumed_hulls': [{'owner': g, 'hull': hs[g]} for g in gs],
        'side_interval_open': [A_LO, A_HI], 'container': S, 'bins': 96,
        'symmetry_limits': [{'owner': g, 'upper_t': t} for g, t in limits.items()],
        'promotion': promotion, 'terminal': terminal,
        'terminal_owned_hulls': {'W0_label4': segment, 'I2_label10': polygon},
        'elapsed_seconds': time.monotonic()-start,
        'source_sha256': {str(p.relative_to(source)) if p.is_relative_to(source) else p.name:
                          hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(serial(result), indent=2)+'\n')
    print(json.dumps({k: result[k] for k in ('status', 'elapsed_seconds')}), flush=True)


if __name__ == '__main__':
    main()
