#!/usr/bin/env python3
"""Fresh exact foundational checks, with all outputs outside the source archive.

Published nonavoidance lemmas, the ownership argument, and the stated
separating-axis theorem are mathematical premises, not machine proofs here.
No prior receipt or saved PASS is read.
"""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
from fractions import Fraction as F
import argparse, contextlib, hashlib, importlib.util, io, json, time

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def main():
    need(__debug__, 'Run without Python -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    source, output = a.source.resolve(), a.output.resolve()
    need(not output.is_relative_to(source), 'Outputs must be outside the source archive')
    files = ['marker_cases.py', 'forced_markers.py', 'verify_reduction.py',
             'corner_markers.py', 'local_data/exact_local.py']
    hashes = {name: sha(source/name) for name in files}
    started = time.time()
    sys.path.insert(0, str(source))
    reduction = module('verify_reduction', source/'verify_reduction.py')
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        reduction.main()
    arithmetic = json.loads(printed.getvalue())
    need(arithmetic['triangles'] == 14 and len(arithmetic['remaining_cases']) == 7,
         'Unexpected marker reduction')
    corners = module('corner_markers', source/'corner_markers.py').verify()
    need(len(corners['vertices']) == 7, 'Unexpected corner cover inventory')
    e = module('fresh_foundation_geometry', source/'local_data/exact_local.py')
    walls, contacts = e.geometry()
    lower = F('3.87708359002281417730789706010096')
    upper = lower + F(1, 10**32)
    lo, hi = e.L.interval()
    need(lower < lo <= hi < upper, 'The two algebraic target descriptions differ')
    optimum_side = F(97, 25)/e.L
    need((optimum_side-F(4003, 4000)).sign() > 0 and
         (F(25019, 25000)-optimum_side).sign() > 0,
         'Construction does not fit the strict normalization bracket')
    need(len(walls) == 20 and len(contacts) == 14, 'Unexpected reference geometry')
    need(hashes == {name: sha(source/name) for name in files}, 'Source changed during replay')
    result = {
        'verdict': 'PASS_FRESH_FOUNDATIONAL_ARITHMETIC_AND_CONSTRUCTION',
        'source_sha256': hashes,
        'checker_sha256': sha(Path(__file__)),
        'marker_reduction': arithmetic,
        'corner_markers': corners,
        'construction': {'vertices': 44, 'square_pairs': 55,
                         'target_polynomial_identity': True,
                         'matching_root_interval': [str(lower), str(upper)],
                         'normalization_bracket_strict': True},
        'accepted_claims': [
            'Arithmetic hypotheses of the cited marker nonavoidance lemmas',
            'Eight symmetry cases, with the stated geometric opposite-pair exclusion leaving seven',
            'Arithmetic hypotheses for initial inner/wall and seven corner compulsory points',
            'Attaining eleven-square construction and identification of its algebraic side',
            'Strict rational normalization bracket for a hypothetical improvement'],
        'mathematical_premises': [
            'Stromquist rectangle, triangle and wall-quadrilateral nonavoidance lemmas',
            'Displayed ownership counting, symmetry, moving-marker and opposite-pair arguments',
            'Separating-axis characterization of interior-disjoint squares',
            'Reviewed exact polynomial and rational arithmetic implementations'],
        'scope': 'Foundation only; no numerical ownership exclusion or global capture ancestry is imported or claimed.',
        'elapsed_seconds': time.time()-started,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2)+'\n')
    print(result['verdict'], flush=True)

if __name__ == '__main__':
    main()
