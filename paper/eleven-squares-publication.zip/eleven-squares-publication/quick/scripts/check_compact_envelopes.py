#!/usr/bin/env python3
"""Exact, read-only extraction of compact separator envelopes.

This checks rational enclosures against two archived pose covers and checks
all constants in SIMPLIFIED_SEPARATORS.md. It does not replay the ancestry
that establishes those covers globally. No source modules are imported.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json

S, A_LO, A_HI = F(97,25), F(4003,4000), F(25019,25000)

def normal(t):
    return (1-t*t)/(1+t*t), 2*t/(1+t*t)

def dot(n,p):
    return n[0]*p[0]+n[1]*p[1]

def centers_and_outer_vertices(d, own):
    H=A_HI*(1+F(1,d['bins']))/2
    centers=[]; whole=[]
    for p in d['owners'][own]:
        c,s=F(p['c']),F(p['s'])
        if (c,s) != normal(F(2*p['k']+1,2*d['bins'])):
            raise ArithmeticError('Unexpected midpoint direction')
        for u,v in p['poly']:
            x,y=c*F(u)-s*F(v),s*F(u)+c*F(v)
            centers.append((x,y))
            for i in [-1,1]:
                for j in [-1,1]:
                    whole.append((x+H*(i*c-j*s),y+H*(i*s+j*c)))
    return centers,whole

def check_box(points,box):
    lo_x,hi_x,lo_y,hi_y=map(F,box)
    margins=[min(x-lo_x for x,y in points),min(hi_x-x for x,y in points),
             min(y-lo_y for x,y in points),min(hi_y-y for x,y in points)]
    if min(margins)<0:
        raise ArithmeticError(('Box failed',box,list(map(str,margins))))
    return {'box':list(map(str,[lo_x,hi_x,lo_y,hi_y])),
            'minimum_margin':str(min(margins)),'vertices':len(points)}

def check_angle(d,own,lo,hi,fold=False):
    observed=[]
    for p in d['owners'][own]:
        a,b=F(p['k'],d['bins']),F(p['k']+1,d['bins'])
        if fold and a>=F(1,2):
            a,b=(a-1)/(a+1),(b-1)/(b+1)
        if not lo<=a<=b<=hi:
            raise ArithmeticError(('Angle envelope failed',own,a,b,lo,hi))
        observed += [a,b]
    return {'half_angle_interval':[str(lo),str(hi)],
            'observed_extrema':[str(min(observed)),str(max(observed))],
            'fold_modulo_right_angle':fold}


def main():
    default=Path(__file__).resolve().parents[1]/'source'
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,default=default)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('compact-envelopes-result.json'))
    args=parser.parse_args();base=args.source
    names={'column':'exploration/seven-spatial-bounds-certified-seed.json',
           'second_corner':'exploration/inner-obstruction-certified-seed.json'}
    src={k:json.loads((base/v).read_text()) for k,v in names.items()}
    d=src['column']
    if d['global_spatial_bounds']!='spatial-bounds-v4-verification.json':
        raise ArithmeticError('Unexpected seven-bound premise')
    rr,rw=centers_and_outer_vertices(d,9)
    qc,qw=centers_and_outer_vertices(d,6)
    pc,pw=centers_and_outer_vertices(d,2)
    column={'R_box':check_box(rr,['2.49','2.63','2.34','2.495']),
            'Q_box':check_box(qc,['3.23','3.38','1.485','1.62']),
            'R_angles':check_angle(d,9,F(1,4),F(1,2)),
            'Q_angles':check_angle(d,6,-F(2,11),F(1,16),True)}
    strip_line=S-F(7,4)*A_LO
    column['strip_checks']=[]
    for own,points in [(2,pw),(6,qw)]:
        margin=min(x for x,y in points)-strip_line
        if margin<=0:raise ArithmeticError(('Strip failed',own,margin))
        column['strip_checks'].append({'owner':own,'whole_square_x_lower':str(min(x for x,y in points)),
                                      'required_x_lower':str(strip_line),'margin':str(margin)})
    column['support_checks']=[]
    for t,r_low,p_high in [(F(1,4),F('0.876'),F('-0.032')),
                            (F(1,2),F('-0.648'),F('-1.153'))]:
        c,s=normal(t);n=(-s,c)
        r_actual=min(dot(n,z) for z in rr);p_actual=max(dot(n,z) for z in pw)
        if r_actual<r_low or p_actual>p_high:
            raise ArithmeticError(('Support envelope failed',t,r_actual,p_actual))
        column['support_checks'].append({'normal':list(map(str,n)),
            'R_center_lower':str(r_low),'P_whole_upper':str(p_high),
            'R_slack':str(r_actual-r_low),'P_slack':str(p_high-p_actual),
            'resulting_margin_beyond_half_side':str(r_low-p_high-F(1001,2000))})
    corner=src['second_corner'];pc,_=centers_and_outer_vertices(corner,3);qc,_=centers_and_outer_vertices(corner,9)
    second={'P_box':check_box(pc,['2.89','3.38','2.90','3.38']),
            'Q_box':check_box(qc,['2.45','2.67','2.35','2.51']),
            'P_angles':check_angle(corner,3,-F(1,16),F(5,48),True),
            'Q_angles':check_angle(corner,9,F(3,32),F(19,32))}

    # Every assertion below is one scalar inequality used in the proofs.
    checks=[]
    def positive(name,value):
        if value<=0:raise ArithmeticError((name,str(value)))
        checks.append({'name':name,'positive_margin':str(value)})
    # Column: relative angles are between theta0-alpha and theta1+beta.
    c0,s0=normal(F(1,4));c1,s1=normal(F(1,2))
    ca,sa=normal(F(1,16));cb,sb=normal(F(2,11))
    g_lo=(c0*ca+s0*sa)+(s0*ca-c0*sa)
    g_hi=(c1*cb-s1*sb)+(s1*cb+c1*sb)
    if g_hi!=F(31,25):raise ArithmeticError('Unexpected endpoint identity')
    positive('column lower relative angle positive',s0*ca-c0*sa)
    positive('column upper relative angle below pi/2',c1*cb-s1*sb)
    positive('column lower-end g exceeds 31/25',g_lo-F(31,25))
    positive('column support threshold exceeds R-edge bound',F(28,25)-F('1.01'))
    positive('column positive Q-angle endpoint is maximum',F('.89')*ca-F('1.01')*sa)
    positive('column positive Q-normal overlap',F(28,25)-(F('.89')*sa+F('1.01')*ca))
    L,M=F('1.39'),F('1.01')
    positive('column wall support increasing',cb*(M-F(1,2))-sb*(L-cb))
    positive('column negative Q-edge overlap',F(28,25)-(L*cb+M*sb-cb*(cb+sb)/2))
    positive('column strip height slack',F(16,9)-F(7,4))
    positive('column corner horizontal strip margin',F(1,2)-F('.495'))
    # Second corner: exclude the mixed-sign normals of both squares.
    cq0,sq0=normal(F(3,32));cq1,sq1=normal(F(19,32))
    positive('corner Q mixed normal first endpoint',1-(F('1.03')*cq0-F('.22')*sq0))
    positive('corner Q mixed normal second endpoint',1-(F('.93')*sq1-F('.39')*cq1))
    cp,sp=normal(F(5,48));ce,se=normal(F(1,40))
    positive('corner positive angle below pi/8',(cp*cp-sp*sp)-2*cp*sp)
    positive('corner wall support after split',1-(F('1.53')*ce-F('.22')*se-ce*(ce+se)/2))
    g0=(cq0*ce+sq0*se)+(sq0*ce-cq0*se)
    positive('corner small angle relative angle positive',sq0*ce-cq0*se)
    positive('corner small angle lower endpoint g',g0-F(11,10))
    positive('corner small angle upper endpoint g',cq1+sq1-F(11,10))
    positive('corner small angle radius beats projection',F(21,20)-F('1.03'))
    result={'verdict':'PASS compact envelope and scalar checks',
        'column':column,'second_corner':second,'scalar_checks':checks,
        'source_hashes':{v:hashlib.sha256((base/v).read_bytes()).hexdigest() for v in names.values()},
        'scope':'Fresh exact rational extraction from the named archived pose covers. '
                'The geometry is proved in SIMPLIFIED_SEPARATORS.md. No global '
                'ancestry replay, geometric search, or Lean verification is claimed.'}
    out=args.output;out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['verdict']);print(len(checks),'scalar inequalities;',out.name)

if __name__=='__main__':main()
