"""Exact univariate arithmetic for the two common-angle support cycles."""
from fractions import Fraction as F
from functools import reduce
from math import gcd,lcm,comb
from pathlib import Path
import json, argparse
if not __debug__: raise RuntimeError('Do not run with Python -O')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=Path(__file__).with_name('support-algebra.json'))
args=parser.parse_args()

def trim(p):
 p=list(map(F,p))
 while len(p)>1 and p[-1]==0:p.pop()
 return p
def add(p,q):return trim([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def neg(p):return [-x for x in p]
def mul(p,q):
 out=[F(0)]*(len(p)+len(q)-1)
 for i,x in enumerate(p):
  for j,y in enumerate(q):out[i+j]+=x*y
 return trim(out)
def divrem(p,q):
 p=trim(p);q=trim(q);v=[F(0)]*max(1,len(p)-len(q)+1)
 while p!=[0] and len(p)>=len(q):
  k=len(p)-len(q);a=p[-1]/q[-1];v[k]=a;p=add(p,neg([0]*k+[a*x for x in q]))
 return trim(v),p
def pgcd(p,q):
 while q!=[0]:p,q=q,divrem(p,q)[1]
 return [x/p[-1] for x in p]
class R:
 def __init__(self,p=0,q=1):
  if isinstance(p,R):self.p,self.q=p.p,p.q;return
  if isinstance(p,(int,F)):p=[p]
  if isinstance(q,(int,F)):q=[q]
  p,q=trim(p),trim(q);d=pgcd(p,q);p=divrem(p,d)[0];q=divrem(q,d)[0]
  k=lcm(*(x.denominator for x in p+q));p=[int(x*k) for x in p];q=[int(x*k) for x in q]
  k=reduce(gcd,p+q);k*=1 if q[-1]>0 else -1
  self.p=[F(x,k) for x in p];self.q=[F(x,k) for x in q]
 def __add__(self,y):
  y=R(y);return R(add(mul(self.p,y.q),mul(y.p,self.q)),mul(self.q,y.q))
 __radd__=__add__
 def __neg__(self):return R(neg(self.p),self.q)
 def __sub__(self,y):return self+-R(y)
 def __rsub__(self,y):return R(y)+-self
 def __mul__(self,y):
  y=R(y);return R(mul(self.p,y.p),mul(self.q,y.q))
 __rmul__=__mul__
 def __truediv__(self,y):
  y=R(y);return R(mul(self.p,y.q),mul(self.q,y.p))
 def __rtruediv__(self,y):return R(y)/self
 def __pow__(self,k):
  out=R(1)
  for _ in range(k):out=out*self
  return out
 def diff(self):return R(add(mul([i*x for i,x in enumerate(self.p)][1:],self.q),neg(mul(self.p,[i*x for i,x in enumerate(self.q)][1:]))),mul(self.q,self.q))
 def data(self):return {'numerator':[str(x) for x in self.p],'denominator':[str(x) for x in self.q]}
 def __repr__(self):return str(self.data())

u=R([0,1]);c=(1-u*u)/(1+u*u);s=2*u/(1+u*u);w=c+s
f1=2+(2+s)/w
den=1+c**3/s+s/c
num=c*w/(2*s)+c*c+2*c**3/s+F(3,2)*c*c/s+2*c+s/(2*c)+s*s/c*(2+F(3,2)*w)+s*(1+w)/2+w/2
f2=num/den
delta=f2-f1
P=[-1,2,2,-6,12,14,-2,-10,5]
print('f1',f1)
print('f2',f2)
print('delta',delta)
print('difference numerator / endpoint polynomial',divrem(delta.p,P))
print('df1',f1.diff())
print('df2',f2.diff())
out={'f1':f1.data(),'f2':f2.data(),'difference':delta.data(),'df1':f1.diff().data(),'df2':f2.diff().data()}
def bernstein(p,a,b):
 n=len(p)-1
 q=[sum(p[k]*comb(k,j)*a**(k-j)*(b-a)**j for k in range(j,n+1)) for j in range(n+1)]
 return [sum(q[j]*F(comb(k,j),comb(n,j)) for j in range(k+1)) for k in range(n+1)]
domain=(F(5,16),F(5,12))
signs={name:bernstein(poly,*domain) for name,poly in [('f1_derivative',f1.diff().p),('f2_derivative',f2.diff().p),('f2_denominator',f2.q)]}
assert all(x>0 for x in signs['f1_derivative'])
assert all(x<0 for x in signs['f2_derivative'])
assert all(x>0 for x in signs['f2_denominator'])
assert divrem(delta.p,P)==([F(0),F(2)],[F(0)])
out['exact_bernstein_sign_checks']={name:[str(x) for x in values] for name,values in signs.items()}
out['domain']=[str(x) for x in domain]
out['scope']='Only the two common-angle support-cycle algebraic formulas and monotonicity are verified; selected separation families and angle alignment remain geometric hypotheses.'
args.output.write_text(json.dumps(out,indent=2)+'\n')
print('PASS exact support-cycle identity and monotonicity checks')
