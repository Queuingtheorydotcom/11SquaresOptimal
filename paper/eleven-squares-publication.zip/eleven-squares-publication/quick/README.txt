Eleven squares: quick proof checks

Tested with CPython 3.12.4 using only its standard library.

  python3 run_all.py --verify-only
  python3 run_all.py --optional --jobs 2

The optional flag includes all thirteen checks, including the local and
capture backup certificates. These checks establish the stated foundational,
local, and conditional implications. They do not replay the global ancestry;
use the parent package's verify.py --full for that complete execution plan.

Only code, mathematical certificate inputs, and the manuscript are shipped.
New run receipts and logs are written under results/. No saved PASS result is
imported by a mathematical check. The manifests bind each distributed file.
