"""Exact field geometry and rigorous local-optimality certificate verification.
Only Python's standard library is needed for verification.
"""
from fractions import Fraction as F
from itertools import product,combinations
from pathlib import Path
import json
# 5u^8-10u^7-2u^6+14u^5+12u^4-6u^3+2u^2+2u-1
MOD=list(map(F,[-1,2,2,-6,12,14,-2,-10,5]))
class K:
 def __init__(self,x=0):self.a=tuple(x) if isinstance(x,(tuple,list)) else (F(x),)+(F(0),)*7
 def __add__(x,y):
  y=cast(y);return K(tuple(a+b for a,b in zip(x.a,y.a)))
 __radd__=__add__
 def __neg__(x):return K(tuple(-a for a in x.a))
 def __sub__(x,y):return x+-cast(y)
 def __rsub__(x,y):return cast(y)+-x
 def __mul__(x,y):
  y=cast(y);a=[F(0)]*15
  for i,b in enumerate(x.a):
   for j,c in enumerate(y.a):a[i+j]+=b*c
  for i in range(14,7,-1):
   for j in range(8):a[i-8+j]-=a[i]*MOD[j]/5
  return K(a[:8])
 __rmul__=__mul__
 def inv(x):
  cols=[(x*K([F(int(i==j)) for i in range(8)])).a for j in range(8)]
  A=[[cols[j][i] for j in range(8)]+[F(i==0)] for i in range(8)]
  for k in range(8):
   p=next(i for i in range(k,8) if A[i][k]);A[k],A[p]=A[p],A[k];v=A[k][k];A[k]=[z/v for z in A[k]]
   for i in range(8):
    if i!=k:
     v=A[i][k];A[i]=[a-v*b for a,b in zip(A[i],A[k])]
  return K([A[i][-1] for i in range(8)])
 def __truediv__(x,y):return x*cast(y).inv()
 def __rtruediv__(x,y):return cast(y)*x.inv()
 def zero(x):return not any(x.a)
 def interval(x):
  lo=hi=F(0)
  for a in x.a[::-1]:
   vals=[lo*UL,lo*UH,hi*UL,hi*UH];lo,hi=min(vals)+a,max(vals)+a
  return lo,hi
 def sign(x):
  if x.zero():return 0
  lo,hi=x.interval()
  assert lo>0 or hi<0,('root interval insufficient',lo,hi)
  return 1 if lo>0 else -1
 def __float__(x):
  lo,hi=x.interval();return float((lo+hi)/2)
def cast(x):return x if isinstance(x,K) else K(x)
def poly(t):
 r=F(0)
 for c in MOD[::-1]:r=r*t+c
 return r
# Derivative positive on [0.36,0.37], checked by rational interval Horner.
def pint(coeff,lo,hi):
 a=b=F(0)
 for c in coeff[::-1]:
  vs=[a*lo,a*hi,b*lo,b*hi];a,b=min(vs)+c,max(vs)+c
 return a,b
UL,UH=F(36,100),F(37,100)
assert poly(UL)<0<poly(UH)
assert pint([i*MOD[i] for i in range(1,9)],UL,UH)[0]>0
for _ in range(220):
 m=(UL+UH)/2
 if poly(m)<0:UL=m
 else:UH=m
U=K([F(0),F(1)]+[F(0)]*6);C=(1-U*U)/(1+U*U);S=2*U/(1+U*U);L=(4+6*U)/(1+2*U-U*U)
assert (C*C+S*S-1).zero()
P_L=K(0)
for coeff in [1,-20,178,-842,1923,-496,-6754,12420,-6865]:P_L=P_L*L+coeff
assert P_L.zero()
x0=1+2/C-(L-2)*S/C;r=1-(L-3)*C;u=((1+r)*C-1)/S;v=C-S;w=(L-1)/S-r-(3+u)*C/S
centers=[(K(F(1,2)),K(F(1,2))),(L-F(1,2),K(F(1,2))),(x0+F(1,2),L-F(1,2)),(K(F(1,2)),L-F(1,2)),(K(F(3,2)),L-F(1,2)),(K(F(1,2)),L-F(3,2))]
for x,y in [(0,0),(u,-1),(1,v),(1+u,v-1),(2+u,-w)]:
 xx=x+F(1,2);yy=y+F(1,2)-r;centers.append((1+xx*C-yy*S,1+xx*S+yy*C))
cs=[(K(1),K(0))]*6+[(C,S)]*5

def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def rot(a):return (-a[1],a[0])
def offsets(i):
 c,s=cs[i]
 return [((a*c-b*s)/2,(a*s+b*c)/2) for a,b in product([-1,1],repeat=2)]
def row():return [K(0) for _ in range(34)]

def geometry():
 walls=[];choices=[]
 for i in range(11):
  for V in offsets(i):
   for k in range(2):
    for side in [0,1]:
     sg=1 if side==0 else -1;val=sg*(centers[i][k]+V[k])+(L if side else 0)
     assert val.sign()>=0
     if val.zero():
      J=row();J[3*i+k]=K(sg);J[3*i+2]=sg*rot(V)[k];J[-1]=K(side);walls.append(J)
 for i,j in combinations(range(11),2):
  delta=tuple(centers[j][k]-centers[i][k] for k in range(2));branches=[];strict=False
  for owner,axisid in product([i,j],[0,1]):
   other=j if owner==i else i;axis=cs[owner] if axisid==0 else rot(cs[owner]);sg=dot(delta,axis).sign()
   vals=[];rows=[]
   for V in offsets(other):
    val=sg*dot(delta,axis)-F(1,2)-dot(V,axis);vals.append(val)
    J=row()
    for k in range(2):J[3*i+k]=-sg*axis[k];J[3*j+k]=sg*axis[k]
    J[3*owner+2]=sg*dot(delta,rot(axis))-dot(V,rot(axis))
    J[3*other+2]=J[3*other+2]-dot(rot(V),axis)
    rows.append(J)
   signs=[x.sign() for x in vals]
   if min(signs)>0:strict=True
   elif min(signs)==0:branches.append((2*(owner==j)+axisid,[J for x,J in zip(vals,rows) if x.zero()]))
  assert strict or branches,('overlap',i,j)
  if not strict:choices.append((i,j,branches))
 return walls,choices

SCALE=10**35
# A rational enclosure: |x - integer/SCALE| <= 1/SCALE.
def integer_enclosure(x):
 lo,hi=x.interval();z=(lo*SCALE).__floor__();assert hi*SCALE<=z+1
 return z

def matrices():
 walls,choices=geometry();iw=[[integer_enclosure(x) for x in r] for r in walls]
 bs=[[(b,[[integer_enclosure(x) for x in r] for r in rows]) for b,rows in opts] for i,j,opts in choices]
 return iw,bs

def verify(path):
 cert=json.loads(Path(path).read_text());iw,bs=matrices();assert cert['scale']==SCALE
 count=1
 for b in bs:count*=len(b)
 assert len(cert['cones'])==count
 # Every rational inverse/multiplier uses the same denominator Q.
 Q=cert['denominator'];worst=F(0);least=None
 for num,selection in enumerate(product(*bs)):
  entry=cert['cones'][num];assert entry['choices']==[b for b,rows in selection]
  J=iw+[r for b,rows in selection for r in rows];m=len(J);W=entry['weights'];R=entry['right_inverse'];assert len(W)==m and len(R)==m and all(len(r)==34 for r in R)
  # A=J^T, b=e_L. Bound true A's difference from the stored rational matrix by 1/SCALE.
  rnorm=F(max(sum(abs(x) for x in r) for r in R),Q)
  erows=[];rho=F(0)
  for i in range(34):
   rowerr=0
   for j in range(34):
    raw=sum(J[k][i]*R[k][j] for k in range(m))-(SCALE*Q if i==j else 0)
    rowerr+=abs(raw)+sum(abs(R[k][j]) for k in range(m))
   erows.append(F(rowerr,SCALE*Q))
   raw=(SCALE*Q if i==33 else 0)-sum(J[k][i]*W[k] for k in range(m))
   rho=max(rho,F(abs(raw)+sum(abs(x) for x in W),SCALE*Q))
  eta=max(erows);assert eta<1
  correction=rnorm*rho/(1-eta);minimum=F(min(W),Q)-correction
  assert minimum>0,(num,float(minimum))
  worst=max(worst,eta);least=minimum if least is None else min(least,minimum)
 print(json.dumps(dict(result='VERIFIED strict local minimum',cones=count,contact_pairs=len(bs),wall_rows=len(iw),L=float(L),max_inverse_error_bound=float(worst),min_positive_stress_bound=float(least)),indent=2))
if __name__=='__main__':
 import sys
 if len(sys.argv)>1:verify(sys.argv[1])
 else:
  walls,bs=geometry();print(float(L),len(walls),[(i,j,[b for b,rows in opts]) for i,j,opts in bs])
