"""Exact rational replay of compulsory-point proposals. Standard library only."""
from fractions import Fraction as F
import json,sys,time,hashlib,argparse
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from marker_cases import POINTS,S,A_LO,A_HI,all_cases,groups,SYMMETRY_OWNER
from forced_markers import owned_points,hull,cross

def area2(p):return sum(p[i][0]*p[(i+1)%len(p)][1]-p[i][1]*p[(i+1)%len(p)][0] for i in range(len(p))) if len(p)>2 else F(0)
def clean(p):
    out=[]
    for x in p:
        if not out or x!=out[-1]:out.append(x)
    if len(out)>1 and out[0]==out[-1]:out.pop()
    return out
def clip(poly,n,d):
    if not poly:return []
    out=[];prev=poly[-1];a=n[0]*prev[0]+n[1]*prev[1]-d
    for p in poly:
        b=n[0]*p[0]+n[1]*p[1]-d
        if (a<=0)!=(b<=0):
            f=a/(a-b);out.append((prev[0]+f*(p[0]-prev[0]),prev[1]+f*(p[1]-prev[1])))
        if b<=0:out.append(p)
        prev=p;a=b
    return clean(out)

def subtract_rect(poly,x0,x1,y0,y1):
    if not poly:return []
    xx=[p[0] for p in poly];yy=[p[1] for p in poly]
    if max(xx)<=x0 or min(xx)>=x1 or max(yy)<=y0 or min(yy)>=y1:return [poly]
    out=[]
    for n,d in [((1,0),x0),((-1,0),-x1)]:
        p=clip(poly,n,d)
        if area2(p)>0:out.append(p)
    mid=clip(clip(poly,(-1,0),-x0),(1,0),x1)
    for n,d in [((0,1),y0),((0,-1),-y1)]:
        p=clip(mid,n,d)
        if area2(p)>0:out.append(p)
    return out

def subtract_convex(poly,forbidden):
    out=[];rem=poly
    for a,b in zip(forbidden,forbidden[1:]+forbidden[:1]):
        n=(b[1]-a[1],a[0]-b[0]);d=n[0]*a[0]+n[1]*a[1]
        pp=clip(rem,(-n[0],-n[1]),-d)
        if area2(pp)>0:out+=pp
        rem=clip(rem,n,d)
        if not rem:break
    return hull(out) if out else []

def pose_bin(ids,N,k,gs,hs,limits=None):
    if limits is not None and ids in limits and F(k,N)>=limits[ids]:return F(1),F(0),F(0),[]
    t0=F(k,N);t1=F(k+1,N);t=(t0+t1)/2
    c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
    transform=lambda p:(c*p[0]+s*p[1],-s*p[0]+c*p[1])
    owned=[transform(p) for p in hs[ids]];uv=[transform(p) for p in POINTS]
    q=1+F(1,N);H=A_HI*q/2;h=A_LO/(2*q)
    x0=max(x-H for x,y in owned);x1=min(x+H for x,y in owned)
    y0=max(y-H for x,y in owned);y1=min(y+H for x,y in owned)
    if x0>=x1 or y0>=y1:return c,s,h,[]
    poly=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
    w=lambda t:(1+2*t-t*t)/(1+t*t)
    wall=A_LO*min(w(t0),w(t1))/2
    for n,d in [((c,-s),S-wall),((-c,s),-wall),((s,c),S-wall),((-s,-c),-wall)]:poly=clip(poly,n,d)
    polys=[poly] if area2(poly)>0 else []
    for j in range(12):
        if j not in ids:
            x,y=uv[j];polys=[part for p in polys for part in subtract_rect(p,x-h,x+h,y-h,y+h)]
    for g in gs:
        if g==ids:continue
        hu=[transform(p) for p in hs[g]]
        forbidden=hull([(x+dx*h,y+dy*h) for x,y in hu for dx,dy in [(-1,-1),(-1,1),(1,-1),(1,1)]])
        polys=[part for p in polys if (part:=subtract_convex(p,forbidden))]
        if not polys:break
    return c,s,h,polys

def contains(poly,p):
    if len(poly)==1:return p==poly[0]
    if len(poly)==2:return cross(poly[0],poly[1],p)==0 and all(min(a,b)<=x<=max(a,b) for a,b,x in zip(poly[0],poly[1],p))
    return all(cross(poly[i],poly[(i+1)%len(poly)],p)>=0 for i in range(len(poly)))

def verify_owner(ids,newpoints,N,gs,hs,limits=None):
    start=time.time();count=0
    for k in range(N):
        c,s,h,polys=pose_bin(ids,N,k,gs,hs,limits)
        for poly in polys:
            count+=1
            xs=[p[0] for p in poly];ys=[p[1] for p in poly]
            lox,hix=max(xs)-h,min(xs)+h;loy,hiy=max(ys)-h,min(ys)+h
            for p in newpoints:
                x=c*p[0]+s*p[1];y=-s*p[0]+c*p[1]
                assert lox<=x<=hix and loy<=y<=hiy,('point not certified',ids,k,tuple(map(str,p)))
    return {'group':ids,'points':len(newpoints),'poses':count,'seconds':time.time()-start}

def owner_task(args):return verify_owner(*args)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('journal');ap.add_argument('--jobs',type=int,default=1);args=ap.parse_args()
    path=Path(args.journal);raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest();data=json.loads(raw);N=data['bins'];gs=groups(all_cases()[0][data['case']]);hs={g:hull(owned_points(g)) for g in gs};results=[]
    limits={SYMMETRY_OWNER[data['case']]:F(5,12)} if data.get('symmetry_restricted') else None
    for rnd,entry in enumerate(data['history']):
        new={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,entry['hulls'])}
        tasks=[]
        for g in gs:
            pp=[p for p in new[g] if not contains(hs[g],p)]
            if pp:
                tasks.append((g,pp,N,gs,hs,limits))
        if args.jobs>1:
            with ProcessPoolExecutor(max_workers=args.jobs) as pool:rr=list(pool.map(owner_task,tasks))
        else:rr=[owner_task(t) for t in tasks]
        for r in rr:r['round']=rnd;results.append(r);print(r,flush=True)
        hs=new
        Path(str(path)+'.verified-prefix.json').write_text(json.dumps({'journal_sha256':digest,'completed_round':rnd,'checks':results,'scope':'Only the stated compulsory-point implications have been replayed.'},indent=2))
    if data.get('terminal_group') is not None:
        g=tuple(data['terminal_group']);assert g in gs
        r=verify_owner(g,[],N,gs,hs,limits);assert r['poses']==0
        verdict={'verdict':'VERIFIED CASE EXCLUSION','case':data['case'],'journal_sha256':digest,'terminal_group':g,'rounds':len(data['history']),'symmetry_restricted':bool(limits),'checks':results}
        Path(str(path)+'.verified-exclusion.json').write_text(json.dumps(verdict,indent=2))
        print('VERIFIED CASE EXCLUSION',data['case'],flush=True)
    else:print('VERIFIED compulsory hull ancestry; no case exclusion asserted',flush=True)

if __name__=='__main__':main()
