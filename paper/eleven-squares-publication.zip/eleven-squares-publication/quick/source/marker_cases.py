"""Exact combinatorial reduction, conditional on the twelve-marker cover."""
from fractions import Fraction as F
from itertools import combinations
import json

S=F(97,25); m=S/2; d=F(7,20); b=F(3,4)
POINTS=[(F(1),F(1)),(S-1,F(1)),(S-1,S-1),(F(1),S-1),
        (m,b),(S-b,m),(m,S-b),(b,m),
        (m-d,m-d),(m+d,m-d),(m+d,m+d),(m-d,m+d)]
A_LO=F(4003,4000) # 1.00075
A_HI=F(25019,25000) # 1.00076
SYMMETRY_OWNER={0:(8,),1:(6,),2:(10,),4:(0,8),6:(8,9)}

def transformations():
    ans=[]
    for flip in [False,True]:
        for k in range(4):
            row=[]
            for x,y in POINTS:
                if flip:x,y=y,x
                for _ in range(k):x,y=S-y,x
                row.append(POINTS.index((x,y)))
            ans.append(row)
    return ans

PERMS=transformations()
def canon(indices):return min(tuple(sorted(p[i] for i in indices)) for p in PERMS)
def all_cases():
    singles=sorted(set(canon((i,)) for i in range(12)))
    pairs=[]
    for i,j in combinations(range(12),2):
        r=sum((x-y)**2 for x,y in zip(POINTS[i],POINTS[j]))
        if r<2*A_HI*A_HI:pairs.append((i,j))
    cp=sorted(set(canon(p) for p in pairs))
    return ([{'kind':'unused','indices':list(p)} for p in singles]+
            [{'kind':'pair','indices':list(p)} for p in cp]),pairs

def groups(case):
    ids=case['indices']
    if case['kind']=='unused':return [(i,) for i in range(12) if i not in ids]
    return [tuple(ids)]+[(i,) for i in range(12) if i not in ids]

if __name__=='__main__':
    cases,pairs=all_cases()
    result={'container':str(S),'side_interval':[str(A_LO),str(A_HI)],
            'points':[[str(x),str(y)] for x,y in POINTS],
            'diameter_admissible_pairs':pairs,'cases':cases,
            'scope':'Necessary finite classification; no geometric case is excluded by this script.'}
    print(json.dumps(result,indent=2))
