"""Rational points supplied by explicit alternative triangulated covers.

Inner singleton: move its marker in a fixed pentagonal star. Boundary
singleton: move the side marker and retain the two boundary quadrilaterals.
The assumptions and their verification are recorded in the research note.
"""
from fractions import Fraction as F
from marker_cases import POINTS,S

def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(ps):
    ps=sorted(set(ps));lo=[];hi=[]
    if len(ps)<2:return ps
    for p in ps:
        while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
        lo.append(p)
    for p in reversed(ps):
        while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
        hi.append(p)
    return lo[:-1]+hi[:-1]

def rotate(p,k):
    x,y=p
    for _ in range(k):x,y=S-y,x
    return x,y

def inner_hull():
    star=[POINTS[i] for i in [0,4,9,11,7]]
    cand=[]
    for ix in range(120,181):
        for iy in range(120,181):
            p=F(ix,100),F(iy,100)
            if all(sum((a-b)**2 for a,b in zip(p,q))<=1 for q in star) and all(cross(star[i],star[(i+1)%5],p)>=0 for i in range(5)):cand.append(p)
    return hull(cand)

INNER=inner_hull()
WALL=[(F(97,50),F(33,50)),(F(97,50),F(41,50)),(F(48,25),F(37,50)),(F(49,25),F(37,50))]

def owned_points(ids):
    ans=[POINTS[i] for i in ids]
    if len(ids)!=1:return ans
    i=ids[0]
    if i>=8:ans+= [rotate(p,i-8) for p in INNER]
    elif i>=4:ans+= [rotate(p,i-4) for p in WALL]
    return list(set(ans))

if __name__=='__main__':
    print('Inner forced hull:',[[str(x),str(y)] for x,y in INNER])
    print('Wall forced points:',[[str(x),str(y)] for x,y in WALL])
