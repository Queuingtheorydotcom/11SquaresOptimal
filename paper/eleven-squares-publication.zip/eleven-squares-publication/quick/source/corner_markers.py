"""Stronger compulsory corner polygons from seven alternative marker covers.

Only singleton corner owners get these points. Each alternative cover moves
one corner marker and keeps all eleven others fixed. The modified corner
rectangle has sides at most A_LO; its two wall quadrilaterals are checked
after scaling by their respective corner-end heights.
"""
from fractions import Fraction as F
from pathlib import Path
import json
from marker_cases import POINTS,S,A_LO
from forced_markers import hull,rotate
from verify_reduction import quad_check,check_triangles

CORNER=[(F(489,500),A_LO),(F(981,1000),F(997,1000)),
 (F(493,500),F(991,1000)),(F(991,1000),F(493,500)),
 (F(997,1000),F(981,1000)),(A_LO,F(489,500)),(A_LO,A_LO)]

def verify():
    certificates=[];m=S/2;b=F(3,4)
    for x,y in CORNER:
        assert 0<x<=A_LO and 0<y<=A_LO
        points=POINTS.copy();points[0]=(x,y);inside=check_triangles(points)
        bottom=quad_check((m-x)/y,b/y);left=quad_check((m-y)/x,b/x)
        assert x*y+3+6*F(47,50)*(1+b)/2+(m-x)*(y+b)/2+(m-y)*(x+b)/2+inside==S*S
        certificates.append({'point':[str(x),str(y)],'bottom_scaled_polynomial_intervals':bottom,'left_scaled_polynomial_intervals':left})
    return {'verdict':'VERIFIED arithmetic for seven alternative corner-marker covers','side_condition':'a > 4003/4000','vertices':certificates,'geometric_basis':'Stromquist rectangle, triangle, and wall-quadrilateral lemmas; the wall lemmas are scaled by the corner-end heights','conclusion':'Every singleton corner owner contains the seven points, rotated with its corner','scope':'Necessary geometric condition, not a global optimality proof.'}

def extend(gs,hs):
    verify()
    return {g:hull(hs[g]+([rotate(p,g[0]) for p in CORNER] if len(g)==1 and g[0]<4 else [])) for g in gs}

if __name__=='__main__':
    result=verify();Path('corner-marker-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
