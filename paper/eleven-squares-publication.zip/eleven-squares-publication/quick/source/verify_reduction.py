"""Standard-library exact checks supporting RESEARCH.md.

This verifies a seven-case NECESSARY reduction, not global optimality.
The geometric nonavoidance lemmas and the ownership argument require the
mathematical proofs cited/stated in RESEARCH.md. No search result is imported.
"""
from fractions import Fraction as F
from math import comb
from collections import Counter
import json
from marker_cases import POINTS,S,A_LO,A_HI,all_cases,PERMS
from forced_markers import INNER,WALL,rotate,cross

def value(poly,x):
    y=F(0)
    for c in reversed(poly):y=y*x+c
    return y

def interval(poly,l,h):
    a=b=F(0)
    for c in reversed(poly):
        v=[a*l,a*h,b*l,b*h];a,b=min(v)+c,max(v)+c
    return a,b

def bernstein(poly,l,h):
    n=len(poly)-1
    q=[sum(poly[k]*comb(k,j)*l**(k-j)*(h-l)**j for k in range(j,n+1)) for j in range(n+1)]
    return [sum(q[j]*F(comb(i,j),comb(n,j)) for j in range(i+1)) for i in range(n+1)]

def positive(poly,l=F(0),h=F(1),depth=0):
    assert depth<30
    if min(bernstein(poly,l,h))>0:return [(str(l),str(h))]
    m=(l+h)/2
    return positive(poly,l,m,depth+1)+positive(poly,m,h,depth+1)

def quad_check(a,b):
    # a > 2 sqrt(2)-2, checked without an irrational approximation.
    assert (a+2)**2>8 and a<1 and 0<b<1
    assert a*a+(1-b)**2<=1
    # t*( c/(1+c)+(1-a*c)/s - b), t=tan(theta/2).
    p=[(1-a)/2,F(1,2)-b,(1+a)/2,F(-1,2)]
    return positive(p)

def poly_area(ps):return sum(ps[i][0]*ps[(i+1)%len(ps)][1]-ps[i][1]*ps[(i+1)%len(ps)][0] for i in range(len(ps)))/2

ROT=[]
for k in range(4):ROT.append([POINTS.index(rotate(p,k)) for p in POINTS])
TRI=[]
for perm in ROT:
    TRI += [tuple(perm[i] for i in tri) for tri in [(0,4,8),(0,8,7),(4,9,8)]]
TRI += [(8,9,11),(9,10,11)]

def check_triangles(ps):
    edges=Counter();area=F(0)
    for ids in TRI:
        pts=[ps[i] for i in ids]
        assert cross(*pts)>0
        area+=poly_area(pts)
        for i in range(3):
            p,q=pts[i],pts[(i+1)%3]
            assert sum((x-y)**2 for x,y in zip(p,q))<=1
            edges[ids[i],ids[(i+1)%3]]+=1
    boundary=[0,4,1,5,2,6,3,7]
    outer=poly_area([ps[i] for i in boundary])
    assert area==outer
    for a,b in list(edges):
        if edges[a,b] and edges[b,a]:
            k=min(edges[a,b],edges[b,a]);edges[a,b]-=k;edges[b,a]-=k
    assert +edges==Counter((boundary[i],boundary[(i+1)%8]) for i in range(8))
    return outer

def main():
    # Algebraic target: one specified root, with strict derivative on its interval.
    poly=list(map(F,[-6865,12420,-6754,-496,1923,-842,178,-20,1]))
    l=F('3.87708359002281417730789706010096');h=l+F(1,10**32)
    assert value(poly,l)<0<value(poly,h)
    derivative=[i*poly[i] for i in range(1,len(poly))]
    assert interval(derivative,l,h)[0]>0
    assert A_LO<S/h<S/l<A_HI
    certificates={'base':quad_check(F(47,50),F(3,4))}
    outer=check_triangles(POINTS)
    # Four corner squares and eight boundary quadrilaterals fill the exterior.
    a=S/2-1;b=F(3,4)
    assert 4+8*a*(1+b)/2+outer==S*S
    # Each inner forced point replaces just point 8 in the same triangulation.
    for p in INNER:
        ps=POINTS.copy();ps[8]=p
        assert check_triangles(ps)==outer
    for p in WALL:
        ps=POINTS.copy();ps[4]=p
        check_triangles(ps)
        x,y=p
        for width in [x-1,S-1-x]:
            certificates[f'{width},{y}']=quad_check(width,y)
    cases,pairs=all_cases()
    assert len(PERMS)==8 and len(set(tuple(p) for p in PERMS))==8
    assert len(cases)==8 and len(pairs)==26
    assert 2*F(7,10)**2<1 # inner opposite-vertex exclusion
    remaining=[c for c in cases if c!={'kind':'pair','indices':[8,10]}]
    assert len(remaining)==7
    result={'verdict':'VERIFIED exact arithmetic for the seven-case necessary reduction; NOT an optimality proof',
            'root_interval':[str(l),str(h)],'normalized_side_interval':[str(A_LO),str(A_HI)],
            'triangles':len(TRI),'inner_forced_vertices':len(INNER),'wall_forced_points':len(WALL),
            'boundary_polynomial_certificates':certificates,'remaining_cases':remaining}
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
