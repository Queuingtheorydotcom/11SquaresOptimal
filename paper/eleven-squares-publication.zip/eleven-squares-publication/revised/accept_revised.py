#!/usr/bin/env python3
"""Compose103 case6 rules plus the newly selected ownership exclusions."""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Do not run with Python -O')
from pathlib import Path
from fractions import Fraction as F
import hashlib,importlib.util,json,subprocess,os
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'work/shared-final/n11-global-proof'
ANCESTRY=ROOT/'work/paper-simplification/global-replay/ancestry'
EARLY='artifact:exploration/two-corner-global-certified-seed.json'
H7='journal:exploration/corner-global-root-N96.json'
CORRIDOR='@research-root-to-C1-bound';ROW='@research-early-row-state1'
BOTH='@research-both-support-state2';FACTS='@research-four-strict-extrema'
BUNDLES=[f'artifact:spatial-bounds-v{i}-verification.json' for i in range(2,7)]
NEW=set(BUNDLES+['@virtual-bottom','@virtual-column',CORRIDOR,ROW,BOTH,FACTS])
NUMERIC=('owner','normal','upper','strict')
RECIPE_FIELDS={'id','kind','parents','claim','artifacts','owner','physical_replacement'}
def need(x,msg):
 if not x:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def factkey(f):return(f['owner'],tuple(map(F,f['normal'])),F(f['upper']),f['strict'])
def recipe(n):return {k:v for k,v in n.items() if k in RECIPE_FIELDS}
def compose(g,evidence):
 done={}
 need(len(g['nodes'])==len(g['topological_order'])==103 and set(g['nodes'])==set(g['topological_order']),'Invalid graph inventory')
 for key in g['topological_order']:
  n=g['nodes'][key];need(n['id']==key and len(n['parents'])==len(set(n['parents'])),'Malformed node')
  need(all(p in done for p in n['parents']),'Invalid topological order or unknown parent')
  done[key]=key in evidence and all(done[p] for p in n['parents'])
 return done
def baseline_run(digest):
 ledger_path=ROOT/'verification/ledger.json';report_path=ROOT/'verification/overall-result.json'
 need(ledger_path.exists() and report_path.exists(),'Fresh baseline full run is absent; early checks remain conditional')
 ledger=read(ledger_path);report=read(report_path);plan=read(ROOT/'full-run-plan.json')
 need(ledger['manifest_sha256']==digest and ledger['plan_sha256']==sha(ROOT/'full-run-plan.json'),'Baseline run belongs to different inputs')
 need(ledger['status']==report['verdict']=='PASS_FRESH_COMPLETE_SELECTED_PROOF','Baseline full execution incomplete')
 need(report['manifest_sha256']==digest and report['ledger_sha256']==sha(ledger_path) and report['run_id']==ledger['run_id'],'Baseline report binding')
 need(set(ledger['steps'])=={s['id'] for s in plan['commands']} and len(plan['commands'])==61,'Incomplete baseline command census')
 for s in plan['commands']:
  step=ledger['steps'][s['id']];p=ROOT/s['completion_artifact']
  need(step['status']=='PASS' and step['run_id']==ledger['run_id'] and step['receipt']==s['completion_artifact'] and sha(p)==step['receipt_sha256'],'Changed or missing baseline execution '+s['id'])
  need(read(p).get(s['completion_field'])==s['completion_value'],'Baseline verdict '+s['id'])
 # Revalidate the119 own-rule receipts and mathematical input bindings now.
 # This is cheap semantic validation, not another expensive geometric replay.
 command=[sys.executable,'-B',str(ANCESTRY/'refresh_acceptance.py'),'--source',str(SOURCE),'--output',str(ANCESTRY),'--require-complete']
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONOPTIMIZE':'0'};env.pop('PYTHONPATH',None)
 log=ROOT/'verification/revised/old-own-rules.log';log.parent.mkdir(parents=True,exist_ok=True)
 before=sha(ANCESTRY/'acceptance-status.json')
 with log.open('w') as f:subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 need(sha(ANCESTRY/'acceptance-status.json')==before,'Revalidated baseline record changed')
 old=read(ANCESTRY/'acceptance-status.json');g=read(ANCESTRY/'acceptance-graph.json')
 need(old['verdict']=='PASS_FRESH_CASE6_ANCESTRY_CLOSED' and old['graph_closed'] and old['total_nodes']==119,'Original own-rule acceptance incomplete')
 return old,g,{'run_id':ledger['run_id'],'ledger_sha256':sha(ledger_path),'overall_result_sha256':sha(report_path),'own_rule_receipt_sha256':before}
def revised_interfaces(g,oldg,early,evidence):
 expected={
  CORRIDOR:['@pose-rules','@angles',H7,'@corner-coarse-boxes','@canonical-C2-C3'],
  '@virtual-bottom':[EARLY,CORRIDOR,'@angles',H7,'@canonical-C2-C3','@strip-support'],
  ROW:[EARLY,CORRIDOR,'@virtual-bottom','@foundation','@pose-rules','@relative-neighborhood'],
  '@virtual-column':[ROW,'@strip-support'],
  BOTH:[ROW,'@virtual-column','@virtual-bottom','@pose-rules','@relative-neighborhood'],FACTS:[BOTH]}
 for k,parents in expected.items():need(g['nodes'][k]['parents']==parents,'Changed typed parent interface '+k)
 need(oldg['nodes']['@angles']['claim']=='G:5/16<t<=sqrt(2)-1; C2:[0,5/48) union (43/48,1].','Missing scalar angle scope')
 need(g['nodes'][CORRIDOR]['proof_interface']['moved_owners']==[4,3],'Changed corner transport')
 need(g['nodes'][CORRIDOR]['explicit_preserved_exports']==[
  {'owner':5,'normal':['-1','0'],'upper':'-21/10','strict':True},
  {'owner':2,'normal':['-1','0'],'upper':'-291/100','strict':True}],'Missing early center exports')
 facts=early['strict_facts'];proved={factkey(c['fact']) for c in facts}
 need(len(proved)==4 and g['nodes'][FACTS]['claim']==[r['fact'] for r in facts],'Four-fact conclusion mismatch')
 rootfact=(2,(F(-1),F(0)),F(-14,5),True)
 for k in BUNDLES:
  n=g['nodes'][k];o=oldg['nodes'][k];name=k.removeprefix('artifact:')
  source=read(SOURCE/name)['necessary_halfplanes'];need(source==o['claim'],'Original bound rows changed')
  need(n['artifacts']==o['artifacts'] and len(n['claim'])==len(source),'Changed bound artifacts or number of rows')
  parents=[]
  for f,a in zip(source,n['claim']):
   need({x:f[x] for x in NUMERIC}=={x:a[x] for x in NUMERIC},'Changed numerical halfplane')
   if factkey(f) in proved:
    parent=FACTS;need(a['evidence_node']==FACTS and a['historical_exclusion_reference']==f['exclusion'],'Wrong extremum rule')
   elif factkey(f)==rootfact:
    parent=CORRIDOR;need(F(291,100)>F(14,5),'Invalid root bound weakening')
   else:
    parent='journal:'+f['exclusion'].removesuffix('.verified-exclusion.json')
    need(a==f and parent in evidence,'A retained strict exclusion was dropped')
    cut=read(SOURCE/f['exclusion'])['spatial_cut'];need(cut['owner']==f['owner'] and len(cut['inequalities'])==1,'Wrong original complement')
    x,y,z=map(F,cut['inequalities'][0]);need(list(map(F,f['normal']))==[-x,-y] and F(f['upper'])==-z and f['strict'] is True,'Incorrect strict complement')
   if parent not in parents:parents.append(parent)
  need(n['parents']==parents,'Incomplete mixed-bound parents')
  evidence[k]={'rule':'unchanged_numeric_rows_with_fresh_mixed_parents','parents':parents}
 for k in expected:evidence[k]={'rule':'fresh_early_components_plus_displayed_mathematics','parents':expected[k]}
 return evidence
def main():
 base=load('baseline',ROOT/'verify_baseline.py');digest,manifest=base.verify_inputs()
 old,oldg,baseline=baseline_run(digest)
 ownership_module=load('selected_ownership',ROOT/'revised/replay_ownership.py')
 ownership=ownership_module.validate_run(digest)
 ownership_path=ROOT/'verification/revised-ownership/result.json'
 ep=ROOT/'verification/revised-early/result.json';need(ep.exists(),'Fresh early component run absent')
 early=read(ep);need(early['verdict']=='PASS_FRESH_CONDITIONAL_REVISED_COMPONENTS' and early['manifest_sha256']==digest,'Early run context')
 need(early['checker_sha256']==sha(ROOT/'revised/replay_early.py'),'Early checker identity')
 for p,h in early['generated_outputs_sha256'].items():need(sha(ROOT/p)==h,'Changed generated early evidence '+p)
 need(early['mathematical_rounds']==2 and not early['later_continuation_rounds_used'],'Wrong propagation scope')
 need(early['H7_sha256']==sha(SOURCE/'exploration/corner-global-root-N96.json') and early['seed_sha256']==sha(SOURCE/'exploration/two-corner-global-certified-seed.json'),'Early upstream geometry changed')
 fresh_module=load('fresh_early_geometry',ROOT/'revised/replay_early.py')
 need(fresh_module.exact_facts(read(fresh_module.PROP/'both-supports/state-01.json'))==early['strict_facts'],'Strict facts not reproduced')
 graph=read(ROOT/'revised/graph.json');need(graph['status']=='UNEXECUTED_RECIPE_ONLY','Published graph contains acceptance state')
 unchanged=set(graph['nodes'])-NEW;need(len(unchanged)==92 and len(NEW)==11,'Wrong rule accounting')
 evidence={}
 for key in unchanged:
  need(recipe(graph['nodes'][key])==recipe(oldg['nodes'][key]),'An original rule changed '+key)
  need(key in old['validated_evidence'] and old['node_status'][key]['accepted'],'Original own rule not freshly valid '+key)
  evidence[key]={'rule':'fresh_baseline_own_rule','evidence':old['validated_evidence'][key]}
 revised_interfaces(graph,oldg,early,evidence)
 status=compose(graph,evidence);need(all(status.values()),'Revised graph remains open')
 omissions=[]
 for k in sorted(evidence):
  e=dict(evidence);del e[k];need(not compose(graph,e)[graph['target']],'Missing own rule closes graph')
  omissions.append(k)
 base.verify_inputs()
 result={'verdict':'PASS_FRESH_REVISED_103_NODE_ANCESTRY','graph_closed':True,'total_nodes':103,'revalidated_original_own_rules':92,'new_or_revised_rules':11,
  'baseline_computation_is_a_redundant_superset':True,'baseline_execution':baseline,'early_run_id':early['run_id'],'early_receipt_sha256':sha(ep),
  'selected_ownership_run_id':ownership['run_id'],'selected_ownership_receipt_sha256':sha(ownership_path),
  'selected_ownership':{'case0':'displayed terminal trap and exact source-hull bridge, with ancestry discharged by the fresh baseline','case3':{'point_assertions':12,'exact_owner_checks':8,'elementary_assertions':1},'case5':{'point_assertions':65,'exact_owner_checks':31}},
  'manifest_sha256':digest,'graph_sha256':sha(ROOT/'revised/graph.json'),'assembler_sha256':sha(__file__),
  'node_status':{k:{'accepted':v} for k,v in status.items()},'validated_evidence':evidence,'single_missing_own_rule_rejections':omissions,
  'scope':'The fresh61-command baseline is a computational superset and closes the case-0 source-hull ancestry. The shorter selected case-3 and case-5 tables replay freshly from initial hulls, and the case-0 terminal bridge is checked exactly. The new corridor,row,column and exactly two early rounds execute freshly; only92 original rules and11 revised rules belong to this103-node case6 proof. The original fifth-prefix ending is unchanged. Displayed geometric proofs remain mathematical inputs; no Lean claim.'}
 save(ROOT/'verification/revised/result.json',result);print(result['verdict'])
if __name__=='__main__':main()
