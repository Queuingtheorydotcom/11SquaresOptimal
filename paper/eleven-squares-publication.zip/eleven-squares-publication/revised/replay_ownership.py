#!/usr/bin/env python3
"""Fresh short case-3/5 exclusions and the case-0 terminal bridge.

This mode does not replay the computational ancestry of the case-0 hulls.
The full runner discharges that ancestry with its baseline execution.
"""
import sys
sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Do not run with Python -O')
from pathlib import Path
from fractions import Fraction as F
import argparse, hashlib, importlib.util, json, os, subprocess, time, uuid

ROOT = Path(__file__).resolve().parents[1]
CASES = ROOT/'work/readability-research/ownership-simplification/cases35'
CASE0 = ROOT/'work/readability-research/ownership-simplification/case0/publication'
SOURCE = ROOT/'work/shared-final/n11-global-proof'
OUT = ROOT/'verification/revised-ownership'
VERDICT = 'PASS_FRESH_SHORT_OWNERSHIP_AND_CONDITIONAL_CASE0_BRIDGE'

def need(value, message):
    if not value:
        raise RuntimeError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def validate_case(case, receipt):
    """Bind the fresh kernel records to every selected point-table row."""
    recipe_path = CASES/f'case{case}-points.json'
    data = read(recipe_path)
    need(data['case'] == case and data['bins'] == 96, 'Wrong case recipe')
    need(receipt['status'] == 'PASS EXACT SHORT OWNERSHIP EXCLUSION', 'Wrong case verdict')
    need(receipt['case'] == case and receipt['bins'] == 96, 'Wrong case scope')
    need(receipt['side_interval'] == ['4003/4000', '25019/25000'], 'Changed side interval')
    script = CASES/('replay_floor_chain.py' if case == 3 else 'replay_small_chain.py')
    files = [recipe_path, script] + [SOURCE/n for n in ('marker_cases.py', 'forced_markers.py', 'exact_poses.py')]
    if case == 3:
        files += [CASES/'wall_bridge.py', CASES/'wall-bridge.tex']
    need(receipt['sha256'] == {p.name: sha(p) for p in files}, 'Case input/code binding')
    need(len(receipt['stages']) == len(data['steps']) == (3 if case == 3 else 5), 'Incomplete stages')
    points = checks = 0
    for index, (step, record) in enumerate(zip(data['steps'], receipt['stages'])):
        need(record['stage'] == index and record['premise_stage'] == step['premise_round'], 'Changed stage ancestry')
        need(record['premise_owners'] == step['premise_owners'], 'Changed premise owners')
        assertions = {str(tuple(row['owner'])): [[str(F(str(x))) for x in p] for p in row['points']] for row in step['points']}
        need(record['assertions'] == assertions, 'Fresh assertions differ from recipe')
        expected = [row for row in step['points'] if not (case == 3 and index == 0 and row['owner'] == [0, 4])]
        need(len(record['checks']) == len(expected), 'Missing owner checks')
        for check, row in zip(record['checks'], expected):
            need(check['group'] == row['owner'] and check['points'] == len(row['points']), 'Wrong owner-check conclusion')
            need(type(check['poses']) is int and check['poses'] >= 0, 'Malformed pose count')
        if case == 3:
            bridge = record['floor_bridge']
            if index == 0:
                floor = load('selected_floor_bridge', CASES/'wall_bridge.py')
                need(bridge == floor.check(), 'Floor bridge arithmetic changed')
                need(assertions['(0, 4)'] == [['33/20', '1']], 'Wrong elementary conclusion')
            else:
                need(bridge is None, 'Unexpected floor inference')
        points += sum(len(row['points']) for row in step['points'])
        checks += len(expected)
    need(points == receipt['point_assertions'] == (12 if case == 3 else 65), 'Wrong point count')
    need(checks == receipt['owner_checks'] == (8 if case == 3 else 31), 'Wrong check count')
    need(receipt['contradiction'] == 'One common point strictly inside two distinct owners', 'Missing terminal contradiction')
    need(receipt['common_point'] == (['49/25', '73/25'] if case == 3 else ['29/10', '5/2']), 'Wrong common point')
    if case == 3:
        need(receipt['human_lemma_assertions'] == 1, 'Wrong elementary assertion count')

def validate_run(digest):
    """Revalidate completed generated evidence; does not claim fresh ancestry."""
    result = read(OUT/'result.json')
    need(result['verdict'] == VERDICT and result['manifest_sha256'] == digest, 'Wrong ownership run context')
    need(result['checker_sha256'] == sha(__file__), 'Changed ownership runner')
    need([r['id'] for r in result['checks']] == ['case3', 'case5', 'case0-bridge'], 'Incomplete ownership run')
    scripts = {'case3': CASES/'replay_floor_chain.py', 'case5': CASES/'replay_small_chain.py',
               'case0-bridge': CASE0/'check_case0_elementary_terminal.py'}
    for record in result['checks']:
        need(record['script'] == str(scripts[record['id']].relative_to(ROOT)), 'Wrong executed ownership checker')
        need(record['receipt'] == str((OUT/(record['id']+'.json')).relative_to(ROOT)), 'Wrong generated ownership receipt path')
        need(sha(ROOT/record['script']) == record['script_sha256'], 'Changed executed checker')
        need(sha(ROOT/record['receipt']) == record['receipt_sha256'], 'Changed generated ownership receipt')
    validate_case(3, read(OUT/'case3.json'))
    validate_case(5, read(OUT/'case5.json'))
    bridge = read(OUT/'case0-bridge.json')
    need(bridge['status'] == 'PASS: CONDITIONAL ELEMENTARY CASE-0 TERMINAL PREMISES', 'Wrong case-0 bridge verdict')
    names = ['exploration/journal-case-0-N96.json', 'marker_cases.py', 'forced_markers.py', 'exact_poses.py']
    bindings = {n: sha(SOURCE/n) for n in names}
    bindings.update({n: sha(CASE0/n) for n in ['check_case0_elementary_terminal.py', 'elementary-terminal-trap.tex']})
    need(bridge['source_sha256'] == bindings, 'Changed case-0 mathematical inputs')
    need(bridge['assumed_hull_round_zero_based'] == 12, 'Wrong assumed case-0 prefix')
    need(bridge['promotion']['group'] == [10] and bridge['promotion']['points'] == 6, 'Wrong terminal promotions')
    need(bridge['side_interval_open'] == ['4003/4000', '25019/25000'] and bridge['container'] == '97/25' and bridge['bins'] == 96, 'Wrong bridge geometry')
    need(bridge['terminal'] == {'kind': 'analytic_segment_trap', 'owner': [9], 'proof': 'elementary-terminal-trap.tex', 'uses_angular_terminal_check': False}, 'Wrong analytic ending')
    # Reconstruct every elementary premise from immutable inputs. A receipt
    # with an omitted membership cannot be accepted even if its outer file
    # digest were updated; no expensive pose enumeration is repeated here.
    sys.path.insert(0, str(SOURCE))
    from marker_cases import SYMMETRY_OWNER, all_cases, groups
    from forced_markers import hull, owned_points
    checker = load('selected_case0_terminal', CASE0/'check_case0_elementary_terminal.py')
    journal = read(SOURCE/'exploration/journal-case-0-N96.json')
    gs = groups(all_cases()[0][0])
    need(journal['groups'] == [list(g) for g in gs], 'Changed case-0 owner order')
    hs = {g: hull([tuple(map(F, p)) for p in row]) for g, row in zip(gs, journal['history'][12]['hulls'])}
    need(bridge['assumed_hulls'] == checker.serial([{'owner': g, 'hull': hs[g]} for g in gs]), 'Changed assumed H12 hulls')
    need(bridge['symmetry_limits'] == [{'owner': list(SYMMETRY_OWNER[0]), 'upper_t': '5/12'}], 'Changed case-0 symmetry')
    polygon = hull([(F(x, 1000), F(y, 1000)) for x, y in
                    [(1901, 1899), (2103, 1897), (2835, 1926), (2856, 2405),
                     (2835, 2833), (1925, 2833), (1897, 2235)]])
    memberships = [
        checker.membership((9,), (F('2.17'), F('1.70')), hull(owned_points((9,))), 'initial compulsory I1 hull'),
        checker.membership((4,), (F('1.93'), F('.99')), hs[(4,)], 'original H12 W0 hull', True),
        checker.membership((10,), (F('2.10'), F('1.92')), polygon, 'I2 polygon after six promotions', True),
        checker.membership((10,), (F('2.50'), F('1.92')), polygon, 'I2 polygon after six promotions', True),
    ]
    need(bridge['membership_checks'] == checker.serial(memberships), 'Missing or changed case-0 convex membership')
    need(bridge['scalar_checks'] == checker.serial(checker.scalar_checks()), 'Missing or changed case-0 scalar inequality')
    need(bridge['total_promotions_including_assumed_prefix'] == 760 and bridge['total_positive_owner_checks_including_assumed_prefix'] == 135, 'Changed case-0 prefix counts')
    need(result['case0_ancestry_replayed'] is False, 'Component mode cannot discharge case-0 ancestry')
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    need(1 <= args.jobs <= 4, 'jobs must be 1..4')
    baseline = load('portable_baseline_ownership', ROOT/'verify_baseline.py')
    digest, manifest = baseline.verify_inputs()
    if args.resume:
        validate_run(digest)
        print('REUSE manifest-bound selected ownership execution')
        return
    need(not OUT.exists(), 'Use a fresh extraction or --resume for a completed ownership run')
    (OUT/'logs').mkdir(parents=True)
    environment = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONOPTIMIZE': '0'}
    environment.pop('PYTHONPATH', None)
    records = []
    def run(name, script, arguments, verdict):
        receipt = OUT/(name+'.json')
        started = time.monotonic()
        with (OUT/'logs'/(name+'.log')).open('w') as log:
            subprocess.run([sys.executable, '-B', str(script), *arguments, '--output', str(receipt)], cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT, check=True)
        data = read(receipt)
        need(data.get('verdict', data.get('status')) == verdict, 'Wrong fresh result '+name)
        records.append({'id': name, 'script': str(script.relative_to(ROOT)), 'script_sha256': sha(script), 'receipt': str(receipt.relative_to(ROOT)), 'receipt_sha256': sha(receipt), 'seconds': time.monotonic()-started})
        print('PASS', name, round(records[-1]['seconds'], 2), 'seconds', flush=True)
        return data
    case3 = run('case3', CASES/'replay_floor_chain.py', [str(CASES/'case3-points.json'), '--jobs', str(args.jobs)], 'PASS EXACT SHORT OWNERSHIP EXCLUSION')
    case5 = run('case5', CASES/'replay_small_chain.py', [str(CASES/'case5-points.json'), '--jobs', str(args.jobs)], 'PASS EXACT SHORT OWNERSHIP EXCLUSION')
    validate_case(3, case3)
    validate_case(5, case5)
    # The exact selected-prefix bridge checker is supplied with the displayed
    # terminal proof. Its ancestry is deliberately not replayed in this mode.
    run('case0-bridge', CASE0/'check_case0_elementary_terminal.py', ['--root', str(ROOT)], 'PASS: CONDITIONAL ELEMENTARY CASE-0 TERMINAL PREMISES')
    baseline.verify_inputs()
    result = {'verdict': VERDICT, 'run_id': str(uuid.uuid4()), 'manifest_sha256': digest,
              'checker_sha256': sha(__file__), 'checks': records,
              'selected_cases_from_initial_hulls': [3, 5], 'case0_ancestry_replayed': False,
              'point_assertions': {'3': 12, '5': 65}, 'exact_owner_checks': {'3': 8, '5': 31},
              'scope': 'Cases 3 and 5 freshly replay from the established initial compulsory hulls. The case-0 terminal bridge is checked against selected source hulls, whose ancestry is not replayed by this mode. Full acceptance additionally requires the baseline execution and the displayed marker-cover, initial-hull, pose-soundness, floor-bridge, and terminal-trap proofs. No standalone global theorem or Lean claim.'}
    (OUT/'result.json').write_text(json.dumps(result, indent=2)+'\n')
    validate_run(digest)
    print(VERDICT, flush=True)

if __name__ == '__main__':
    main()
