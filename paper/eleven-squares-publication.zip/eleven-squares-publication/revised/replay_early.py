#!/usr/bin/env python3
"""Fresh conditional corridor, scalar row, row1, column and first both round."""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Do not run with Python -O')
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,importlib.util,json,os,subprocess,time,uuid
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'work/readability-research';CAP=R/'direct-packing/capture-next'
PROP=R/'support-rigidity/global-next/row-cut-propagation'
ROW=R/'support-rigidity/global-next/early-row';EXT=R/'strip-capacity/support-extension'
SOURCE=ROOT/'work/shared-final/n11-global-proof'
ROW_SHA='47c90221194683608a7384dffe3ddb52b8405a8b2c09d745076e9bbf00395dc3'
BOTH_SHA='fe3e986421683281ad8f8286b1d2a87bb5efe2cae3725bcb169bf3351c1816b1'
SEED_SHA='2bb94177be8d64b5c0eee5420d1f49e81a6a6343b6ba0a033f83ac833980f2f9'
def need(x,msg):
 if not x:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def generated_files():
 return [CAP/'root-roof.json',EXT/'all-angle-root-corridor-scalars.json',
  R/'independent/wider-strip-algebra-result.json',
  CAP/'row-scalar/positive-sector-certificate.json',CAP/'row-scalar/outer-sector-scalars.json',
  ROW/'early-row-strip.json',ROW/'bootstrap-c1.json',ROW/'scalar-early-row-assembly.json',
  *[PROP/(n+s) for n in ['state-00','state-01'] for s in ['.json','-report.json']],
  CAP/'fresh-column-interface.json',
  *[PROP/'both-supports'/(n+s) for n in ['state-00','state-01'] for s in ['.json','-report.json']]]
def exact_facts(state):
 facts=[(9,(0,-1),F(-23,10)),(10,(1,0),F(34,25)),(0,(1,0),F(97,50)),(0,(0,1),F(341,200))]
 expected=['-29564010978569329/12685964832000000','1411619929/1047000000','229945466681933/118884960000000','214285276379/125715000000']
 need(state['groups']==[[8,9],[0],[1],[2],[3],[4],[5],[6],[7],[10],[11]] and state['normalized_corners']==[3,4] and state['bins']==96,'State owner contract')
 out=[]
 for (owner,n,upper),want in zip(facts,expected):
  values=[]
  for row in state['owners'][owner]:
   c,s=F(row['c']),F(row['s']);need(c*c+s*s==1,'Bad pose frame')
   for u,v in row['poly']:
    u,v=F(u),F(v);values.append(n[0]*(c*u-s*v)+n[1]*(s*u+c*v))
  need(values,'Empty owner requires a separate exclusion')
  v=max(values);need(v==F(want) and v<upper,'Strict outer extremum')
  out.append({'fact':{'owner':owner,'normal':list(map(str,n)),'upper':str(upper),'strict':True},'exact_maximum':str(v),'strict_margin':str(upper-v)})
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--resume',action='store_true');a=ap.parse_args()
 need(1<=a.jobs<=4,'jobs must be1..4')
 baseline=load('portable_baseline',ROOT/'verify_baseline.py');digest,manifest=baseline.verify_inputs()
 out=ROOT/'verification/revised-early';result_path=out/'result.json'
 if a.resume and result_path.exists():
  old=read(result_path);need(old['manifest_sha256']==digest,'Changed input manifest')
  for p,h in old['generated_outputs_sha256'].items():need(sha(ROOT/p)==h,'Changed previous early output '+p)
  need(old['verdict']=='PASS_FRESH_CONDITIONAL_REVISED_COMPONENTS','Wrong earlier scope')
  print('REUSE manifest-bound conditional early execution');return
 need(not a.resume,'No completed conditional run to resume')
 need(not out.exists(),'Use a fresh extraction or --resume for an existing completed early run')
 for p in generated_files():need(not p.exists(),'Pre-existing generated early input '+str(p.relative_to(ROOT)))
 out.mkdir(parents=True);(out/'logs').mkdir()
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONOPTIMIZE':'0'};env.pop('PYTHONPATH',None)
 records=[]
 def run(name,script,args,receipt,verdict):
  start=time.monotonic();log=out/'logs'/(name+'.log')
  with log.open('w') as f:subprocess.run([sys.executable,'-B',str(script),*args],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  d=read(receipt);need(d.get('verdict',d.get('status'))==verdict,'Wrong fresh result '+name)
  records.append({'id':name,'script':str(script.relative_to(ROOT)),'script_sha256':sha(script),'receipt':str(receipt.relative_to(ROOT)),'receipt_sha256':sha(receipt),'seconds':time.monotonic()-start})
  print('PASS',name,round(records[-1]['seconds'],2),'seconds',flush=True);return d
 roof=run('root-roof',CAP/'check_root_roof.py',[],CAP/'root-roof.json','PASS_ROOT_ROOF_AND_RESIDUAL_AXIS_SCALARS')
 corridor=run('all-angle',EXT/'check_all_angle_root_corridor.py',[],EXT/'all-angle-root-corridor-scalars.json','PASS_ALL_ANGLE_SCALAR_AND_POINT_CHECKS')
 # The same right-center identity used by the reviewed corridor wrapper.
 def mul(a,b):
  q=[F(0)]*(len(a)+len(b)-1)
  for i,x in enumerate(a):
   for j,y in enumerate(b):q[i+j]+=x*y
  return q
 def add(*ps):return [sum(p[i] if i<len(p) else 0 for p in ps) for i in range(max(map(len,ps)))]
 def scale(a,p):return [a*x for x in p]
 t=[F(0),F(1)];plus=[F(1),F(0),F(1)];minus=[F(1),F(0),F(-1)]
 polynomial=add(scale(9,mul(t,plus)),scale(-29,mul(minus,plus)),scale(10,add(mul(plus,plus),mul(minus,minus),scale(2,mul(t,minus)))))
 need(polynomial==list(map(F,[-9,29,0,-11,49])) and 49*F(5,16)>11 and 29*F(5,16)>9,'Right-center polynomial')
 point=list(map(F,roof['point_bindings']['G_right']['point']));need(point[0]>=F(19,8) and point[1]<=F(29,20),'Right-center point')
 need(corridor['pair_pruning_receipts_read']==[],'Unexpected pair input')
 run('wider-strip-algebra',R/'independent/check_wider_strip_algebra.py',[],R/'independent/wider-strip-algebra-result.json','PASS_EXACT_IDENTITIES_AND_STRIP_INPUTS')
 scalar=run('scalar-row',ROW/'check_scalar_early_row.py',[],ROW/'scalar-early-row-assembly.json','PASS_FRESH_PUBLIC_SCALAR_EARLY_ROW')
 need(scalar['source_seed_sha256']==sha(SOURCE/'exploration/two-corner-global-certified-seed.json')==SEED_SHA,'Scalar seed')
 run('row-one-round',PROP/'row_cut_probe.py',['--rounds','1','--jobs',str(min(2,a.jobs))],PROP/'state-01-report.json','PASS_CONDITIONAL_PROPAGATION_PREFIX')
 need(sha(PROP/'state-01.json')==ROW_SHA,'Fresh row1 differs from reviewed state')
 rr=read(PROP/'state-01-report.json');need(len(rr['rounds'])==2 and rr['source_sha256']==SEED_SHA and rr['script_sha256']==sha(PROP/'row_cut_probe.py'),'Fresh row context')
 column=run('column',CAP/'check_column_interface.py',[],CAP/'fresh-column-interface.json','PASS_CONDITIONAL_ONE_ROUND_VIRTUAL_COLUMN_INTERFACE')
 need(column['state_sha256']==ROW_SHA,'Column not on fresh row1')
 run('first-both-round',PROP/'both_supports_probe.py',['--rounds','1','--jobs',str(min(2,a.jobs))],PROP/'both-supports/state-01-report.json','PASS_CONDITIONAL_PROPAGATION_PREFIX')
 need(sha(PROP/'both-supports/state-01.json')==BOTH_SHA,'Fresh both state differs')
 br=read(PROP/'both-supports/state-01-report.json');bs=read(PROP/'both-supports/state-01.json')
 need(len(br['rounds'])==2 and br['source_sha256']==ROW_SHA and br['script_sha256']==sha(PROP/'both_supports_probe.py') and bs['parent_state_sha256']==ROW_SHA,'Fresh both ancestry')
 facts=exact_facts(bs);baseline.verify_inputs()
 result={'verdict':'PASS_FRESH_CONDITIONAL_REVISED_COMPONENTS','run_id':str(uuid.uuid4()),'manifest_sha256':digest,
  'checker_sha256':sha(__file__),'checks':records,'H7_sha256':sha(SOURCE/'exploration/corner-global-root-N96.json'),'seed_sha256':SEED_SHA,
  'row_state_sha256':ROW_SHA,'both_state_sha256':BOTH_SHA,'mathematical_rounds':2,'later_continuation_rounds_used':False,
  'right_center_polynomial':list(map(str,polynomial)),'strict_facts':facts,
  'generated_outputs_sha256':{str(p.relative_to(ROOT)):sha(p) for p in generated_files()},
  'semantic_parent_requirements':['fresh H7 and angle restriction','fresh original two-corner seed ancestry','corner transport of all unchanged owners','displayed support/strip and strict-side neighborhood proofs'],
  'scope':'Fresh conditional component computation. No global PASS and no assumption that source journal or seed ancestry was replayed. The103-node assembler discharges these parents only after a completed manifest-bound baseline run.'}
 save(result_path,result);print(result['verdict'],flush=True)
if __name__=='__main__':main()
