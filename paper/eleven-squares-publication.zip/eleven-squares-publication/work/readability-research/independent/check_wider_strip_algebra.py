"""Independent exact polynomial checks for wider-strip proof. Standard library only.
Derives support numerators from D=2r+1-M, then clears positive denominators.
No source checker is imported or executed.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
if not __debug__:raise RuntimeError('Assertions must be enabled')
class Poly:
 def __init__(self,value=0):
  self.terms={k:F(v) for k,v in value.items() if v} if isinstance(value,dict) else ({(0,0):F(value)} if value else {})
 def __add__(self,other):
  other=cast(other);out=self.terms.copy()
  for ij,v in other.terms.items():out[ij]=out.get(ij,F(0))+v
  return Poly(out)
 __radd__=__add__
 def __neg__(self):return Poly({ij:-v for ij,v in self.terms.items()})
 def __sub__(self,other):return self+-cast(other)
 def __rsub__(self,other):return cast(other)+-self
 def __mul__(self,other):
  out={}
  for (i,j),v in self.terms.items():
   for (k,l),w in cast(other).terms.items():out[i+k,j+l]=out.get((i+k,j+l),F(0))+v*w
  return Poly(out)
 __rmul__=__mul__
 def __pow__(self,n):
  out=Poly(1)
  for _ in range(n):out=out*self
  return out
 def subst_t_b(self):
  out={}
  for (i,j),v in self.terms.items():out[i+j,0]=out.get((i+j,0),F(0))+v
  return Poly(out)
def cast(v):return v if isinstance(v,Poly) else Poly(v)
checks={}
def eq(name,a,b=0):
 assert (cast(a)-cast(b)).terms=={},name
 checks[name]='PASS'
b=Poly({(1,0):1});t=Poly({(0,1):1})
U=1+t*t;C=1-t*t;S=2*t;W=C+S
R=1-b*b;J=1+2*b-b*b;K=(1+b)**2;V=(1+t)**2
# r=R/(2b), alpha=J/K, c=C/U, s=S/U, w=W/U.
eq('alpha_minus_half_positive_numerator',2*J-K,(1-b)*(3*b+1))
eq('one_minus_alpha_positive_numerator',K-J,2*b*b)
eq('alpha_gap_positive_numerator',J-(1-b)*K,b*(1+b*b))
eq('absolute_value_breakpoint_numerator',2*b*C-R*S,2*(b-t)*(1+b*t))
G=(1+b*b)*(1-b)**2+(b-t)*((1+b*b)*(2-b)+(1+2*b-b*b)*t)
Fplus=R*(b+t)+(1+5*b+7*b*b+3*b**3)*t*t+(1+2*b)*R*t*t*(1-t)
Fminus=2*b*b*(1+b)*(1-b+(1+b)*t)+(1+2*b)*R*(t-b)*(1-t)
for sign in (1,-1):
 # M numerator over 4bU, hence D numerator over 4bU.
 Dnum=4*(R+b)*U-(R*C+2*b*S+sign*(2*b*C-R*S))
 # The B upper bound minus 1/2, denominator 2 R U^2 K.
 Bnum=S*Dnum*K-2*R*S*U*K-(2*b*S+R*C)*W*K+2*R*C*J*U-R*U*U*K
 eq('B_factor_'+str(sign),Bnum,4*(t-b)*Fplus if sign==1 else 4*(t-b)*(t-1)*Fminus)
 if sign==1:
  # A upper bound minus 1/2 at Y=w/2, same denominator.
  Anum=C*Dnum*K-2*R*C*U*K+(R*S-2*b*C)*W*K-2*R*S*J*U-R*U*U*K
  eq('A_lower_Y_substitution',Anum,2*S*(C*((R+2*b)*t+R-2*b)*K-R*J*U))
 else:
  # A upper bound minus 1/2 at Y=1+alpha-w/2.
  Anum=C*Dnum*K-2*R*C*U*K+(R*S-2*b*C)*(2*U*(K+J)-W*K)-2*R*S*J*U-R*U*U*K
  eq('A_upper_Y_substitution',Anum*V,4*C*(C*K*(b*V-R*t*t)-b*J*U*V))
eq('A_G_factor',C*((R+2*b)*t+R-2*b)-(1-b)*R*U,(t-b)*G)
# Product c*(1-2rt^2/(1+t)^2) equals 1-b at t=b.
eq('A_product_endpoint',(C*(b*V-R*t*t)-(1-b)*b*U*V).subst_t_b())
eq('G_matches_source',G,1+b*b+2*(b-1)*t-J*t*t)
eq('Fplus_matches_source',Fplus,R*(b+t)+(2+7*b+6*b*b+b**3)*t*t-(1+2*b)*R*t**3)
eq('Fminus_matches_source',Fminus,-b*R+(1+b)**3*t-(1+2*b)*R*t*t)
# kappa half-angle identity after multiplying by 2s=4t/U.
N=1-t*t+2*t**3
eq('kappa_half_angle',2*t*N,(U-C)**2+C*S)
eq('kappa_derivative',(-2*t+6*t*t)*2*U-N*4*t,4*t*(t**3+3*t-2))
eq('kappa_endpoint_mod_t2plus2tminus1',N-2*t*U,1-2*t-t*t)
r0=F(160,231);d0=F(281,231)
assert 1+r0*r0==d0*d0
assert 1+(r0+1)/(d0+1)==F(903,512)
assert F(33,20)<F(903,512)
checks['early_row_exact_height_and_angle']='PASS'
root=Path(__file__).resolve().parents[3]
inputs=['revised/proofs/wider-strip-proof.txt','work/shared-final/n11-global-proof/STRIP_SUPPORT_DOMINATION.md','work/readability-research/support-rigidity/global-next/early-row/scalar-early-row-assembly.tex']
seed_path='work/shared-final/n11-global-proof/exploration/two-corner-global-certified-seed.json'
seedraw=(root/seed_path).read_bytes()
assert hashlib.sha256(seedraw).hexdigest()=='2bb94177be8d64b5c0eee5420d1f49e81a6a6343b6ba0a033f83ac833980f2f9'
seed=json.loads(seedraw);Nbin=seed['bins'];assert Nbin==96 and seed['case']==6
alo=F(4003,4000);ahi=F(25019,25000);half=ahi*(1+F(1,Nbin))/2
strip=[];boxes={}
for owner,cut,height in [(2,F(291,100),F(33,20)),(5,F(21,10),F(7,5))]:
 margins=[];allpoints=[]
 for cell in seed['owners'][owner]:
  cc,ss=F(cell['c']),F(cell['s']);tm=F(2*cell['k']+1,2*Nbin)
  assert (cc,ss)==((1-tm*tm)/(1+tm*tm),2*tm/(1+tm*tm))
  world=[(cc*F(u)-ss*F(v),ss*F(u)+cc*F(v)) for u,v in cell['poly']]
  allpoints+=world
  clipped=[]
  for p,q in zip(world,world[1:]+world[:1]):
   dp,dq=p[0]-cut,q[0]-cut
   if dp>=0:clipped.append(p)
   if (dp>=0)!=(dq>=0):
    lam=dp/(dp-dq)
    clipped.append((cut,p[1]+lam*(q[1]-p[1])))
  if clipped:
   top=max(p[1] for p in clipped)+half*(cc+ss)
   margin=height*alo-top;assert margin>0;margins.append(margin)
 assert margins
 boxes[owner]=(min(p[0] for p in allpoints),max(p[0] for p in allpoints),min(p[1] for p in allpoints),max(p[1] for p in allpoints))
 strip.append({'owner':owner,'nonempty_pose_polygons':len(margins),'height_factor':str(height),'minimum_strict_margin':str(min(margins))})
assert boxes[2][0]>boxes[5][1]
assert max(boxes[2][3]-boxes[5][2],boxes[5][3]-boxes[2][2])<=F(58,100)
assert F(81,100)**2+F(58,100)**2<1
assert F(97,25)-F(793,500)*ahi>F(229,100)
assert F(12235,10000)-F(3,96**2)-ahi*F(169,140)>F(3,200)
checks['independent_world_coordinate_strip_enclosures']='PASS'
checks['early_row_bootstrap_scalar_margins']='PASS'
inputs.append(seed_path)
out={'status':'PASS_EXACT_IDENTITIES_AND_STRIP_INPUTS','checks':checks,'strip_inputs':strip,'scope':'Exact algebra and independent full-square height checks accompanying proof audit; not a separating-feature replay, ancestry check, or global packing theorem.','source_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in inputs}}
Path(__file__).with_name('wider-strip-algebra-result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
