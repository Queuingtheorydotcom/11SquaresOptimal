"""Exact replay of a short ownership implication table from initial hulls.
No historical PASS receipt or propagation journal is read. The source geometric
soundness and initial marker-cover lemmas are explicit mathematical premises.
"""
import sys,json,time,hashlib,argparse
from pathlib import Path
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Python -O forbidden')
HERE=Path(__file__).resolve().parent;SOURCE=HERE.parents[2]/'shared-final'/'n11-global-proof';sys.path.insert(0,str(SOURCE))
from marker_cases import all_cases,groups,A_LO,A_HI,S
from forced_markers import owned_points,hull
from exact_poses import verify_owner,contains
from marker_cases import POINTS
from wall_bridge import check as check_floor_bridge

def serial(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,dict):return {str(k):serial(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [serial(x) for x in v]
 return v

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('proposal',type=Path);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--jobs',type=int,default=2);args=ap.parse_args()
 data=json.loads(args.proposal.read_text());case=data['case'];assert case==3 and data['bins']==96
 bridge=check_floor_bridge();assert POINTS[0]==(F(1),F(1)) and POINTS[4]==(F(97,50),F(3,4)) and A_LO>1
 assert S==F(97,25) and A_LO==F(4003,4000) and A_HI==F(25019,25000)
 gs=groups(all_cases()[0][case]);initial={g:hull(owned_points(g)) for g in gs};stages=[];parsed=[];start=time.time()
 for si,entry in enumerate(data['steps']):
  pr=entry['premise_round'];assert -1<=pr<si
  owners=[tuple(g) for g in entry['premise_owners']];assert set(owners)<=set(gs)
  pts={tuple(row['owner']):[tuple(F(str(x)) for x in p) for p in row['points']] for row in entry['points']};assert set(pts)<=set(gs)
  hs=initial.copy()
  if pr>=0:
   for g in owners:hs[g]=hull(initial[g]+parsed[pr].get(g,[]))
  if si==0:assert pts[(0,4)]==[(F(33,20),F(1))]
  tasks=[(g,ps,96,gs,hs,None) for g,ps in pts.items() if not(si==0 and g==(0,4))]
  with ProcessPoolExecutor(max_workers=args.jobs) as pool:rr=list(pool.map(lambda_task,tasks))
  parsed.append(pts);stages.append({'stage':si,'premise_stage':pr,'premise_owners':owners,'assertions':pts,'checks':rr,'floor_bridge':bridge if si==0 else None})
  print('PASS stage',si,'points',sum(len(v) for v in pts.values()),flush=True)
 end=parsed[-1];expected=[(11,),(6,)] if case==3 else [(10,),(5,)]
 assert sorted(end)==sorted(expected) and len(end[expected[0]])==len(end[expected[1]])==1
 assert end[expected[0]][0]==end[expected[1]][0]
 files=[args.proposal.resolve(),Path(__file__).resolve(),HERE/'wall_bridge.py',HERE/'wall-bridge.tex']+[SOURCE/n for n in ('marker_cases.py','forced_markers.py','exact_poses.py')]
 out={'status':'PASS EXACT SHORT OWNERSHIP EXCLUSION','case':case,'scope':'Only this ownership case, conditional on marker-cover/initial-hull lemmas and established strict-slack soundness of the exact rational pose kernel. No other case or global theorem is asserted.','bins':96,'side_interval':[A_LO,A_HI],'stages':stages,'point_assertions':sum(sum(len(v) for v in p.values()) for p in parsed),'owner_checks':sum(len(s['checks']) for s in stages),'human_lemma_assertions':1,'contradiction':'One common point strictly inside two distinct owners','common_point':end[expected[0]][0],'elapsed_seconds':time.time()-start,'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
 args.output.write_text(json.dumps(serial(out),indent=2)+'\n');print(out['status'],out['point_assertions'],out['owner_checks'],out['elapsed_seconds'],flush=True)

def lambda_task(args):return verify_owner(*args)
if __name__=='__main__':main()
