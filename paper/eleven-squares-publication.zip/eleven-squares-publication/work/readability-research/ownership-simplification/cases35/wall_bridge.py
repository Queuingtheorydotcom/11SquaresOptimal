"""Exact scalar checks in the elementary floor bridge (wall-bridge.tex).
The proof uses monotonicity, no angle bins and no polynomial root isolation.
"""
from fractions import Fraction as F

def check():
 d=F(97,50)-F(33,20)
 assert d==F(29,100)>0
 # d > 3/(4 sqrt(7)), checked by squaring positive quantities.
 assert d*d>F(9,112)
 assert d*d-F(9,112)==F(131,35000)
 return {'status':'PASS EXACT FLOOR-BRIDGE SCALAR CHECK','conclusion_point':['33/20','1'], 'owned_points':[['1','1'],['97/50','3/4']], 'side_hypothesis':'a>1','container_hypothesis':'y>=0','sine_split':'3/4','positive_squared_margin':str(d*d-F(9,112))}
if __name__=='__main__':
 import json
 print(json.dumps(check(),indent=2))
