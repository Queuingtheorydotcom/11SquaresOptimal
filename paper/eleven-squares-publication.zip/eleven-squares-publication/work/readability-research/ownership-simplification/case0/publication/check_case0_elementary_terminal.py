"""Check the elementary case-0 terminal premises from the selected H12 hulls.

Fresh exact checks: six I2 promotions, four convex memberships, and rational
inequalities used in the all-angle proof elementary-terminal-trap.tex.
The geometric proof, rather than this arithmetic program, supplies the
terminal contradiction. This program does not replay the H12 ancestry and
does not accept or read a stored PASS receipt. Standard library only.
"""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Do not run with Python -O')


def serial(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [serial(v) for v in value]
    return value


def cross(a, b, p):
    return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])


def membership(owner, point, polygon, premise, strict=False):
    determinants = [cross(a, b, point)
                    for a, b in zip(polygon, polygon[1:]+polygon[:1])]
    assert len(polygon) >= 3 and min(determinants) >= 0
    if strict:
        assert min(determinants) > 0
    return {'owner': owner, 'point': point, 'premise': premise,
            'polygon': polygon,
            'minimum_oriented_edge_determinant': min(determinants)}


def scalar_checks():
    P = lambda x, y: (F(x), F(y))
    A, B, C = P('-.58', '-.11'), P('-.24', '-.71'), P('.71', '-.70')
    D, E = P('-.07', '.22'), P('.33', '.22')
    sq = lambda p: sum(x*x for x in p)
    sub = lambda p, q: tuple(x-y for x, y in zip(p, q))
    lengths = [sq(sub(C, B)), sq(sub(A, B)), sq(sub(D, A)),
               sq(sub(D, B)), sq(sub(E, C))]
    assert lengths == list(map(F, ['.9026', '.4756', '.3690', '.8938', '.9908']))
    assert all(q < 1 for q in lengths)
    assert F(281, 200)**2 < 2 < F(59, 40)**2
    assert F(281, 200)-F(237, 200) == F('.22')
    assert F(58)**2/(F(58)**2+F(11)**2) > F('.9')**2
    assert F(71)**2/(F(71)**2+F(70)**2) > F('.7')**2
    assert F('.7')-F('.7')*F('.7')**2 == F('.357') > F('.30')
    assert F(7, 22) > F(11, 58)
    assert F(22, 33) < F(71, 70)
    assert F(71, 24) > F(71, 70)
    assert 1-F('.235')-F('.475') == F('.29')
    assert F('.235')+2*F('.475') == F(237, 200)
    assert 1-F('.54')-F('.17') == F('.29')
    assert F('.54')+2*F('.17') == F('.88')
    assert F('1.17')**2 < 2
    return {'projection_squared_lengths': lengths,
            'height_lower_bound': 'sqrt(2)-237/200',
            'segment_height': F('.22'),
            'rational_lower_bound_for_sqrt2': F(281, 200)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=Path.cwd(),
                    help='Package root; defaults to current directory')
    ap.add_argument('--source', type=Path,
                    help='Override package root/work/shared-final/n11-global-proof')
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve()
    source = (args.source or root/'work/shared-final/n11-global-proof').resolve()
    output = args.output.resolve()
    if output.is_relative_to(source):
        raise ValueError('Output must be outside the read-only source')
    sys.path.insert(0, str(source))
    from marker_cases import A_LO, A_HI, S, SYMMETRY_OWNER, all_cases, groups
    from forced_markers import hull, owned_points
    from exact_poses import contains, verify_owner
    start = time.monotonic()
    journal = source/'exploration/journal-case-0-N96.json'
    data = json.loads(journal.read_bytes())
    assert hashlib.sha256(journal.read_bytes()).hexdigest() == 'e3c69bef5b241e7d0f3858297a1a57f6fa70fa6b2c3139fc313a33e97f3e282d'
    gs = groups(all_cases()[0][0])
    assert data['case'] == 0 and data['bins'] == 96
    assert data['groups'] == [list(g) for g in gs]
    assert data['symmetry_restricted'] and not data.get('branch')
    assert A_LO == F(4003, 4000) and A_HI == F(25019, 25000) and S == F(97, 25)
    hs = {g: hull([tuple(map(F, p)) for p in row])
          for g, row in zip(gs, data['history'][12]['hulls'])}
    limits = {SYMMETRY_OWNER[0]: F(5, 12)}
    polygon = hull([(F(x, 1000), F(y, 1000)) for x, y in
                    [(1901, 1899), (2103, 1897), (2835, 1926), (2856, 2405),
                     (2835, 2833), (1925, 2833), (1897, 2235)]])
    assert len(polygon) == 7
    added = [p for p in polygon if not contains(hs[(10,)], p)]
    assert len(added) == 6
    promotion = verify_owner((10,), added, 96, gs, hs, limits)
    assert promotion['points'] == 6
    memberships = [
        membership((9,), (F('2.17'), F('1.70')), hull(owned_points((9,))), 'initial compulsory I1 hull'),
        membership((4,), (F('1.93'), F('.99')), hs[(4,)], 'original H12 W0 hull', True),
        membership((10,), (F('2.10'), F('1.92')), polygon, 'I2 polygon after six promotions', True),
        membership((10,), (F('2.50'), F('1.92')), polygon, 'I2 polygon after six promotions', True),
    ]
    # All hull vertices are strictly owned; even boundary convex membership
    # therefore gives an interior point of the square.
    scalar = scalar_checks()
    proof = Path(__file__).with_name('elementary-terminal-trap.tex')
    files = [journal, source/'marker_cases.py', source/'forced_markers.py',
             source/'exact_poses.py', Path(__file__), proof]
    result = {
        'status': 'PASS: CONDITIONAL ELEMENTARY CASE-0 TERMINAL PREMISES',
        'scope': 'Assuming the original H12 hulls are strictly owned, plus the initial marker ownership/hull premises and specified symmetry normalization, six freshly checked I2 promotions and exact convex memberships establish the hypotheses of the all-angle segment-trap lemma. Scalar inequalities are checked here; the written proof supplies the geometric implication. No H12 ancestry is replayed and no stored PASS record is read. This alone is not a complete case-0 or global proof.',
        'assumed_hull_round_zero_based': 12,
        'assumed_hulls': [{'owner': g, 'hull': hs[g]} for g in gs],
        'side_interval_open': [A_LO, A_HI], 'container': S, 'bins': 96,
        'symmetry_limits': [{'owner': g, 'upper_t': t} for g, t in limits.items()],
        'promotion': promotion,
        'membership_checks': memberships,
        'scalar_checks': scalar,
        'terminal': {'kind': 'analytic_segment_trap', 'owner': [9],
                     'proof': proof.name, 'uses_angular_terminal_check': False},
        'total_promotions_including_assumed_prefix': 760,
        'total_positive_owner_checks_including_assumed_prefix': 135,
        'elapsed_seconds': time.monotonic()-start,
        'source_sha256': {str(p.relative_to(source)) if p.is_relative_to(source) else p.name:
                          hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(serial(result), indent=2)+'\n')
    print(json.dumps({k: result[k] for k in ('status', 'elapsed_seconds')}), flush=True)


if __name__ == '__main__':
    main()
