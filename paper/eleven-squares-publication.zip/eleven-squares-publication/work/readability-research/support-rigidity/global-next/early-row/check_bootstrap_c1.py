"""Original N96 domains plus X_C1>=3.10 imply strict common-normal separation."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
if not __debug__:raise SystemExit('Refusing -O')
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
SOURCE=ROOT/'work/shared-final/n11-global-proof/exploration/two-corner-global-certified-seed.json'
EXPECTED='2bb94177be8d64b5c0eee5420d1f49e81a6a6343b6ba0a033f83ac833980f2f9'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED
d=json.loads(SOURCE.read_text());N=d['bins'];assert N==96
S=F(97,25);alo=F(4003,4000);ahi=F(25019,25000)
def world(pp):
 c,s=F(pp['c']),F(pp['s']);assert c*c+s*s==1
 return [(c*F(x)-s*F(y),s*F(x)+c*F(y)) for x,y in pp['poly']]
def clip_x(poly,b):
 out=[]
 for p,q in zip(poly,poly[1:]+poly[:1]):
  dp=p[0]-b;dq=q[0]-b
  if dp>=0:out.append(p)
  if (dp>=0)!=(dq>=0):out.append(tuple((dp*q[k]-dq*p[k])/(dp-dq) for k in range(2)))
 return out
P=[p for pp in d['owners'][2] for p in clip_x(world(pp),F(31,10))]
assert P and all(0<=x<=S and 0<=y<=S for x,y in P)
expected=[F(x,10000) for x in [12235,12418,12596,12771,12942,12998,13062,13114,13155,13320]]
table=[]
for pp in d['owners'][0]:
 G=world(pp);assert all(0<=x<=S and 0<=y<=S for x,y in G)
 lower=[]
 for k in [pp['k'],pp['k']+1]:
  t=F(k,N);c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
  lower.append(min(-s*x+c*y for x,y in G)-max(-s*x+c*y for x,y in P))
 b=expected[pp['k']-30];assert b<=min(lower)
 margin=b-F(3,N*N)-ahi*F(169,140)
 assert margin>F(3,200)
 table.append({'bin':pp['k'],'rounded_endpoint_projection_lower':str(b),'exact_endpoint_projection_lower':str(min(lower)),'separation_margin':str(margin)})
assert sorted(q['bin'] for q in table)==list(range(30,40))
# Independent exact bootstrap constants, with deliberately generous root boxes.
assert F(707,500)**2<2 and S-F(793,500)*ahi>F(229,100)
assert F(81,100)**2+F(58,100)**2<1 and F(229,100)+F(81,100)==F(31,10)
for owner,box in [(2,[F(246,100),F(1,2),F(338,100),F(108,100)]),(5,[F(148,100),F(1,2),F(240,100),F(71,100)])]:
 assert all(box[0]<=x<=box[2] and box[1]<=y<=box[3] for pp in d['owners'][owner] for x,y in world(pp))
assert F(246,100)>F(240,100)
result={'verdict':'PASS_BOOTSTRAP_C1_COMMON_SEPARATOR','scope':'Original seed plus X_C1>=3.10 only; no arc pruning, row-intersection assumption, or later bound. Wall bootstrap and G/W0 axis theorem are proved separately.',
 'source_sha256':EXPECTED,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'angle_endpoint_table':table,'uniform_separation_margin_lower':'3/200','bootstrap_constants_verified':True,
 'projection_interpolation_loss':str(F(3,N*N)),'two_square_projection_radius_upper':str(ahi*F(169,140))}
(HERE/'bootstrap-c1.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['verdict'],'10 angle-bin bounds, margin >3/200')
