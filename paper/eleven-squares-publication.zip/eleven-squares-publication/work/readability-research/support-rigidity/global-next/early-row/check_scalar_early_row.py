"""Fresh scalar-only conditional early-row assembly. No pair receipts/imports."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,subprocess,sys
if not __debug__:raise SystemExit('Refusing -O')
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
RESEARCH=ROOT/'work/readability-research'
SCALAR=RESEARCH/'direct-packing/capture-next/row-scalar'
SOURCE=ROOT/'work/shared-final/n11-global-proof'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
H7=SOURCE/'exploration/corner-global-root-N96.json'
SEED=SOURCE/'exploration/two-corner-global-certified-seed.json'
assert sha(H7)=='b40c3fa3270f1e11ac446117575e7422a6994f86459022eae768a3bdd1d0364c'
assert sha(SEED)=='2bb94177be8d64b5c0eee5420d1f49e81a6a6343b6ba0a033f83ac833980f2f9'
for file in [SCALAR/'check_positive_sector.py',SCALAR/'check_outer_sectors.py',HERE/'check_early_row_strip.py',HERE/'check_bootstrap_c1.py']:
 subprocess.run([sys.executable,str(file)],check=True)
positive=json.loads((SCALAR/'positive-sector-certificate.json').read_text())
outer=json.loads((SCALAR/'outer-sector-scalars.json').read_text())
strip=json.loads((HERE/'early-row-strip.json').read_text())
c1=json.loads((HERE/'bootstrap-c1.json').read_text())
assert positive['verdict']=='PASS_FOUR_RECTANGLE_EARLY_ROW_SECTOR'
assert positive['source_sha256']==sha(H7) and positive['checker_sha256']==sha(SCALAR/'check_positive_sector.py')
assert positive['proof_sha256']==sha(SCALAR/'positive-sector.tex')
assert positive['rectangle_count']==4 and positive['positive_coefficient_count']==100
assert positive['pair_pruning_receipts_read']==[]
assert len(positive['rectangles'])==4
for r in positive['rectangles']:
 assert r['bidegree']==[4,4]
 assert len(r['bernstein_coefficients'])==5 and all(len(row)==5 for row in r['bernstein_coefficients'])
 assert min(F(x) for row in r['bernstein_coefficients'] for x in row)>0
assert outer['verdict']=='PASS_OUTER_SECTOR_SCALARS' and outer['root_sha256']==sha(H7)
assert outer['checker_sha256']==sha(SCALAR/'check_outer_sectors.py') and outer['proof_sha256']==sha(SCALAR/'full-axis-argument.tex')
assert outer['pair_pruning_receipts_read']==[]
for receipt,file in [(strip,'check_early_row_strip.py'),(c1,'check_bootstrap_c1.py')]:
 assert receipt['source_sha256']==sha(SEED) and receipt['checker_sha256']==sha(HERE/file)
assert strip['verdict']=='PASS_CONDITIONAL_EARLY_BOTTOM_STRIP'
assert strip['minimum_direction_dependent_strip_factor']=='903/512'
assert c1['verdict']=='PASS_BOOTSTRAP_C1_COMMON_SEPARATOR'
assert c1['bootstrap_constants_verified'] and c1['uniform_separation_margin_lower']=='3/200'

# The scalar sector uses only unchanged non-corner owners0,5,9,10. Bind
# their required points and all rounded center facts to the actual seed,
# instead of assuming that literal H7 vertices remain boundary vertices.
data=json.loads(SEED.read_text())
assert data['normalized_corners']==[3,4]
def inside(poly,p):
 cross=[(q[0]-r[0])*(p[1]-r[1])-(q[1]-r[1])*(p[0]-r[0]) for r,q in zip(poly,poly[1:]+poly[:1])]
 return min(cross)>=0 or max(cross)<=0
points={0:[['1.873613','1.07226'],['1.486351','1.472087'],['2.377569','1.447771'],['1.59','1.59']],
        5:[['1.989606','.990917'],['1.949504','.157326']],
        9:[['2.17','2.18']],10:[['1.529','2.043'],['1.7','2.17']]}
for owner,ps in points.items():
 poly=[tuple(map(F,q)) for q in data['hulls'][owner]]
 assert len(poly)>=3 and owner not in data['normalized_corners']
 for p in ps:assert inside(poly,tuple(map(F,p)))
for owner,box in [(0,['1.69','1.48','1.97','1.71']),(5,['1.48','.5','2.40','.71'])]:
 loX,loY,hiX,hiY=map(F,box)
 for pp in data['owners'][owner]:
  c,s=F(pp['c']),F(pp['s']);assert c*c+s*s==1
  for x,y in pp['poly']:
   x,y=F(x),F(y);X,Y=c*x-s*y,s*x+c*y
   assert loX<=X<=hiX and loY<=Y<=hiY

# Public assembly: the wider-strip proof is a displayed mathematical input;
# its independent polynomial/input checker has executed in this same run.
wider=RESEARCH/'independent/wider-strip-algebra-result.json'
wr=json.loads(wider.read_text())
assert wr['status']=='PASS_EXACT_IDENTITIES_AND_STRIP_INPUTS'
assert all(value=='PASS' for value in wr['checks'].values())
assert [(q['owner'],q['nonempty_pose_polygons'],q['height_factor']) for q in wr['strip_inputs']]==[(2,126,'33/20'),(5,47,'7/5')]
for file,digest in wr['source_sha256'].items():assert sha(ROOT/file)==digest
files=[H7,SEED,Path(__file__),HERE/'scalar-early-row-assembly.tex',wider,RESEARCH/'independent/check_wider_strip_algebra.py',ROOT/'revised/proofs/wider-strip-proof.txt']
files += [SCALAR/name for name in ['check_positive_sector.py','positive-sector-certificate.json','positive-sector.tex','check_outer_sectors.py','outer-sector-scalars.json','full-axis-argument.tex']]
files += [HERE/name for name in ['check_early_row_strip.py','early-row-strip.json','check_bootstrap_c1.py','bootstrap-c1.json']]
files += [RESEARCH/'direct-packing/capture-next/root-roof-and-corridor.tex',RESEARCH/'strip-capacity/support-extension/all-angle-root-corridor.tex']
out={'verdict':'PASS_FRESH_PUBLIC_SCALAR_EARLY_ROW',
 'conclusion':'n_G dot C_G >= -sin(theta_G)*S+a*(2*sin(theta_G)+cos(theta_G)+1/2)',
 'source_seed_sha256':sha(SEED),'source_H7_sha256':sha(H7),
 'early_center_premises':['X_W0>2.1','X_C1>2.91'],
 'actual_common_angle_premise':'2atan(5/16)<=theta_G<=pi/4',
 'normalization_transport':'Only owners3,4 move; all used points were checked inside the literal two-corner seed hulls.',
 'pair_pruning_receipts_read':[],
 'scope':'Fresh rational arithmetic and point inheritance accompanying displayed support, roof and wider-strip proofs. Seed/root/angle ancestry and strict center bounds remain explicit semantic parents.',
 'files':{str(p.relative_to(ROOT)):sha(p) for p in sorted(set(files))}}
(HERE/'scalar-early-row-assembly.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['verdict'])
