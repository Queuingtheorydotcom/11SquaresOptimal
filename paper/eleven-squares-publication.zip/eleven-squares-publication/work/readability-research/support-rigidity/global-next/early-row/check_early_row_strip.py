"""Exact whole-square strip from the original seed and two centre cuts only."""
from pathlib import Path
from fractions import Fraction as F
import json, hashlib
if not __debug__: raise SystemExit('Refusing -O')
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[4]
SOURCE=ROOT/'work/shared-final/n11-global-proof/exploration/two-corner-global-certified-seed.json'
EXPECTED='2bb94177be8d64b5c0eee5420d1f49e81a6a6343b6ba0a033f83ac833980f2f9'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED
data=json.loads(SOURCE.read_text()); assert data['case']==6
N=data['bins']; S=F(97,25); alo=F(4003,4000); ahi=F(25019,25000)
H=ahi*(1+F(1,N))/2
def normal(t): return ((1-t*t)/(1+t*t),2*t/(1+t*t))
def clip(poly,n,b):
    out=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        dp=b-sum(x*y for x,y in zip(n,p)); dq=b-sum(x*y for x,y in zip(n,q))
        if dp>=0: out.append(p)
        if (dp>=0)!=(dq>=0):
            out.append(tuple((dp*q[k]-dq*p[k])/(dp-dq) for k in range(2)))
    return out
rows=[]
for owner,cut,factor in [(2,F(291,100),F(33,20)),(5,F(21,10),F(7,5))]:
    checked=[]
    for pp in data['owners'][owner]:
        k=pp['k']; c,s=F(pp['c']),F(pp['s'])
        assert (c,s)==normal(F(2*k+1,2*N)) and c>=0 and s>=0
        p=clip([tuple(map(F,q)) for q in pp['poly']],(-c,s),-cut)
        if not p: continue
        top=max(s*x+c*y for x,y in p)+H*(c+s)
        assert top<factor*alo
        checked.append({'bin':k,'upper_y':str(top),'margin':str(factor*alo-top)})
    assert checked
    rows.append({'owner':owner,'center_x_lower':str(cut),'whole_square_y_upper_factor':str(factor),
                 'minimum_margin':str(min(F(q['margin']) for q in checked)),'checks':checked})
gmin=F(min(pp['k'] for pp in data['owners'][0]),N)
assert gmin==F(5,16)
c,s=normal(gmin); alpha=(c+s)/(1+c)
assert alpha==F(391,512) and 1+alpha>F(33,20)
result={'verdict':'PASS_CONDITIONAL_EARLY_BOTTOM_STRIP',
 'scope':'Conditional only on original two-corner pose membership and X_C1>=2.91,X_W0>=2.1. No later bounds or arc pruning used. Seed ancestry and the two new centre bounds are external premises.',
 'source_sha256':EXPECTED,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'G_half_angle_lower':str(gmin),'minimum_direction_dependent_strip_factor':str(1+alpha),'owners':rows}
(HERE/'early-row-strip.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['verdict'], 'C1 below33a/20, W0 below7a/5, strip allowance903a/512')
