"""Bounded conditional propagation from the ORIGINAL two-corner cover.

Additional premises only: X_W0>2.1, X_C1>2.91, and the early G row support.
This is not a replay or modification of the accepted global proof graph.
"""
if not __debug__:raise SystemExit('Refusing -O')
from pathlib import Path
from fractions import Fraction as F
import argparse,json,sys,time,hashlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
SOURCE=ROOT/'work/shared-final/n11-global-proof'
sys.dont_write_bytecode=True;sys.path.insert(0,str(SOURCE))
from marker_cases import S,A_LO,A_HI
from forced_markers import hull
from exact_poses import clip,contains
from exact_persistent_journal import bounds,cut_and_round
from exact_edge_arc_compatibility import Compatibility,normal
from exact_arc_hulls import reduce_domains
from exact_rectangle_cores import rectangle_cores
from exact_actual_edge_pair_regions import refine
from corner_obstruction_seed import intersect

def tighten(poses,dom,N):
 out=[];fresh=[]
 for owner,ids in enumerate(dom):
  new=set()
  for i in sorted(ids):
   p=poses[i];c,s=p['c'],p['s'];poly=p['poly']
   if owner in [2,5]:poly=clip(poly,(-c,s),-F(291 if owner==2 else 210,100))
   if owner==0:
    pieces=[]
    for k in [p['k'],p['k']+1]:
     C,T=normal(F(k,N))
     # The necessary constraint holds at AT LEAST ONE angle endpoint.
     # Maximum endpoint projection >= (a/2)cos(1/N)>=a/2-a/(4N^2).
     # Replacing a by A_LO weakens the positive support threshold, and
     # A_HI<2 makes1/(2N^2) a strict conservative error allowance.
     b=T*(S-2*A_LO)-A_LO*C-A_LO/2+F(1,2*N*N)
     pieces.extend(clip(poly,(T*c-C*s,-T*s-C*c),b))
    poly=hull(pieces)
   if poly:
    new.add(len(out));out.append({**p,'poly':poly,'own':bounds(poly)})
  fresh.append(new)
 return out,fresh

def boxes(poses,dom):
 out=[]
 for owner,ids in enumerate(dom):
  points=[(poses[i]['c']*x-poses[i]['s']*y,poses[i]['s']*x+poses[i]['c']*y) for i in ids for x,y in poses[i]['poly']]
  if not points:out.append({'owner':owner,'empty':True});continue
  b=[min(p[k] for p in points) for k in [0,1]]+[max(p[k] for p in points) for k in [0,1]]
  out.append({'owner':owner,'rows':len(ids),'center_box':list(map(str,b)),'decimal_center_box':list(map(float,b)),'bin_range':[min(poses[i]['k'] for i in ids),max(poses[i]['k'] for i in ids)+1]})
 return out

def column_screen(poses,dom,N):
 # This is an independent diagnostic copy, conditioned on possible column
 # intersection. Its conditional domains never feed global propagation.
 H=A_HI*(1+F(1,N))/2
 E=[(x,y) for x in [S-A_HI,S] for y in [F(0),2*A_HI]]
 out=[];fresh=[]
 for own,ids in enumerate(dom):
  new=set()
  for i in sorted(ids):
   p=poses[i];poly=p['poly'];c,s=p['c'],p['s']
   if own==9:
    forbidden=hull([(c*x+s*y+u*H,-s*x+c*y+v*H) for x,y in E for u in [-1,1] for v in [-1,1]])
    poly=intersect(poly,forbidden)
   if poly:new.add(len(out));out.append({**p,'poly':poly,'own':bounds(poly)})
  fresh.append(new)
 cc=Compatibility(out,N);selected=[2,6,9];active=[set(fresh[o]) for o in selected]
 ok,deleted=reduce_domains(active,cc)
 for o,ids in zip(selected,active):fresh[o]=ids
 bad=[];far=[];checks=0;fc=0;minmargin=None;fmin=None
 for i in fresh[9]:
  for j in fresh[6]:
   if not cc.compatible(i,j):continue
   threshold=cc.threshold(out[i]['k'],out[j]['k'])
   for who in [i,j]:
    for axis in [0,1]:
     for sign in [-1,1]:
      if who==i and axis==1 and sign==1:continue
      vals=[]
      for k in [out[who]['k'],out[who]['k']+1]:
       aa,bb=cc.endpoint_project(i,k),cc.endpoint_project(j,k);lo,hi=2*axis,2*axis+1
       vals.append(aa[hi]-bb[lo] if sign==1 else bb[hi]-aa[lo])
      margin=threshold-max(vals);checks+=1;minmargin=margin if minmargin is None else min(minmargin,margin)
      if margin<=0:bad.append({'I2_bin':out[i]['k'],'W1_bin':out[j]['k'],'axis_owner':'I2' if who==i else 'W1','axis':axis,'sign':sign,'margin':str(margin)})
  for j in fresh[2]:
   if not cc.compatible(i,j):continue
   vals=[]
   for k in [out[i]['k'],out[i]['k']+1]:
    aa,bb=cc.endpoint_project(i,k),cc.endpoint_project(j,k);vals.append(aa[2]-bb[3])
   margin=min(vals)-F(3,N*N)-A_HI*F(169,140);fc+=1;fmin=margin if fmin is None else min(fmin,margin)
   if margin<=0:far.append({'I2_bin':out[i]['k'],'C1_bin':out[j]['k'],'margin':str(margin)})
 return {'verdict':'PASS_CONDITIONAL_COLUMN_SEPARATOR_SCREEN' if ok and not bad and not far else 'INCONCLUSIVE_COLUMN_SCREEN',
         'counts':{str(o):len(fresh[o]) for o in selected},'nonempty':ok,'arc_deletions':len(deleted),'unwanted_axis_checks':checks,
         'unresolved_axis_checks':len(bad),'minimum_axis_margin':str(minmargin),'C1_checks':fc,'unresolved_C1_checks':len(far),'minimum_C1_margin':str(fmin),
         'unresolved_axes':bad,'unresolved_C1':far}

def save_state(name,d,poses,dom,hs,gs,N,records):
 owners=[]
 for ids in dom:owners.append([{'k':poses[i]['k'],'c':str(poses[i]['c']),'s':str(poses[i]['s']),'poly':[[str(x),str(y)] for x,y in poses[i]['poly']]} for i in sorted(ids)])
 state={'method':'conditional_early_row_exploration','case':6,'bins':N,'groups':d['groups'],'normalized_corners':[3,4],
        'hulls':[[[str(x),str(y)] for x,y in hs[g]] for g in gs],'owners':owners,
        'explicit_added_premises':['X_W0>2.1','X_C1>2.91','early G virtual-bottom-row normal support inequality'],
        'scope':'Conditional research cover from original two-corner domains only; early-row theorem and seed ancestry are external premises. No late source cover or accepted graph is reused.'}
 (HERE/(name+'.json')).write_text(json.dumps(state)+'\n')
 report={'verdict':'PASS_CONDITIONAL_PROPAGATION_PREFIX','stage':name,'rounds':records,'boxes':boxes(poses,dom),'column_screen':column_screen(poses,dom,N),
         'source_sha256':hashlib.sha256((SOURCE/'exploration/two-corner-global-certified-seed.json').read_bytes()).hexdigest(),
         'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'state_sha256':hashlib.sha256((HERE/(name+'.json')).read_bytes()).hexdigest(),
         'scope':state['scope']}
 (HERE/(name+'-report.json')).write_text(json.dumps(report,indent=2)+'\n')
 print(name,'counts',list(map(len,dom)),'column unresolved',report['column_screen']['unresolved_axis_checks'],report['column_screen']['unresolved_C1_checks'],flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--rounds',type=int,default=0);ap.add_argument('--jobs',type=int,default=1);args=ap.parse_args()
 assert 0<=args.rounds<=3 and 1<=args.jobs<=2
 source=SOURCE/'exploration/two-corner-global-certified-seed.json'
 assert hashlib.sha256(source.read_bytes()).hexdigest()=='2bb94177be8d64b5c0eee5420d1f49e81a6a6343b6ba0a033f83ac833980f2f9'
 d=json.loads(source.read_text());N=d['bins'];gs=[tuple(g) for g in d['groups']]
 hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,d['hulls'])};poses=[];dom=[]
 for owner in d['owners']:
  ids=set()
  for pp in owner:
   poly=[tuple(map(F,p)) for p in pp['poly']];ids.add(len(poses));poses.append({'k':pp['k'],'c':F(pp['c']),'s':F(pp['s']),'poly':poly,'own':bounds(poly)})
  dom.append(ids)
 poses,dom=tighten(poses,dom,N);cc=Compatibility(poses,N);ok,deleted=reduce_domains(dom,cc);assert ok
 records=[{'stage':'initial row/center cuts and all-owner arc consistency','deleted_rows':len(deleted)}]
 save_state('state-00',d,poses,dom,hs,gs,N,records)
 for rnd in range(1,args.rounds+1):
  start=time.monotonic();print('starting actual-edge round',rnd,flush=True)
  poses,dom,pruning=refine(poses,dom,N,args.jobs)
  cc=Compatibility(poses,N);ok,deleted=reduce_domains(dom,cc);assert ok
  hs,cores=rectangle_cores(poses,dom,gs,hs,N)
  poses,dom=cut_and_round(poses,dom,gs,hs,N,10**6)
  poses,dom=tighten(poses,dom,N)
  records.append({'round':rnd,'deleted_rows':len(deleted),'center_pruning':pruning,'rectangle_cores':cores,'seconds':time.monotonic()-start})
  save_state(f'state-{rnd:02d}',d,poses,dom,hs,gs,N,records)

if __name__=='__main__':main()
