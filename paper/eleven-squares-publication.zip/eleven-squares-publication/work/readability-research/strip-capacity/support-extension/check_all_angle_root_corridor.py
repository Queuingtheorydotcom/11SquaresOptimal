"""Exact scalar and source-point checks for the all-angle argument.

This is not a full formal proof checker. The displayed geometric argument
needs independent mathematical review; the existing H7/root-interface
replay is a separate premise. No pair-pruning receipt is read.
"""
if not __debug__:
    raise SystemExit("Refusing optimized execution")

from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[2] / "shared-final/n11-global-proof"
ROOT = SOURCE / "exploration/corner-global-root-N96.json"


def main():
    root = json.loads(ROOT.read_text())
    assert root["case"] == 6 and root["branch"] == [0, 30, 40]
    assert len(root["history"]) == 7
    hulls = root["history"][-1]["hulls"]
    # These are literal hull vertices, not rounded inferred points.
    points = {
        "d": (5, ["1.949504", "0.157326"]),
        "g": (0, ["1.873613", "1.07226"]),
        "k": (0, ["1.486351", "1.472087"]),
    }
    for owner, point in points.values():
        assert point in hulls[owner]
    d, g, k = [tuple(map(F, points[name][1])) for name in ["d", "g", "k"]]
    assert d[0] >= F("1.94") and d[1] <= F(".16")
    assert F("1.87") <= g[0] <= F("1.88") and g[1] <= F("1.08")
    assert k[0] <= F("1.49") and k[1] <= F("1.48")

    amin, amax = F(4003, 4000), F(25019, 25000)
    c, s = F(231, 281), F(160, 281)
    assert c*c + s*s == 1 and s > F(1, 2)
    q = F("2.17"), F("2.18")
    roof_records = []
    for r in [(F("1.529"), F("2.043")), (F("1.7"), F("2.17"))]:
        assert q[1] >= r[1]
        derivative_lower = amin - (q[0]-r[0])
        assert derivative_lower > 0
        bxlo = q[0]+(r[0]-q[0])*s*s+(q[1]-r[1])*s*c-amax*(c-s)
        bxhi = (q[0]+r[0]+q[1]-r[1])/2
        assert bxlo > F(7, 4) and bxhi <= F("1.94")
        roof_records.append({"r": list(map(str, r)), "Bx_lower": str(bxlo),
                             "Bx_upper": str(bxhi), "derivative_lower": str(derivative_lower)})

    assert F(".7")**2 < F(1, 2) < F(".71")**2
    assert F(".8")**2 < F(3, 4)
    assert F(".385")-F(".83")**2/2 == F(".04055") > 0
    assert F(".27")+F(".46")**2/2-F(".58")*F(".46") == F(".109") > 0
    assert F(".58") > F(".46")  # quadratic decreases on the needed interval
    assert amin-F(".7395") > 0 and amin-F(".999") > 0
    assert 1+F(".06")*F(".7")-F("1.08")*F(".71")-F(".16")*F(3,2) == F(".0352") > 0
    assert F(".49")+F(1,8)-F("1.08")/2 == F(".075") > 0
    assert F("1.08") > F(1, 2)  # last quadratic decreases on [0,1/2]
    assert F(".81")**2+F(".58")**2 < 1
    assert amax*amax/2 < F(".71")**2

    report = {
        "verdict": "PASS_ALL_ANGLE_SCALAR_AND_POINT_CHECKS",
        "scope": "Elementary arithmetic only; geometric proof and H7/interface ancestry are separate obligations.",
        "pair_pruning_receipts_read": [],
        "root_sha256": hashlib.sha256(ROOT.read_bytes()).hexdigest(),
        "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "proof_sha256": hashlib.sha256((HERE/"all-angle-root-corridor.tex").read_bytes()).hexdigest(),
        "points": {name: {"owner": owner, "coordinates": point} for name, (owner, point) in points.items()},
        "roof_intersection_x_bounds": roof_records,
        "strict_margins": [".04055", ".109", ".0352", ".075"],
    }
    (HERE/"all-angle-root-corridor-scalars.json").write_text(json.dumps(report, indent=2)+"\n")
    print(report["verdict"])


if __name__ == "__main__":
    main()
