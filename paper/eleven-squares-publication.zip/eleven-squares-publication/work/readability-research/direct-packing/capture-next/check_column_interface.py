"""Exact virtual-column interface from the new conditional one-round state.

The state ancestry and two-square strip theorem remain explicit premises.
This replays only the necessary interference cover and geometric interface.
"""
if not __debug__:
    raise SystemExit('Refusing optimized execution')

from pathlib import Path
from fractions import Fraction as F
import argparse
import hashlib
import json
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SOURCE = ROOT/'work/shared-final/n11-global-proof'
STATE = ROOT/'work/readability-research/support-rigidity/global-next/row-cut-propagation/state-01.json'


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bounds(poly):
    return min(x for x, y in poly), max(x for x, y in poly), min(y for x, y in poly), max(y for x, y in poly)


def world(row):
    c, s = F(row['c']), F(row['s'])
    return [(c*F(x)-s*F(y), s*F(x)+c*F(y)) for x, y in row['poly']]


def intersect(poly, region):
    for a, b in zip(region, region[1:]+region[:1]):
        normal = b[1]-a[1], a[0]-b[0]
        poly = clip(poly, normal, normal[0]*a[0]+normal[1]*a[1])
    return poly


def screen(state):
    N = state['bins']
    H = A_HI*(1+F(1, N))/2
    virtual_outer = [(x, y) for x in [S-A_HI, S] for y in [F(0), 2*A_HI]]
    poses, domains = [], {}
    for owner in [2, 6, 9]:
        ids = set()
        for row in state['owners'][owner]:
            k, c, s = row['k'], F(row['c']), F(row['s'])
            require(0 <= k < N and (c, s) == normal(F(2*k+1, 2*N)), 'pose frame')
            poly = [tuple(map(F, point)) for point in row['poly']]
            if owner == 9:
                region = hull([(c*x+s*y+u*H, -s*x+c*y+v*H)
                               for x, y in virtual_outer for u in [-1, 1] for v in [-1, 1]])
                poly = intersect(poly, region)
            # Retain all nonempty closed intersections, including segments
            # and points. No dimension-based deletion occurs in this stage.
            if poly:
                ids.add(len(poses))
                poses.append({'k': k, 'c': c, 's': s, 'poly': poly, 'own': bounds(poly)})
        domains[owner] = ids
    compatibility = Compatibility(poses, N)
    active = [domains[owner] for owner in [2, 6, 9]]
    nonempty, deletions = reduce_domains(active, compatibility)
    require(nonempty, 'expected nonempty conditioned cover')
    domains = dict(zip([2, 6, 9], active))
    checks, c1_checks, minimum, c1_minimum = 0, 0, None, None
    for i in sorted(domains[9]):
        for j in sorted(domains[6]):
            if not compatibility.compatible(i, j):
                continue
            threshold = compatibility.threshold(poses[i]['k'], poses[j]['k'])
            for who in [i, j]:
                for axis in [0, 1]:
                    for sign in [-1, 1]:
                        if who == i and axis == 1 and sign == 1:
                            continue
                        endpoint_gaps = []
                        for k in [poses[who]['k'], poses[who]['k']+1]:
                            aa, bb = compatibility.endpoint_project(i, k), compatibility.endpoint_project(j, k)
                            lo, hi = 2*axis, 2*axis+1
                            endpoint_gaps.append(aa[hi]-bb[lo] if sign == 1 else bb[hi]-aa[lo])
                        margin = threshold-max(endpoint_gaps)
                        require(margin > 0, 'unwanted I2/W1 separating axis')
                        minimum = margin if minimum is None else min(minimum, margin)
                        checks += 1
        for j in sorted(domains[2]):
            if not compatibility.compatible(i, j):
                continue
            endpoint_gaps = []
            for k in [poses[i]['k'], poses[i]['k']+1]:
                aa, bb = compatibility.endpoint_project(i, k), compatibility.endpoint_project(j, k)
                endpoint_gaps.append(aa[2]-bb[3])
            margin = min(endpoint_gaps)-F(3, N*N)-A_HI*F(169, 140)
            require(margin > 0, 'C1 common-normal separation')
            c1_minimum = margin if c1_minimum is None else min(c1_minimum, margin)
            c1_checks += 1
    require(checks > 0 and c1_checks > 0, 'nonvacuous expected interface')
    return {
        'counts': {str(owner): len(ids) for owner, ids in domains.items()},
        'arc_deletions': len(deletions),
        'unwanted_axis_checks': checks,
        'minimum_axis_margin': str(minimum),
        'C1_checks': c1_checks,
        'minimum_C1_margin': str(c1_minimum),
    }


def main():
    global clip, hull, Compatibility, normal, reduce_domains, S, A_LO, A_HI
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=HERE/'fresh-column-interface.json')
    parser.add_argument('--manifest', type=Path, default=HERE/'column-interface-inputs.json')
    args = parser.parse_args()
    started = time.monotonic()
    manifest = json.loads(args.manifest.read_text())
    require(manifest['schema'] == 'one-round-column-interface-v1' and manifest['files'], 'input manifest')
    expected_inputs = [Path(__file__).resolve(), HERE/'one-round-column-interface.tex', STATE]
    expected_inputs += [SOURCE/name for name in ['marker_cases.py', 'forced_markers.py',
                        'exact_poses.py', 'exact_arc_hulls.py', 'exact_edge_arc_compatibility.py']]
    require(set(manifest['files']) == {str(path.relative_to(ROOT)) for path in expected_inputs},
            'complete input inventory')
    for name, digest in manifest['files'].items():
        require(sha(ROOT/name) == digest, 'input hash '+name)
    sys.path.insert(0, str(SOURCE))
    from exact_poses import clip
    from forced_markers import hull
    from exact_edge_arc_compatibility import Compatibility, normal
    from exact_arc_hulls import reduce_domains
    from marker_cases import S, A_LO, A_HI
    state = json.loads(STATE.read_text())
    require(state['case'] == 6 and state['bins'] == 96
            and state['normalized_corners'] == [3, 4], 'state scope')
    expected_groups = [[8, 9], [0], [1], [2], [3], [4], [5], [6], [7], [10], [11]]
    require(state['groups'] == expected_groups, 'owner-label contract')
    boxes = {}
    for owner in [2, 6, 9]:
        rows = state['owners'][owner]
        require(rows, 'nonempty owner domain')
        points = [point for row in rows for point in world(row)]
        boxes[owner] = bounds(points)
        require(all(0 <= value <= S for value in boxes[owner]),
                'center enclosure for angular interpolation')
    for owner in [2, 6]:
        require(boxes[owner][0] >= F(309, 100), 'full-square strip center bound')
    require(F(71, 100)**2 > F(1, 2) and A_LO > 1, 'circumradius and side')
    strip_margin = F(309, 100) + F(79, 100)*A_LO-S
    require(strip_margin > 0, 'three-halves strip width')
    b = boxes[9]
    z = (S-A_HI-b[1], S-A_LO-b[0], 2*A_LO-b[3], 2*A_HI-b[2])
    require(0 < z[0] <= z[1] < F(449, 1000)
            and -F(492, 1000) < z[2] <= z[3] < 0, 'column-corner offset')
    bins = [row['k'] for row in state['owners'][9]]
    require(0 < min(bins) and max(bins)+1 < 96, 'strict first-quadrant I2 angle')
    require(F(492, 1000) < A_LO/2, 'strict corner e-strip')
    require(F(99, 70)**2 > 2, 'sum-of-square-radii upper bound')
    finite_screen = screen(state)
    imported = {}
    for module in list(sys.modules.values()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            if path.is_relative_to(SOURCE) and path.suffix == '.py':
                key = str(path.relative_to(ROOT))
                require(key in manifest['files'], 'unmanifested helper '+key)
                imported[key] = sha(path)
    for name, digest in manifest['files'].items():
        require(sha(ROOT/name) == digest, 'input changed during replay '+name)
    result = {
        'verdict': 'PASS_CONDITIONAL_ONE_ROUND_VIRTUAL_COLUMN_INTERFACE',
        'conclusion': 'ell_I2(n_I2) >= h_[S-a,S]x[0,2a](n_I2)',
        'scope': 'Fresh rational interface replay from a pinned conditional state. Valid state ancestry, source pose/SAT soundness and the displayed two-square strip theorem remain explicit premises. No global optimality or full ancestry replay is asserted.',
        'state_sha256': sha(STATE),
        'checker_sha256': sha(Path(__file__)),
        'manifest_sha256': sha(args.manifest),
        'source_sha256': imported,
        'center_boxes_xmin_xmax_ymin_ymax': {str(owner): list(map(str, box)) for owner, box in boxes.items()},
        'whole_square_strip': 'S-3a/2 < x <= S for both C1 and W1',
        'strip_lower_margin': str(strip_margin),
        'column_corner_offset_bounds': list(map(str, z)),
        'I2_half_angle_bin_range': [min(bins), max(bins)+1, 96],
        'conditioned_screen': finite_screen,
        'seconds': time.monotonic()-started,
    }
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(result['verdict'], result['seconds'])
    print(finite_screen)


if __name__ == '__main__':
    main()
