"""Exact arithmetic for the human roof and residual-axis argument.

Compulsory hulls are conditional premises from the seven-round root.
This checker verifies their small point/interface consequences; it does
not replace the accepted root replay or the coarse pair-pruning receipt.
"""
if not __debug__:raise SystemExit('Refusing -O')
from fractions import Fraction as F
from pathlib import Path
import sys,json,hashlib,time
HERE=Path(__file__).resolve().parent;SOURCE=HERE.parents[2]/'shared-final/n11-global-proof'
sys.dont_write_bytecode=True;sys.path.insert(0,str(SOURCE))
from exact_poses import contains,pose_bin
from marker_cases import A_LO,A_HI
def normal(t):return (1-t*t)/(1+t*t),2*t/(1+t*t)
def dot(n,p):return sum(a*b for a,b in zip(n,p))
def roof(q,r):
    qx,qy=q;rx,ry=r;v=F(999,1000)-ry
    return [v+A_LO,-2*(qx-rx)+2*A_LO,2*v-4*(qy-ry),2*(qx-rx)+2*A_LO,v-A_LO]
def main():
    start=time.monotonic();path=SOURCE/'exploration/corner-global-root-N96.json';j=json.loads(path.read_text())
    assert j['case']==6 and j['branch']==[0,30,40] and len(j['history'])==7
    gs=list(map(tuple,j['groups']));hs={g:[tuple(map(F,p)) for p in h] for g,h in zip(gs,j['history'][-1]['hulls'])}
    pts={'G_left':(0,('1.28','1.715')),'I2_roof':(9,('2.17','2.18')),
         'I3_roof_early':(10,('1.529','2.043')),'I3_roof_late':(10,('1.7','2.17')),
         'W0_upper':(5,('1.99','.99')),'G_right':(0,('2.377569','1.447771'))}
    for name,(own,p) in pts.items():assert contains(hs[gs[own]],tuple(map(F,p))),name
    c0,s0=normal(F(5,16));T0=s0/c0
    # q is in G's n strip; both r points are in G's e strip.
    margins={'q below G_left in n':F('.89')*T0-F('.465'),
       'early r above I0 in e':-F('.061')+F('.453')*T0,
       'early r below I1 in e':F('.761')-F('.453'),
       'late r below I1 in e':F('.59')-F('.58'),
       'late r above I0 in n':F('.58')-F('.11')}
    assert min(margins.values())>0
    polys=[]
    q=tuple(map(F,pts['I2_roof'][1]))
    for key,lo,hi in [('I3_roof_early',F(5,16),F(1,3)),('I3_roof_late',F(1,3),F(5,12))]:
        poly=roof(q,tuple(map(F,pts[key][1])));scaled=[4000*v for v in poly]
        d2=[2*scaled[2],6*scaled[3],12*scaled[4]];disc=d2[1]**2-4*d2[0]*d2[2]
        endpoints=[sum(v*t**i for i,v in enumerate(scaled)) for t in [lo,hi]]
        assert d2[2]<0 and disc<0 and min(endpoints)>0
        polys.append({'foreign_point':key,'half_angle_interval':[str(lo),str(hi)],'power_coefficients':list(map(str,poly)),'scaled_by_4000':list(map(str,scaled)),'second_derivative':list(map(str,d2)),'second_derivative_discriminant':str(disc),'scaled_endpoint_values':list(map(str,endpoints))})
    # Coarse center and G-strip interface, from unmodified root hulls.
    boxes={0:tuple(map(F,['1.69','1.97','1.48','1.71'])),2:tuple(map(F,['2.46','3.38','.5','1.08'])),5:tuple(map(F,['1.48','2.4','.5','.71']))}
    N=96;records=[];estrip=F(0);p=tuple(map(F,pts['W0_upper'][1]))
    for own,box in boxes.items():
        count=0;minslack=None
        for k in range(N):
            if own==0 and not 30<=k<40:continue
            c,s,_,pp=pose_bin(gs[own],N,k,gs,hs)
            for poly in pp:
                count+=1
                for u,v in poly:
                    x,y=c*u-s*v,s*u+c*v
                    slack=min(x-box[0],box[1]-x,y-box[2],box[3]-y);assert slack>=0
                    minslack=slack if minslack is None else min(slack,minslack)
                    if own==0:
                        val=max(abs(dot(normal(F(z,N)),(x-p[0],y-p[1]))) for z in [k,k+1])+F(3,N*N)
                        estrip=max(estrip,val)
        records.append({'owner':own,'box':list(map(str,box)),'pose_pieces':count,'minimum_margin':str(minslack)})
    assert estrip<F(1,2)
    # b_x >=1.55 from G_right and maximum cosine; b_x<=X_G<=1.97.
    assert F(19,8)-A_HI*c0>F(31,20)
    C,T=normal(F(1,96))
    # h_Q(n_phi)-ell_G(n_phi), for all surviving folded Q angles.
    # Drop the nonnegative square term and bound |b_x-X_Q|<=.55.
    gap=C*(A_LO-F('.999'))+T*(A_LO*C/2-F('.55'))
    assert gap>0
    assert F('.49')+F('1.21')*T<1
    assert F('.7')*F('.77')-F('.71')*F('.49')>0
    assert C*F('.77')-T*F('.49')>0
    assert F('.81')**2+F('.58')**2<1
    assert A_HI*A_HI/2<F('.71')**2
    out={'verdict':'PASS_ROOT_ROOF_AND_RESIDUAL_AXIS_SCALARS','scope':'Conditional root interface plus displayed geometric proof. Coarse N384 pair-pruning and independent right-center lemma remain separate premises.',
         'point_bindings':{k:{'owner':v[0],'point':list(v[1])} for k,v in pts.items()},'projection_margins':{k:str(v) for k,v in margins.items()},'roof_polynomials':polys,'center_boxes':records,'G_e_strip_absolute_upper':str(estrip),'Q_normal_overlap_margin':str(gap),'seconds':time.monotonic()-start,
         'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [path,SOURCE/'marker_cases.py',SOURCE/'forced_markers.py',SOURCE/'exact_poses.py']},'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    HERE.joinpath('root-roof.json').write_text(json.dumps(out,indent=2)+'\n');print(out['verdict']);print('estrip',float(estrip),'normalgap',float(gap),'seconds',out['seconds'])
if __name__=='__main__':main()
