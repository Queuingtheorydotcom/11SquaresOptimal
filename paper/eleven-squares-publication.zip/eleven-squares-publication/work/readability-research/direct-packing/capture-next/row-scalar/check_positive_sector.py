"""Four exact polynomial rectangles for the remaining early-row sector.

No pose enumeration, floating arithmetic or pair-pruning receipt is used.
The geometric support inequalities and row-failure hypothesis are explicit
mathematical premises, not inferred from this scalar certificate.
"""
if not __debug__:
    raise SystemExit('Refusing optimized execution')

from fractions import Fraction as F
from math import comb
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[3] / 'shared-final/n11-global-proof'
A = F(4003, 4000)
B = F(25019, 25000)


def require(ok, message):
    if not ok:
        raise ArithmeticError(message)


def mono(value, i=0, j=0):
    return {(i, j): F(value)}


def add(*polynomials):
    out = {}
    for polynomial in polynomials:
        for powers, coefficient in polynomial.items():
            out[powers] = out.get(powers, F(0)) + coefficient
    return {powers: coefficient for powers, coefficient in out.items() if coefficient}


def scale(value, polynomial):
    return {powers: F(value) * coefficient for powers, coefficient in polynomial.items()
            if F(value) * coefficient}


def mul(left, right):
    out = {}
    for (i, j), a in left.items():
        for (k, l), b in right.items():
            out[i+k, j+l] = out.get((i+k, j+l), F(0)) + a*b
    return {powers: coefficient for powers, coefficient in out.items() if coefficient}


def evaluate(polynomial, t, u):
    return sum(coefficient*t**i*u**j for (i, j), coefficient in polynomial.items())


def bernstein(polynomial, box):
    """Exact affine substitution, followed by degree-(4,4) conversion."""
    (t0, t1), (u0, u1) = box
    require(t0 < t1 and u0 < u1, 'nonempty rectangle')
    require(all(0 <= i <= 4 and 0 <= j <= 4 for i, j in polynomial), 'bidegree')
    power = {}
    for (a, b), coefficient in polynomial.items():
        for i in range(a+1):
            for j in range(b+1):
                power[i, j] = power.get((i, j), F(0)) + coefficient * comb(a, i) * comb(b, j) * t0**(a-i) * u0**(b-j) * (t1-t0)**i * (u1-u0)**j
    return [[sum(power.get((k, l), F(0))*F(comb(i, k), comb(4, k))*F(comb(j, l), comb(4, l))
                 for k in range(i+1) for l in range(j+1))
             for j in range(5)] for i in range(5)]


def polynomials():
    # cos(theta)=ct/D, sin(theta)=st/D; likewise C=cu/E,S=su/E.
    D = add(mono(1), mono(1, 2))
    E = add(mono(1), mono(1, 0, 2))
    ct = add(mono(1), mono(-1, 2))
    st = mono(2, 1)
    cu = add(mono(1), mono(-1, 0, 2))
    su = mono(2, 0, 1)
    alpha = add(mul(st, cu), scale(-1, mul(ct, su)))
    beta = add(mul(ct, cu), mul(st, su))
    e_upper = add(scale(F('2.17'), ct), scale(F('2.18'), st), scale(-A, D))
    roofs = {
        'row': add(scale(B, ct), scale(2*B-F('3.88'), st)),
        'r2': add(scale(-F('1.7'), st), scale(F('2.17'), ct), scale(-A, D)),
    }
    supports = {
        'wall': add(scale(-F('2.4'), mul(su, E)),
                    scale(A/2, add(mul(E, E), mul(cu, cu), mul(cu, su)))),
        'point': add(scale(A, mul(E, cu)), scale(-F('1.95'), mul(su, cu)),
                     scale(-F('.16'), mul(su, su))),
    }
    result = {}
    for roof_name, n_upper in roofs.items():
        roof = add(mul(alpha, e_upper), mul(beta, n_upper))
        for support_name, support in supports.items():
            multiplier = E if support_name == 'wall' else cu
            result[roof_name, support_name] = add(mul(support, mul(D, D)),
                                                scale(-1, mul(roof, multiplier)))
    return result


def direct_numerator(t, u, roof_name, support_name):
    """Independent evaluation of the displayed rational support formula."""
    c, s = (1-t*t)/(1+t*t), 2*t/(1+t*t)
    C, S = (1-u*u)/(1+u*u), 2*u/(1+u*u)
    e_upper = F('2.17')*c + F('2.18')*s - A
    n_upper = (B*(c+2*s)-F('3.88')*s if roof_name == 'row'
               else -F('1.7')*s+F('2.17')*c-A)
    roof = (s*C-c*S)*e_upper + (c*C+s*S)*n_upper
    support = (-F('2.4')*S+A*(1+C*C+C*S)/2 if support_name == 'wall'
               else A-F('1.95')*S-F('.16')*S*S/C)
    denominator = (1+t*t)**2 * (1+u*u) * ((1+u*u) if support_name == 'wall' else (1-u*u))
    require(denominator > 0, 'positive common denominator')
    return denominator*(support-roof)


def check_rectangle(polynomial, box, names):
    coefficients = bernstein(polynomial, box)
    require(min(map(min, coefficients)) > 0, 'positive Bernstein coefficients')
    (t0, t1), (u0, u1) = box
    # These 25 points check a polynomial identity of bidegree at most(4,4),
    # not positivity by sampling. Positivity comes from all coefficients.
    for i in range(5):
        for j in range(5):
            t, u = t0+(t1-t0)*i/4, u0+(u1-u0)*j/4
            require(evaluate(polynomial, t, u) == direct_numerator(t, u, *names),
                    'support polynomial identity')
    return coefficients


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=HERE/'positive-sector-certificate.json')
    args = parser.parse_args()
    root_path = SOURCE/'exploration/corner-global-root-N96.json'
    root_bytes = root_path.read_bytes()
    root_hash = hashlib.sha256(root_bytes).hexdigest()
    require(root_hash == 'b40c3fa3270f1e11ac446117575e7422a6994f86459022eae768a3bdd1d0364c',
            'literal H7 source')
    root = json.loads(root_bytes)
    d = ['1.949504', '0.157326']
    require(d in root['history'][-1]['hulls'][5], 'Q low-point binding')
    require(F(d[0]) <= F('1.95') and F(d[1]) <= F('.16'), 'rounded low-point bounds')
    t_intervals = {'row': (F(5, 16), F(37, 100)), 'r2': (F(37, 100), F(5, 12))}
    u_intervals = {'wall': (F(0), F(1, 15)), 'point': (F(1, 15), F(5, 12))}
    require((1+F(5, 12))**2 > 2 and F(5, 12) < 1, 'angular enclosure and denominator')
    records = []
    for names, polynomial in polynomials().items():
        roof_name, support_name = names
        box = (t_intervals[roof_name], u_intervals[support_name])
        coefficients = check_rectangle(polynomial, box, names)
        records.append({
            'roof': roof_name, 'support': support_name,
            't_interval': list(map(str, box[0])), 'u_interval': list(map(str, box[1])),
            'bidegree': [4, 4],
            'power_coefficients': [[str(polynomial.get((i, j), F(0))) for j in range(5)] for i in range(5)],
            'bernstein_coefficients': [[str(value) for value in row] for row in coefficients],
            'minimum_bernstein_coefficient': str(min(map(min, coefficients))),
        })
    result = {
        'verdict': 'PASS_FOUR_RECTANGLE_EARLY_ROW_SECTOR',
        'scope': 'Exact continuous scalar inequality only, conditional on the displayed roof, row-failure, low-point and wall support inequalities. No pose search or full virtual-row theorem is asserted.',
        'side_bounds': [str(A), str(B)],
        'rectangle_count': 4, 'positive_coefficient_count': 100,
        'source_sha256': root_hash,
        'checker_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'proof_sha256': hashlib.sha256((HERE/'positive-sector.tex').read_bytes()).hexdigest(),
        'point_binding': {'owner': 5, 'point': d, 'upper_bounds': ['1.95', '.16']},
        'pair_pruning_receipts_read': [],
        'rectangles': records,
    }
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(result['verdict'])
    for record in records:
        print(record['roof'], record['support'], record['minimum_bernstein_coefficient'])


if __name__ == '__main__':
    main()
