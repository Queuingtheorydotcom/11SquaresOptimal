"""Exact scalar/source checks for the signed-axis composition.

The geometric proof is separately reviewed. No pose pairs are enumerated.
"""
if not __debug__:
    raise SystemExit("Refusing optimized execution")
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3] / "shared-final/n11-global-proof/exploration/corner-global-root-N96.json"


def main():
    r = json.loads(ROOT.read_text())
    assert r["case"] == 6 and r["branch"] == [0, 30, 40] and len(r["history"]) == 7
    hs = r["history"][-1]["hulls"]
    points = {
        "z": (5, ["1.989606", "0.990917"]),
        "d": (5, ["1.949504", "0.157326"]),
        "g": (0, ["1.873613", "1.07226"]),
        "k": (0, ["1.486351", "1.472087"]),
        "p": (0, ["2.377569", "1.447771"]),
    }
    for owner, p in points.values():
        assert p in hs[owner]
    c, s = F(231, 281), F(160, 281)
    assert c*c+s*s == 1
    assert F(".115993")-F(".081343") == F(693, 20000) > 0
    assert -F(".399606")+F(".599083")*s/c == F(1772147, 115500000) > 0
    assert F(231, 160)**3 < 4
    assert 1-F(".92")*F(3,10)-F(".16")/F(3,10)-F(".08") == F(83,750) > 0
    endpoint = 1-F(".92")*c-F(".16")/c-F(".08")*s
    assert endpoint == F(5708,1622775) > 0
    assert F(".5")-F(".025")-F("1.45")*F(".3") == F(".04") > 0
    assert F(".71") < F(4003, 4000) and F("1.48")-F(".71") == F(".77")
    result = {
        "verdict": "PASS_OUTER_SECTOR_SCALARS",
        "scope": "Arithmetic and literal H7 vertices, not a formal geometric proof or global theorem.",
        "root_sha256": hashlib.sha256(ROOT.read_bytes()).hexdigest(),
        "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "proof_sha256": hashlib.sha256((HERE/"full-axis-argument.tex").read_bytes()).hexdigest(),
        "points": {name: {"owner": owner, "point": point} for name,(owner,point) in points.items()},
        "f_at_c0": str(endpoint),
        "f_at_three_tenths_strict_lower": "83/750",
        "near_horizontal_margin": "1/25",
        "pair_pruning_receipts_read": [],
    }
    (HERE/"outer-sector-scalars.json").write_text(json.dumps(result,indent=2)+"\n")
    print(result["verdict"])


if __name__ == "__main__":
    main()
