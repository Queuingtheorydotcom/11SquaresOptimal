"""Same rational pruning as exact_pair_regions, with one input per worker.

Only dispatch changes: each bin calls the original refine_bin function with
the same (poses, domains, bin, N) tuple as the original implementation.
"""
from concurrent.futures import ProcessPoolExecutor
from exact_pair_regions import refine_bin

def initialize(poses,dom,N):
    global SHARED
    SHARED=(poses,dom,N)

def worker(k):
    poses,dom,N=SHARED
    return refine_bin((poses,dom,k,N))

def refine(poses,dom,N,jobs=1):
    bins=sorted({p['k'] for p in poses})
    if jobs>1:
        with ProcessPoolExecutor(max_workers=jobs,initializer=initialize,initargs=(poses,dom,N)) as pool:
            results=list(pool.map(worker,bins))
    else:results=[refine_bin((poses,dom,k,N)) for k in bins]
    retained={};checks=[];old_owner={i:owner for owner,d in enumerate(dom) for i in d}
    for ps,record in results:retained.update(ps);checks.append(record)
    newposes=[];newdom=[set() for d in dom]
    for i in sorted(retained):newdom[old_owner[i]].add(len(newposes));newposes.append(retained[i])
    return newposes,newdom,checks
