"""Join completed exact hull and coarse-bound checks for the corner lemma."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
from marker_cases import POINTS,S,A_LO,A_HI

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
 journal=Path('exploration/corner-global-root-N96.json');j=json.loads(journal.read_text());prefix=Path(str(journal)+'.verified-prefix.json');r=json.loads(prefix.read_text());boxes=Path('corner-boxes-conditional.json');b=json.loads(boxes.read_text());angle=Path('combined-angle-verification.json');a=json.loads(angle.read_text())
 assert j['case']==6 and j['base'] is None and j['base_sha256'] is None and j['bins']==96 and j['branch']==[0,30,40]
 assert j['symmetry_restricted'] and j['terminal'] is None
 assert r['journal_sha256']==b['hypothesis_sha256']==sha(journal)
 assert not r.get('base_assumed') and r['base_sha256'] is None and r['completed_round']==len(j['history'])-1==6
 assert len(r['checks'])==7 and [x['round'] for x in r['checks']]==list(range(7)) and all('checked_new_vertices' in x for x in r['checks'])
 assert b['verdict']=='VERIFIED coarse bounds for corner normalization, conditional on journal hulls' and len(b['records'])==11
 for path,digest in b['source_hashes'].items():assert sha(path)==digest,(path,digest)
 assert a['case']==6 and a['pair_half_angle']=='5/16 < t <= sqrt(2)-1'
 for source in a['sources']:assert sha(source['receipt'])==source['sha256']
 assert F(30,96)==F(5,16) and F(40,96)==F(5,12) and (1+F(5,12))**2>2
 for idx,(x,y) in enumerate(POINTS):
  inward=(x,S-y)
  if idx==3:assert all(0<v<A_LO for v in inward)
  else:assert any(v>=A_HI for v in inward)
 sources=[journal,prefix,boxes,angle,Path('CORNER_NORMALIZATION.md'),Path(__file__),Path('exact_arc_fast.py'),Path('exact_pair_regions_fast.py'),Path('exact_pair_regions.py')]
 result={'verdict':'VERIFIED global existence-preserving corner normalization in the remaining ownership case','case':6,'corner_owner':4,'corner_marker':3,'replacement':'[0,a] x [S-a,S]','normalized_container':str(S),'small_side_interval':[str(A_LO),str(A_HI)],'hypothesis_ancestry_discharged':True,'hull_rounds':7,'checked_new_hull_vertices':sum(v['checked_new_vertices'] for v in r['checks']),'checked_incompatible_pose_pairs':sum(v['exact_incompatible_edges'] for v in r['checks']),'geometric_proof':'CORNER_NORMALIZATION.md','statement':'Every packing in the remaining normalized case can be rearranged, with the other ten squares fixed, so that the C3 owner is the stated axis-aligned corner square. Marker ownership and side length are preserved.','scope':'Combine with the previously completed ownership and angle reductions for an arbitrary hypothetical improvement. The support-domination and separating-line arguments are mathematical proofs in the referenced document. Global optimality is not proved.','source_hashes':{str(p):sha(p) for p in sources}}
 Path('corner-normalization-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_hashes'},indent=2))
if __name__=='__main__':main()
