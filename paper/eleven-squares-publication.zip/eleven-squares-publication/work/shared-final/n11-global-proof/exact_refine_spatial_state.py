"""Exact angle subdivision retaining all inherited center-position constraints."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
from retained_spatial_state import load_seed,serialize
from corner_obstruction_seed import sha
from exact_persistent_journal import bounds,cut_and_round
from exact_poses import clip,area2
from marker_cases import S,A_LO

def main():
 ap=argparse.ArgumentParser();ap.add_argument('source');ap.add_argument('output');ap.add_argument('--factor',type=int,default=2);args=ap.parse_args();d,pp,dd=load_seed(args.source);R=args.factor;assert R>=2;N=R*d['bins'];poses=[];dom=[]
 for own,ids in enumerate(dd):
  new=set()
  for i in sorted(ids):
   p=pp[i];C,T=p['c'],p['s']
   for k in range(p['k']*R,(p['k']+1)*R):
    if own in [3,4] and k!=0:continue
    t=F(2*k+1,2*N);c=(1-t*t)/(1+t*t);s=2*t/(1+t*t);co=c*C+s*T;si=-s*C+c*T
    poly=[(co*x-si*y,si*x+co*y) for x,y in p['poly']]
    w=lambda z:(1+2*z-z*z)/(1+z*z)
    wall=A_LO*min(w(F(k,N)),w(F(k+1,N)))/2
    for n,b in [((c,-s),S-wall),((-c,s),-wall),((s,c),S-wall),((-s,-c),-wall)]:poly=clip(poly,n,b)
    if area2(poly)>0:new.add(len(poses));poses.append({'k':k,'c':c,'s':s,'poly':poly,'own':bounds(poly)})
  dom.append(new)
 gs=[tuple(g) for g in d['groups']];hs={g:[tuple(map(F,p)) for p in h] for g,h in zip(gs,d['hulls'])};poses,dom=cut_and_round(poses,dom,gs,hs,N,10**8)
 sources=[Path(args.source),Path(__file__),Path('retained_spatial_state.py'),Path('exact_persistent_journal.py'),Path('exact_poses.py')]
 out={'method':'exact_refined_spatial_seed','case':6,'bins':N,'normalized_corners':[3,4],'groups':d['groups'],'hulls':d['hulls'],'owners':serialize(poses,dom),'parent_seed':args.source,'spatial_cut':d['spatial_cut'],'source_hashes':{str(p):sha(p) for p in sources},'scope':'Exact necessary domains from a verified retained state, with angle subdivision and conservative cuts.'}
 Path(args.output).write_text(json.dumps(out));print('refined',N,[len(x) for x in dom],flush=True)
if __name__=='__main__':main()
