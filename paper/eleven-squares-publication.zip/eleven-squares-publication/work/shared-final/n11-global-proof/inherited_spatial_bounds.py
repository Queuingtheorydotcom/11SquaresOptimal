"""Collect only globally certified spatial bounds along a seed's ancestry."""
from pathlib import Path
import json
from corner_obstruction_seed import sha
from fixed_spatial_constraints import load_bounds,CERTIFICATE

def load_inherited_bounds(seed):
    bounds=load_bounds();sources={str(Path(CERTIFICATE))};seen=set()
    def visit(path):
        path=Path(path);key=str(path.resolve())
        if key in seen:return
        seen.add(key);d=json.loads(path.read_text())
        for p,h in d.get('source_hashes',{}).items():assert sha(p)==h,p
        if d.get('global_spatial_bounds'):
            p=Path(d['global_spatial_bounds']);r=json.loads(p.read_text())
            assert r['verdict']=='VERIFIED necessary spatial bounds after two-corner normalization'
            assert r['ancestry_discharged'] and r['normalized_corners']==[3,4] and r['case']==6
            for q,h in r['source_hashes'].items():assert sha(q)==h,q
            sources.add(str(p));bounds.extend(r['necessary_halfplanes'])
        for field in ['root','parent_seed','global_retained_parent','unbounded_root','rectangle_core_parent']:
            if d.get(field):visit(d[field])
    visit(seed)
    unique={}
    for b in bounds:unique[(b['owner'],tuple(b['normal']),b['upper'])]=b
    return list(unique.values()),sorted(sources)
