"""Rational exclusion by all actual separating-edge angle arcs."""
from fractions import Fraction as F
from exact_arc_hulls import Compatibility as InnerCompatibility
from marker_cases import S,A_LO

def normal(t):return ((1-t*t)/(1+t*t),2*t/(1+t*t))

class Compatibility(InnerCompatibility):
    def __init__(self,poses,N):
        super().__init__(poses,N);assert 2*S*S<36
        self.N=N;self.endpoint={q:normal(F(q,N)) for p in poses for q in (p['k'],p['k']+1)}
        self.arc_answers={};self.endpoint_ranges={};self.thresholds={};self.arc_edges=0
        self.xy=[[(p['c']*u-p['s']*v,p['s']*u+p['c']*v) for u,v in p['poly']] for p in poses]
        self.fxy=[[(float(x),float(y)) for x,y in poly] for poly in self.xy]

    def threshold(self,k,l):
        key=(min(k,l),max(k,l))
        if key not in self.thresholds:
            if abs(k-l)<=1:g=F(1)
            else:
                vals=[]
                for a,b in [(k,l+1),(k+1,l)]:
                    c,s=self.endpoint[a];C,T=self.endpoint[b]
                    vals.append(abs(c*C+s*T)+abs(c*T-s*C))
                g=min(vals)
            self.thresholds[key]=A_LO*(1+g)/2-F(3,self.N*self.N)
        return self.thresholds[key]

    def endpoint_project(self,i,k):
        key=(i,k)
        if key not in self.endpoint_ranges:
            c,s=self.endpoint[k];xy=self.xy[i]
            xx=[c*x+s*y for x,y in xy];yy=[-s*x+c*y for x,y in xy]
            self.endpoint_ranges[key]=(min(xx),max(xx),min(yy),max(yy))
        return self.endpoint_ranges[key]

    def compatible(self,i,j):
        key=(min(i,j),max(i,j))
        if key in self.arc_answers:return self.arc_answers[key]
        if not super().compatible(i,j):self.arc_answers[key]=False;return False
        p,q=self.poses[i],self.poses[j];threshold=self.threshold(p['k'],q['k'])
        # A heuristic positive answer only retains an extra compatibility edge.
        for k in [p['k'],p['k']+1,q['k'],q['k']+1]:
            c,s=map(float,self.endpoint[k])
            for nx,ny in [(c,s),(-s,c)]:
                xx=[nx*x+ny*y for x,y in self.fxy[i]];yy=[nx*x+ny*y for x,y in self.fxy[j]]
                if max(max(xx)-min(yy),max(yy)-min(xx))>=float(threshold)-1e-9:
                    self.arc_answers[key]=True;return True
        for k in [p['k'],p['k']+1,q['k'],q['k']+1]:
            a0,a1,b0,b1=self.endpoint_project(i,k);x0,x1,y0,y1=self.endpoint_project(j,k)
            if max(a1-x0,x1-a0,b1-y0,y1-b0)>=threshold:
                self.arc_answers[key]=True;return True
        self.arc_answers[key]=False;self.arc_edges+=1;self.exact_edges+=1;return False
