# A virtual bottom row for the common owner

Let P be the C1 owner, Q the W0 owner, and G the common owner of markers
I0 and I1. After the established normalizations, define

\[
 E_b=[S-2a,S]\times[0,a].
\]

The interiors of G and E_b are disjoint. This is a virtual obstacle for G;
it does not assert that P and Q can be moved into this row while preserving
their nonoverlap with every other square.

The exact global pose cover at N=384 puts both whole squares P and Q in
0<=y<=3a/2. Apply STRIP_SUPPORT_DOMINATION.md in coordinates U=S-x, V=y.
Their union has support at least that of E_b in all directions (-v,u),
u,v>=0.

Condition G on possible intersection with E_b, conservatively using
[S-2 A_HI,S] x [0,A_HI] enlarged by its outer reference square.
The exact check bottom_pair_neighbor_axes.py excludes every separating
axis between G and Q except G's own NW normal n=(-sin(theta),cos(theta)).
All 1,575 signed-axis checks have positive rational margins. A further
180 checks separate P from G along this same normal. Thus nonoverlap with
Q forces h_Q(n)<=l_G(n), and h_P(n)<l_G(n). Support domination gives
h_Eb(n)<=l_G(n), contrary to interior intersection. This discharges the
conditioning hypothesis.

The corner p(a)=(S-2a,a) cannot lie in G's interior. The unconditioned pose
cover, for all a in [A_LO,A_HI], puts p(a) strictly inside G's strip along
the edge direction (cos(theta),sin(theta)). It also puts its projection
relative to G's center along n strictly below zero. These two assertions
are checked rationally at the angle endpoints with chord error 1/(2N^2),
using |p(a)-center(G)|<1. Consequently G can exclude p(a) only below its
lower n-edge. Every feasible G satisfies

\[
 -\sin\theta X+\cos\theta Y
 \ge -\sin\theta S+a(2\sin\theta+\cos\theta+1/2).
\]

In particular, because a>A_LO,

\[
 F_b(\theta)=\sin\theta(S-X-2A_{LO})
  +\cos\theta(Y-A_{LO})-A_{LO}/2>0.
\]

The exact pose cover puts G's center in [1.90,1.94] x [1.67,1.705],
and the vector in this last trigonometric expression has length below 1.
At least one endpoint of its angle bin therefore satisfies
F_b>-1/(2N^2). Intersect the center polygon with each of these two rational
halfplanes and convexify their union. This is a necessary constraint,
preserves all actual feasible centers, and can be reapplied after rounding.
