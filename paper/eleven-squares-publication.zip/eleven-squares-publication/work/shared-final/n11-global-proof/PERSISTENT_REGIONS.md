# Exact propagation with retained center regions

This method strengthens the existing necessary-condition propagation. A
surviving domain does not establish that a packing exists. Global optimality
remains unproved.

In an angle bin, represent possible square centers by a rational convex
polygon in the coordinates of the bin's midpoint orientation. The existing
pose cover supplies an outer square containing every actual square in the
bin, and an inner square contained strictly inside every actual square.
Retain the center polygon between deduction sweeps, rather than reconstructing
it from compulsory points and losing earlier position restrictions.

Each sweep performs the following safe operations:

1. Apply `exact_pair_regions.refine_bin` to remove centers for which the
   corresponding inner square overlaps every remaining pose of another owner.
   Its floating calculations can only skip pruning; every actual removal is
   constructed with rational arithmetic.
2. Apply the existing rational pairwise compatibility and domain-deletion
   routines. A real packing supplies mutually compatible poses, so none of
   its poses can be removed by these implications.
3. Check every proposed new compulsory vertex against every remaining inner
   square pose of its owner. Thus the vertex really belongs to that owner
   in every surviving actual packing.
4. Apply the outer-square inequalities for its owner's compulsory polygon
   and the inner-square nonintersection inequalities for all other owners'
   compulsory polygons. Convexification only enlarges a remaining domain.
5. Round each remaining polygon outward using the 16 integer normals
   `(1,0),(2,1),(1,1),(1,2)` and their quarter-turn rotations. For each normal
   `n`, compute the exact support `b=max(n.p)` over the polygon and replace
   it by `(ceil(D*b)+1)/D`, where `D=100000000`. Intersect these half-planes
   with the universal center box `[-8,8]^2`. Every genuine center is strictly
   inside this box because the physical container has side 3.88. Each rounded
   support is strictly larger than the original support, so this rounding
   cannot delete a genuine center.

The inner-square and outer-square margins give every genuine center strict
slack in the relevant inequalities, as in the original pose-cover argument.
Consequently zero-area remainders do not hide genuine feasible centers. The
branch restrictions here concern only angle intervals, not spatial cuts;
interval endpoints are included in the corresponding closed bin cover.

The induction invariant is that every actual packing satisfying the journal's
angle cuts has a represented pose for each owner. An empty owner domain
therefore proves an exclusion under those cuts. Newly checked compulsory
polygons can be inherited by a finer-grid journal; that continuation starts
with a fresh conservative cover and does not assume unrecorded center domains.

`persistent_journal.py` proposes hulls numerically. Its output alone proves
nothing. `exact_persistent_journal.py` recomputes all geometry using rational
arithmetic and checks the proposed vertices before using them. The default
checker also verifies the complete base ancestry. `--assume-base` instead
writes only a conditional receipt. `assemble_persistent_replays.py` can join
such receipts after checking all source hashes, completed root and intermediate
prefixes, nested physical angle cuts, ownership groups, symmetry scope, and
the terminal empty domain. It discharges the base assumptions; it does not
replace a fresh geometric replay.

`exact_pair_regions_fast.py` changes only multiprocessing dispatch: each bin
calls the unchanged original `refine_bin` function with identical arguments.
`exact_arc_fast.py` uses that dispatcher with the existing arc-hull checker.
All exact programs use Python's standard library. Do not run with `python -O`,
which would disable the comparison assertions.

Completed exclusions, if any, are recorded separately in `STATUS.json` and
`RESEARCH.md`. Prefix receipts certify only their completed implications.
