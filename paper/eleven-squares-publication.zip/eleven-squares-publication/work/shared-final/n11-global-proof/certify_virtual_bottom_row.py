"""Exact premises and assembly of the Common owner's virtual bottom row."""
from fractions import Fraction as F
from pathlib import Path
import json
from spatial_branch_seed import validate_root
from marker_cases import S,A_LO,A_HI
from exact_edge_arc_compatibility import normal
from corner_obstruction_seed import sha

def main():
    source=Path('exploration/ten-bound-global-N384-certified-seed.json')
    d=validate_root(source);N=d['bins'];H=A_HI*(1+F(1,N))/2
    axes=Path('exploration/ten-bound-global-N384-bottom-axes.json');ar=json.loads(axes.read_text())
    assert ar['verdict']=='VERIFIED Common virtual-row separator hypotheses'
    assert ar['unresolved_axis_checks']==ar['unresolved_C1_checks']==0
    assert ar['source_hashes'][str(source)]==sha(source)
    theorem=Path('strip-support-identities-verification.json');tr=json.loads(theorem.read_text())
    for r in [ar,tr]:
        for p,h in r['source_hashes'].items():assert sha(p)==h,p
    strips=[]
    for own in [2,5]:
        top=F(0)
        for p in d['owners'][own]:
            c,s=F(p['c']),F(p['s'])
            top=max(top,max(s*F(u)+c*F(v) for u,v in p['poly'])+H*(c+s))
        margin=3*A_LO/2-top;assert margin>0
        strips.append({'owner':own,'whole_square_upper_y':str(top),'strip_margin':str(margin)})
    minimum=None;signmargin=None;maxnorm=F(0);checked=0
    for p in d['owners'][0]:
        C,T=F(p['c']),F(p['s']);xy=[(C*F(u)-T*F(v),T*F(u)+C*F(v)) for u,v in p['poly']]
        for X,Y in xy:
            assert F(19,10)<=X<=F(97,50) and F(167,100)<=Y<=F(341,200)
            for a in [A_LO,A_HI]:
                dx,dy=S-2*a-X,a-Y
                maxnorm=max(maxnorm,dx*dx+dy*dy);assert dx*dx+dy*dy<1
                for k in [p['k'],p['k']+1]:
                    c,s=normal(F(k,N));projection=c*dx+s*dy
                    margin=A_LO/2-abs(projection)-F(1,2*N*N);assert margin>0
                    negative=s*dx-c*dy-F(1,2*N*N);assert negative>0
                    minimum=margin if minimum is None else min(minimum,margin)
                    signmargin=negative if signmargin is None else min(signmargin,negative);checked+=1
    sources=[source,axes,theorem,Path(__file__),Path('VIRTUAL_BOTTOM_ROW.md'),Path('STRIP_SUPPORT_DOMINATION.md'),Path('exact_edge_arc_compatibility.py')]
    out={'verdict':'VERIFIED global virtual-bottom-row obstacle and Common support inequality','ancestry_discharged':True,'owner':0,'virtual_rectangle':'[S-2a,S] x [0,a]','strip_checks':strips,'endpoint_strip_checks':checked,'minimum_strip_margin':str(minimum),'minimum_negative_projection_margin':str(signmargin),'maximum_squared_point_distance':str(maxnorm),'coarse_center_box':['19/10','97/50','167/100','341/200'],'necessary_inequality':'-sin(theta)*X+cos(theta)*Y >= -sin(theta)*S+a*(2*sin(theta)+cos(theta)+1/2)','source_hashes':{str(p):sha(p) for p in sources},'scope':'A globally necessary inequality after normalization; no physical replacement of the bottom pair or global optimality is asserted.'}
    Path('virtual-bottom-row-verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out['verdict']);print('strip margins',[float(F(r['strip_margin'])) for r in strips]);print('point strip margin',float(minimum))
if __name__=='__main__':main()
