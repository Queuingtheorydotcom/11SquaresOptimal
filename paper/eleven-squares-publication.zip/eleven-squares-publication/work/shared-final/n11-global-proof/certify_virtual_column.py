"""Assemble the virtual-column theorem and certify its endpoint cut premises."""
from fractions import Fraction as F
from pathlib import Path
import json
from spatial_branch_seed import validate_root
from marker_cases import S,A_LO,A_HI
from exact_edge_arc_compatibility import normal
from corner_obstruction_seed import sha

def main():
    source=Path('exploration/eight-spatial-bounds-certified-seed.json');d=validate_root(source);N=d['bins']
    axes=Path('exploration/eight-bound-I2-column-axes.json');ar=json.loads(axes.read_text())
    strip=Path('lower-right-strip-verification.json');sr=json.loads(strip.read_text())
    assert ar['verdict']=='VERIFIED I2 virtual-column separator hypotheses'
    assert ar['unresolved_axis_checks']==ar['unresolved_C1_checks']==0
    assert sr['verdict']=='VERIFIED global lower-right two-square support domination after normalization'
    for r in [ar,sr]:
        assert r['source_hashes'][str(source)]==sha(source)
        for p,h in r['source_hashes'].items():assert sha(p)==h,p
    minimum=None;maxnorm=F(0);checked=0
    for p in d['owners'][9]:
        C,T=F(p['c']),F(p['s']);xy=[(C*F(u)-T*F(v),T*F(u)+C*F(v)) for u,v in p['poly']]
        for X,Y in xy:
            assert F(12,5)<=X<=F(27,10) and F(23,10)<=Y<=F(13,5)
            for a in [A_LO,A_HI]:
                dx,dy=S-a-X,2*a-Y;assert dx>0 and dy<0
                maxnorm=max(maxnorm,dx*dx+dy*dy);assert dx*dx+dy*dy<1
                for k in [p['k'],p['k']+1]:
                    c,s=normal(F(k,N));projection=c*dx+s*dy
                    margin=A_LO/2-abs(projection)-F(1,2*N*N);assert margin>0
                    minimum=margin if minimum is None else min(minimum,margin);checked+=1
    sources=[source,axes,strip,Path(__file__),Path('VIRTUAL_COLUMN.md'),Path('STRIP_SUPPORT_DOMINATION.md'),Path('strip-support-identities-verification.json'),Path('exact_edge_arc_compatibility.py')]
    out={'verdict':'VERIFIED global virtual-column obstacle and I2 support inequality','ancestry_discharged':True,'owner':9,'virtual_rectangle':'[S-a,S] x [0,2a]','endpoint_strip_checks':checked,'minimum_strip_margin':str(minimum),'maximum_squared_point_distance':str(maxnorm),'coarse_center_box':['12/5','27/10','23/10','13/5'],'necessary_inequality':'-sin(theta)*X+cos(theta)*Y >= -sin(theta)*S+a*(sin(theta)+2*cos(theta)+1/2)','source_hashes':{str(p):sha(p) for p in sources},'scope':'A globally necessary inequality after normalization. P and Q have not been replaced; no third-corner normalization or global optimality is asserted.'}
    Path('virtual-column-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(out['verdict']);print('strip margin',float(minimum),'squared norm',float(maxnorm))
if __name__=='__main__':main()
