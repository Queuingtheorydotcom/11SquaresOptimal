"""Exclude non-inward separators for possible canonical-C2 interference.

Owner 7 is reserved for a separate geometric obstruction exclusion. For owner
9 the verified seed already conditions its center on possible interference.
Endpoint interpolation uses |center difference| < 6 and angle width <= 2/N.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,time
from corner_obstruction_seed import load_seed,sha
from exact_corner_normalization import outer_poly,direction,dot,rot,project,gmin
from marker_cases import S,A_LO,A_HI

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--seed',default='exploration/inner-obstruction-certified-seed.json');ap.add_argument('--output',default='second-corner-axes-verification.json');args=ap.parse_args();start=time.time()
 seed,poses,dom=load_seed(args.seed);assert seed['obstructor']==9;N=seed['bins'];owners=[[outer_poly(poses[i]) for i in sorted(d)] for d in dom];P=owners[3]
 box=[(S-A_HI,S-A_HI),(S,S-A_HI),(S,S),(S-A_HI,S)];H=A_HI*(1+F(1,N))/2;error=F(3,N*N);records=[];cache={};minimum=None;checks=0
 for other,Q in enumerate(owners):
  if other in [3,7]:continue
  direct=0;checked=0
  for q in Q:
   separate=False
   for n in [(F(1),F(0)),(F(0),F(1)),(q['c'],q['s']),(-q['s'],q['c'])]:
    support=H*(abs(n[0]*q['c']+n[1]*q['s'])+abs(-n[0]*q['s']+n[1]*q['c']));lo,hi=project(n,q['poly']);a,b=project(n,box)
    if lo-support>b or a>hi+support:separate=True;break
   if separate:direct+=1;continue
   for p in P:
    key=(p['k'],q['k'])
    if key not in cache:cache[key]=A_LO*(1+gmin(*key,N))/2-error
    threshold=cache[key]
    for ownerpose in [p,q]:
     endpoints=[direction(F(ownerpose['k'],N)),direction(F(ownerpose['k']+1,N))]
     for axis in [0,1]:
      ns=[rot(n) if axis else n for n in endpoints]
      for sign in [-1,1]:
       normals=[(sign*n[0],sign*n[1]) for n in ns]
       if all(n[0]<=0 and n[1]<=0 for n in normals):continue
       upper=max(project(n,q['poly'])[1]-project(n,p['poly'])[0] for n in normals);margin=threshold-upper
       assert margin>0,('non-inward axis remains',other,p['k'],q['k'],axis,sign,float(margin))
       minimum=margin if minimum is None else min(minimum,margin);checked+=1
  records.append({'other_owner':other,'poses':len(Q),'directly_separated':direct,'non_inward_signed_axes_excluded':checked});checks+=checked;print(records[-1],flush=True)
 paths=[Path(args.seed),Path(str(args.seed)+'.verified.json'),Path(__file__),Path('exact_corner_normalization.py'),Path('corner_obstruction_seed.py')]
 receipt={'verdict':'VERIFIED second-corner replacement against all owners except 7','corner_owner':3,'reserved_owner':7,'conditioned_owner':9,'records':records,'non_inward_signed_axes_excluded':checks,'minimum_margin':str(minimum),'minimum_margin_decimal':float(minimum),'source_hashes':{str(p):sha(p) for p in paths},'ancestry_discharged':True,'scope':'Together with the corner-support lemma, excludes new interior overlap against owners other than 7. Does not exclude the existence of packings.','seconds':time.time()-start}
 Path(args.output).write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['verdict'],float(minimum),time.time()-start,flush=True)
if __name__=='__main__':main()
