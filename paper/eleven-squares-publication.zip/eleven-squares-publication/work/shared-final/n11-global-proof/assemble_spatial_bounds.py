"""Join completed spatial exclusions into necessary center halfplanes."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json
from retained_spatial_state import load_seed
from corner_obstruction_seed import sha

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('receipts',nargs='+');args=ap.parse_args();bounds=[];sources=[];totals={'new_hull_vertices':0,'incompatible_pose_pairs':0}
 for file in args.receipts:
  p=Path(file);r=json.loads(p.read_text());assert r['verdict']=='VERIFIED SPATIAL BRANCH EXCLUSION' and r['ancestry_discharged'] and r['normalized_corners']==[3,4]
  for source,h in r['source_hashes'].items():assert sha(source)==h,source
  journal=next(Path(s) for s,h in r['source_hashes'].items() if h==r['journal_sha256']);j=json.loads(journal.read_text());seed,_,_=load_seed(j['seed']);assert sha(j['seed'])==r['seed_sha256'] and seed['spatial_cut']==r['spatial_cut']
  assert any(v==0 for v in r['checks'][-1]['active'])
  cut=r['spatial_cut'];assert len(cut['inequalities'])==1
  nx,ny,b=map(F,cut['inequalities'][0]);bounds.append({'owner':cut['owner'],'normal':[str(-nx),str(-ny)],'upper':str(-b),'strict':True,'exclusion':str(p)})
  totals['new_hull_vertices']+=sum(q.get('checked_new_vertices',0) for q in r['checks']);totals['incompatible_pose_pairs']+=sum(q['exact_incompatible_edges'] for q in r['checks']);sources.extend([p,journal,Path(j['seed'])])
 sources.extend([Path(__file__),Path('retained_spatial_state.py')]);out={'verdict':'VERIFIED necessary spatial bounds after two-corner normalization','case':6,'normalized_corners':[3,4],'ancestry_discharged':True,'necessary_halfplanes':bounds,'totals':totals,'source_hashes':{str(p):sha(p) for p in sources},'scope':'Every hypothetical improvement has a normalized representative satisfying these strict center inequalities. No global optimality conclusion.'}
 Path(args.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='source_hashes'},indent=2))
if __name__=='__main__':main()
