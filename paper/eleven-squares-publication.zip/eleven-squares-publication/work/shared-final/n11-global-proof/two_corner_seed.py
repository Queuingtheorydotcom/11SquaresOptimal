"""Exact necessary domains after the proved two-corner normalization."""
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse,json
from corner_obstruction_seed import foundation,sha,intersect
from marker_cases import S,A_LO,A_HI,all_cases,groups
from forced_markers import hull
from exact_arc_hulls import make_owner
from exact_poses import clip,area2

def owner_task(args):
 own,N,gs,hs=args;branch=(int(F(5,16)*N),int(F(5,12)*N)) if own==0 else ((0,1) if own in [3,4] else None)
 ps=make_owner((gs[own],N,gs,hs,{gs[0]:F(5,12)},branch));out=[]
 for p in ps:
  c,s=p['c'],p['s'];poly=p['poly']
  if own in [3,4]:
   xlo,xhi=(S-A_HI/2,S-A_LO/2) if own==3 else (A_LO/2,A_HI/2)
   for n,b in [((c,-s),xhi),((-c,s),-xlo),((s,c),S-A_LO/2),((-s,-c),-(S-A_HI/2))]:poly=clip(poly,n,b)
  if area2(poly)>0:out.append({'k':p['k'],'c':str(c),'s':str(s),'poly':[[str(x),str(y)] for x,y in poly]})
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--bins',type=int,default=96);ap.add_argument('--jobs',type=int,default=4);ap.add_argument('--output',required=True);args=ap.parse_args();N=args.bins;assert N%48==0
 base=foundation();receipt=Path('second-corner-normalization-verification.json');r=json.loads(receipt.read_text());assert r['hypothesis_ancestry_discharged']
 for p,h in r['source_hashes'].items():assert sha(p)==h,p
 gs=groups(all_cases()[0][6]);hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,base['history'][-1]['hulls'])}
 for own in [3,4]:
  xx=(S-A_LO,S) if own==3 else (F(0),A_LO)
  hs[gs[own]]=hull(hs[gs[own]]+[(x,y) for x in xx for y in [S-A_LO,S]])
 with ProcessPoolExecutor(max_workers=args.jobs) as pool:owners=list(pool.map(owner_task,[(own,N,gs,hs) for own in range(11)]))
 sources=[receipt,Path(__file__),Path('corner_obstruction_seed.py'),Path('exact_arc_hulls.py'),Path('exact_poses.py')]
 d={'method':'exact_two_corner_seed','case':6,'bins':N,'normalized_corners':[3,4],'groups':[list(g) for g in gs],'hulls':[[[str(x),str(y)] for x,y in hs[g]] for g in gs],'owners':owners,'source_hashes':{str(p):sha(p) for p in sources},'scope':'Necessary outer domains for a packing after the two existence-preserving corner replacements; no exclusion.'}
 p=Path(args.output);p.write_text(json.dumps(d));poses=[];spans=[]
 for owner in owners:
  a=len(poses)
  for q in owner:
   c,s=F(q['c']),F(q['s']);poly=[tuple(map(F,z)) for z in q['poly']]
   poses.append({'k':q['k'],'c':float(c),'s':float(s),'t':(q['k']+.5)/N,'dt':1/(2*N),'poly':[(float(c*x-s*y),float(s*x+c*y)) for x,y in poly]})
  spans.append((a,len(poses)))
 state={'case':6,'bins':N,'groups':d['groups'],'hulls':[[[float(F(x)),float(F(y))] for x,y in h] for h in d['hulls']],'poses':poses,'spans':spans,'history':[],'terminal':None,'scope':'Floating view of exact two-corner seed','seed_sha256':sha(p)}
 Path(str(p)+'.float.json').write_text(json.dumps(state));print('seed counts',[len(o) for o in owners],flush=True)
if __name__=='__main__':main()
