"""Exact polynomial identities for STRIP_SUPPORT_DOMINATION.md."""
from fractions import Fraction as F
class P:
 def __init__(self,d):self.d={k:F(v) for k,v in (d if isinstance(d,dict) else {(0,0):d}).items() if v}
 def __add__(self,o):
  if not isinstance(o,P):o=P(o)
  d=self.d.copy()
  for k,v in o.d.items():d[k]=d.get(k,0)+v
  return P(d)
 __radd__=__add__
 def __neg__(self):return P({k:-v for k,v in self.d.items()})
 def __sub__(self,o):return self+-o if isinstance(o,P) else self+P(-o)
 def __rsub__(self,o):return -self+o
 def __mul__(self,o):
  if not isinstance(o,P):o=P(o)
  d={}
  for (i,j),v in self.d.items():
   for (k,l),w in o.d.items():d[i+k,j+l]=d.get((i+k,j+l),0)+v*w
  return P(d)
 __rmul__=__mul__
 def __pow__(self,n):
  p=P(1)
  for _ in range(n):p=p*self
  return p
 def divide_t_minus(self,b):
  p=self;q=P(0)
  while p.d and max(k[0] for k in p.d)>=1:
   n=max(k[0] for k in p.d);term=P({(n-1,j):v for (i,j),v in p.d.items() if i==n});q=q+term;p=p-term*(t-b)
  assert not p.d,p.d
  return q
 def show(self):
  for i in sorted(set(k[0] for k in self.d)):
   print('t^',i,':',[(j,str(self.d[i,j])) for j in sorted(j for k,j in self.d if k==i)])

from pathlib import Path
import hashlib,json

def eq(x,y):assert x.d==y.d,(x.d,y.d)
def subst(p,x):
 out=P(0)
 for (i,j),v in p.d.items():out=out+v*(x**i)*(b**j)
 return out

t=P({(1,0):1});b=P({(0,1):1});D=1+t*t;C=1-t*t;S=2*t;W=C+S
Rb=1-b*b;Ab=1+2*b-b*b;Ad=(1+b)**2
G=1+b*b+2*(b-1)*t-Ab*t*t
Fp=Rb*(b+t)+(2+7*b+6*b*b+b**3)*t*t-(1+2*b)*Rb*t**3
Fm=-b*Rb+(1+b)**3*t-(1+2*b)*Rb*t*t
checks=0
for sign in [1,-1]:
 cap=2*(Rb+2*b)*D-(Rb*C+2*b*S+sign*(2*b*C-Rb*S))
 numB=S*cap*Ad-(2*b*S+Rb*C)*W*Ad+2*Rb*Ab*C*D-Rb*D*D*Ad
 eq(numB,4*(t-b)*Fp if sign==1 else 4*(t-b)*(t-1)*Fm);checks+=1
 if sign==1:
  numA=C*cap*Ad+(Rb*S-2*b*C)*W*Ad-2*Rb*Ab*S*D-Rb*D*D*Ad
  eq(numA,2*S*(C*((Rb+2*b)*t+Rb-2*b)*Ad-Rb*Ab*D));checks+=1
 else:
  numA=C*cap*Ad+2*(Rb*S-2*b*C)*((Ad+Ab)*D-F(1,2)*Ad*W)-2*Rb*Ab*S*D-Rb*D*D*Ad
  eq(numA*(1+t)**2,4*C*(Ad*C*(b*(1+t)**2-Rb*t*t)-b*Ab*D*(1+t)**2));checks+=1
pairs=[
 (C*((Rb+2*b)*t+Rb-2*b)-Rb*(1-b)*D,(t-b)*G),
 (subst(G,b),(1-b)**2*(1+b*b)),
 (subst(Fm,b),2*b*b*(1+b)*(1+b*b)),
 (subst(Fm,P(1)),4*b*b*(1+b)),
 ((2+7*b+6*b*b+b**3)-(1+2*b)*Rb,1+5*b+7*b*b+3*b**3),
 (Ab-(1-b)*Ad,b*(1+b*b)),
 (2*Ab-Ad,(1-b)*(1+3*b)),
 (Rb*(Ad-Rb*b),(1-b)*(1+b*b)*Ad),
]
for x,y in pairs:eq(x,y);checks+=1
sources=[Path(__file__),Path('STRIP_SUPPORT_DOMINATION.md')]
out={'verdict':'VERIFIED exact polynomial identities supporting the strip support theorem','identities':checks,'source_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'scope':'The geometric reduction, sign arguments, and interior perturbation are proved in STRIP_SUPPORT_DOMINATION.md. This checker uses exact rational polynomial arithmetic, not numerical angle samples.'}
Path('strip-support-identities-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['verdict'],checks)
