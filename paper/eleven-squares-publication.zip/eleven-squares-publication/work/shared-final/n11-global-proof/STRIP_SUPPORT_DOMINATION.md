# Two squares in a strip: support domination by a straight row

Let P and Q be interior-disjoint unit squares contained in

\[
 x\ge0,\qquad 0\le y\le\frac32.
\]

Then, for every r>0,

\[
 \boxed{\max_{z\in P\cup Q}(r z_x+z_y)\ge2r+1.} \tag{1}
\]

The row [0,2] x [0,1] attains equality for all r. By taking limits, its
support is at most that of P union Q in every direction with nonnegative
components. This is a support comparison, not a claim that the entire row
is contained in the union or its convex hull.

## 1. A forced point for each direction

Fix r>0 and put

\[
 d=\sqrt{1+r^2},\quad b=d-r\in(0,1),\quad
 \alpha=\frac{r+1}{d+1}
       =\frac{1+2b-b^2}{(1+b)^2}.
\]

In particular 1/2<alpha<1, and

\[
 \alpha-(1-b)=\frac{b(1+b^2)}{(1+b)^2}>0. \tag{2}
\]

We prove that every unit square contained in

\[
 T_r=\{x,y\ge0:\ y\le1+\alpha,\ rx+y\le2r+1\}
\]

contains p=(1,alpha). For a square with edge directions (c,s),(-s,c),
c,s>=0 and c^2+s^2=1, write its center (X,Y), w=c+s, and

\[
 M=\frac{rc+s+|c-rs|}{2},\qquad D=2r+1-M.
\]

Containment gives

\[
 X,Y\ge w/2,\quad Y\le1+\alpha-w/2,\quad rX+Y\le D. \tag{3}
\]

Two edge inequalities follow from the walls:

\[
\begin{aligned}
 c(1-X)+s(\alpha-Y)&\le c+\alpha s-w^2/2\le1/2,\\
 -s(1-X)+c(\alpha-Y)&\ge-w+w^2/2\ge-1/2.
\end{aligned} \tag{4}
\]

The first uses c+s<=1+cs and alpha<1; the second uses (w-1)^2>=0.
It remains to show A<=1/2 and B<=1/2, where

\[
 A=c(X-1)+s(Y-\alpha),\qquad
 B=s(X-1)-c(Y-\alpha).
\]

Write t=s/(1+c) in [0,1]. The breakpoint c=rs is exactly t=b.

## 2. The inequality A<=1/2

If c>=rs, substitute X<=(D-Y)/r and Y>=w/2 into A. This gives

\[
 A-\frac12\le s\left(\frac c r((r+1)t+r-1)-\alpha\right).
\]

For 0<=t<=b, the expression before alpha is at most 1-b. Indeed its
difference from 1-b is

\[
 \frac{(t-b)G(t)}{(1-b^2)(1+t^2)},\qquad
 G(t)=1+b^2+2(b-1)t-(1+2b-b^2)t^2.
\]

G is concave, G(0)=1+b^2>0, and
G(b)=(1-b)^2(1+b^2)>0. Equation (2) therefore proves the claim.

If c<=rs, use Y<=1+alpha-w/2 instead. Direct simplification gives

\[
 A-\frac12\le\frac c r
 \left[c\left(1-\frac{2rt^2}{(1+t)^2}\right)-\alpha\right].
\]

For t>=b, the expression c(1-2rt^2/(1+t)^2) is at most its value
1-b at t=b: both factors decrease while the second is nonnegative;
if the second becomes negative, the expression is already <=0.
Again (2) proves A<=1/2. The endpoint c=0 follows directly.

## 3. The inequality B<=1/2

Use X<=(D-Y)/r and Y>=w/2 to obtain

\[
 B\le\overline B
 :=s(D/r-1)-(s/r+c)w/2+c\alpha.
\]

Put E=(1-b^2)(1+b)^2(1+t^2)^2>0. Exact algebra gives

\[
\overline B-\frac12=
\begin{cases}
 2(t-b)F_+(t)/E,&0\le t\le b,\\
 2(t-b)(t-1)F_-(t)/E,&b\le t\le1,
\end{cases}
\]

where

\[
\begin{aligned}
F_+(t)={}&(1-b^2)(b+t)
 +(2+7b+6b^2+b^3)t^2-(1+2b)(1-b^2)t^3,\\
F_-(t)={}&-b(1-b^2)+(1+b)^3t-(1+2b)(1-b^2)t^2.
\end{aligned}
\]

F_+ is positive on [0,1]: the coefficient remaining with t^2 after
bounding t<=1 is at least 1+5b+7b^2+3b^3>0, and its other terms are
nonnegative. F_- is concave and has positive endpoint values on [b,1]:

\[
 F_-(b)=2b^2(1+b)(1+b^2),\qquad F_-(1)=4b^2(1+b).
\]

Thus both displayed expressions are nonpositive. The rational polynomial
identities, including the endpoint evaluations, are independently checked
by verify_strip_support_identities.py; no angle sampling is used in the proof.
This completes the forced-point assertion.

## 4. Interior details and the two-square conclusion

Suppose the weighted support is strictly below 2r+1. The final inequality
in (3) is then strict. If c,s>0, both inequalities in (4) are strict;
the substitutions for A and B use the strict cap bound with coefficients
c/r and s/r, respectively. Consequently p is interior to the square.

For an axis-aligned square, its right and top edges are at least x=1 and
y=1. The strict cap bound forces its left edge strictly below x=1.
Its bottom edge is at most y=alpha. Thus p can only lie on its right or
bottom edge, and p+epsilon(-1,1) is interior for sufficiently small
positive epsilon. A single sufficiently small epsilon works simultaneously
for two squares, including when one or both are rotated.

If both P and Q had support strictly below 2r+1, the strip height 3/2 is
less than 1+alpha, so both belong to T_r. The common perturbation would
belong to both interiors, a contradiction. This proves (1).

## 5. Packing interpretation

Scale by a and use inward lower-right coordinates U=y, V=S-x. If two
side-a squares lie in 0<=V<=3a/2 and U>=0, their union has support at least
that of the canonical two-square column

\[
 [S-a,S]\times[0,2a]
\]

in every normal (-v,u) with u,v>=0. In particular, every common separating
line with such a normal remains a valid separator after replacing the pair
by that column. To deduce a normalization, one still must establish that
each remaining square either misses the new column or has such a common
separator from the original pair. Pairwise nonoverlap alone does not give
that additional assertion.
