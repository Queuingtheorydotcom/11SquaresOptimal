"""Exact persistent replay of spatial branches; no assumed geometric ancestry."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json,time
from retained_spatial_state import load_seed,serialize
from corner_obstruction_seed import sha
from forced_markers import hull
from exact_poses import contains
from exact_arc_hulls import Compatibility,reduce_domains
from exact_pair_regions_fast import refine
from exact_persistent_journal import cut_and_round

def main():
 ap=argparse.ArgumentParser();ap.add_argument('journal');ap.add_argument('--dump-state');ap.add_argument('--jobs',type=int,default=4);args=ap.parse_args();path=Path(args.journal);data=json.loads(path.read_text())
 assert data['method']=='corner_obstruction_persistent' and data['seed_sha256']==sha(data['seed'])
 seed,poses,dom=load_seed(data['seed']);N=seed['bins'];den=data['rounding_denominator'];assert N==data['bins'] and isinstance(den,int) and den>0
 gs=[tuple(g) for g in seed['groups']];assert data['groups']==seed['groups'];hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,seed['hulls'])}
 sources=[path,Path(data['seed']),Path(__file__),Path('spatial_branch_seed.py'),Path('retained_spatial_state.py'),Path('exact_persistent_journal.py'),Path('exact_pair_regions_fast.py'),Path('exact_pair_regions.py'),Path('exact_arc_hulls.py'),Path('exact_poses.py')]
 hashes={str(p):sha(p) for p in sources};checks=[];start=time.time()
 for rnd,entry in enumerate(data['history']+([None] if data.get('terminal') else [])):
  initial=[len(d) for d in dom];print('spatial exact start',rnd,initial,flush=True);region=[]
  if all(dom):poses,dom,region=refine(poses,dom,N,args.jobs)
  cc=Compatibility(poses,N);ok,deletions=reduce_domains(dom,cc)
  record={'round':rnd,'initial':initial,'active':[len(d) for d in dom],'deleted_poses':len(deletions),'exact_incompatible_edges':cc.exact_edges,'seconds':time.time()-start,'center_pruning':region};checks.append(record)
  receipt={'method':'spatial_branch_persistent','journal_sha256':sha(path),'seed_sha256':sha(data['seed']),'ancestry_discharged':True,'spatial_cut':seed['spatial_cut'],'normalized_corners':[3,4],'source_hashes':hashes,'checks':checks,'scope':'Conditional only on the stated spatial branch after the established normalizations. No global optimality claim.'}
  if not ok:
   receipt['verdict']='VERIFIED SPATIAL BRANCH EXCLUSION';Path(str(path)+'.verified-exclusion.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['verdict'],flush=True);return
  assert entry is not None,'Floating terminal did not replay'
  new={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,entry['hulls'])};total=0
  for g,d in zip(gs,dom):
   assert all(contains(new[g],p) for p in hs[g]);added=[p for p in new[g] if not contains(hs[g],p)];total+=len(added)
   for i in d:
    p=poses[i];x0,x1,y0,y1=p['own'];c=p['c'];s=p['s']
    for X,Y in added:
     x=c*X+s*Y;y=-s*X+c*Y
     assert x1-cc.h<=x<=x0+cc.h and y1-cc.h<=y<=y0+cc.h,('uncertified vertex',rnd,g,p['k'],str(X),str(Y))
  hs=new;poses,dom=cut_and_round(poses,dom,gs,hs,N,den);record['checked_new_vertices']=total;record['after_hulls']=[len(d) for d in dom]
  receipt['completed_round']=rnd;Path(str(path)+'.verified-prefix.json').write_text(json.dumps(receipt,indent=2)+'\n');print('spatial exact checked',rnd,record['after_hulls'],'vertices',total,'seconds',round(time.time()-start,1),flush=True)
 if args.dump_state:
  assert data['history'] and not data.get('terminal')
  prefix=Path(str(path)+'.verified-prefix.json')
  state={'method':'exact_retained_spatial_state','case':6,'bins':N,'groups':seed['groups'],'hulls':[[[str(x),str(y)] for x,y in hs[g]] for g in gs],'owners':serialize(poses,dom),'parent_seed':data['seed'],'journal':str(path),'prefix_receipt':str(prefix),'spatial_cut':seed['spatial_cut'],'normalized_corners':[3,4],'source_hashes':{**hashes,str(prefix):sha(prefix)},'scope':'Retained exact center polygons after the complete verified journal prefix.'}
  Path(args.dump_state).write_text(json.dumps(state));print('SAVED VERIFIED RETAINED STATE',args.dump_state,flush=True)
 print('VERIFIED PREFIX ONLY',flush=True)
if __name__=='__main__':main()
