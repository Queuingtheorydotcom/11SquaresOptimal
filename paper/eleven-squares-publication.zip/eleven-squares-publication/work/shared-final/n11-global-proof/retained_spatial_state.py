"""Load ancestry-checked persistent states and exact angular refinements."""
from fractions import Fraction as F
from pathlib import Path
import json
from corner_obstruction_seed import sha
from spatial_branch_seed import load_seed as initial_seed
from exact_persistent_journal import bounds

def load_seed(path):
 d=json.loads(Path(path).read_text())
 if d['method']=='exact_spatial_branch_seed':return initial_seed(path)
 assert d['method'] in ['exact_retained_spatial_state','exact_refined_spatial_seed']
 for p,h in d['source_hashes'].items():assert sha(p)==h,p
 parent,_,_=load_seed(d['parent_seed'])
 assert d['case']==parent['case']==6 and d['groups']==parent['groups'] and d['spatial_cut']==parent['spatial_cut'] and d['normalized_corners']==parent['normalized_corners']==[3,4]
 if d['method']=='exact_retained_spatial_state':
  j=json.loads(Path(d['journal']).read_text());r=json.loads(Path(d['prefix_receipt']).read_text())
  assert r['journal_sha256']==sha(d['journal']) and r['seed_sha256']==sha(d['parent_seed']) and r['ancestry_discharged'] and r['completed_round']==len(j['history'])-1
  assert d['bins']==parent['bins']==j['bins']
 else:assert d['bins']>parent['bins'] and d['bins']%parent['bins']==0
 poses=[];dom=[]
 for owner in d['owners']:
  ids=set()
  for p in owner:
   poly=[tuple(map(F,q)) for q in p['poly']];ids.add(len(poses));poses.append({'k':p['k'],'c':F(p['c']),'s':F(p['s']),'poly':poly,'own':bounds(poly)})
  dom.append(ids)
 return d,poses,dom

def serialize(poses,dom):
 return [[{'k':poses[i]['k'],'c':str(poses[i]['c']),'s':str(poses[i]['s']),'poly':[[str(x),str(y)] for x,y in poses[i]['poly']]} for i in sorted(ids)] for ids in dom]
