"""Assemble spatial bounds and count all checked continuation prefixes."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json
from retained_spatial_state import load_seed
from corner_obstruction_seed import sha

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('receipts',nargs='+');args=ap.parse_args();bounds=[];sources=set();checked={}
 def collect_seed(path):
  p=Path(path);d=json.loads(p.read_text());sources.add(p)
  if d['method']=='exact_retained_spatial_state':
   pr=Path(d['prefix_receipt']);checked[str(pr)]=json.loads(pr.read_text());sources.add(pr);sources.add(Path(d['journal']))
  if d.get('parent_seed'):collect_seed(d['parent_seed'])
 for file in args.receipts:
  p=Path(file);r=json.loads(p.read_text());assert r['verdict']=='VERIFIED SPATIAL BRANCH EXCLUSION' and r['ancestry_discharged'] and r['normalized_corners']==[3,4]
  for source,h in r['source_hashes'].items():assert sha(source)==h,source
  journal=next(Path(s) for s,h in r['source_hashes'].items() if h==r['journal_sha256']);j=json.loads(journal.read_text());seed,_,_=load_seed(j['seed']);assert sha(j['seed'])==r['seed_sha256'] and seed['spatial_cut']==r['spatial_cut']
  assert any(v==0 for v in r['checks'][-1]['active']);cut=r['spatial_cut'];assert len(cut['inequalities'])==1
  nx,ny,b=map(F,cut['inequalities'][0]);bounds.append({'owner':cut['owner'],'normal':[str(-nx),str(-ny)],'upper':str(-b),'strict':True,'exclusion':str(p)})
  sources.update([p,journal]);checked[str(p)]=r;collect_seed(j['seed'])
 sources.update([Path(__file__),Path('retained_spatial_state.py')])
 details=[{'receipt':p,'hull_rounds':sum('checked_new_vertices' in q for q in r['checks']),'new_hull_vertices':sum(q.get('checked_new_vertices',0) for q in r['checks']),'incompatible_pose_pairs':sum(q['exact_incompatible_edges'] for q in r['checks'])} for p,r in checked.items()]
 totals={k:sum(x[k] for x in details) for k in ['hull_rounds','new_hull_vertices','incompatible_pose_pairs']}
 out={'verdict':'VERIFIED necessary spatial bounds after two-corner normalization','case':6,'normalized_corners':[3,4],'ancestry_discharged':True,'necessary_halfplanes':bounds,'totals':totals,'checked_continuations':details,'source_hashes':{str(p):sha(p) for p in sorted(sources)},'scope':'All stated strict bounds hold after normalization. Counts include each complete spatial-chain prefix once, excluding older shared ownership, angle and corner proofs. Global optimality remains unproved.'}
 Path(args.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['source_hashes','checked_continuations']},indent=2))
if __name__=='__main__':main()
