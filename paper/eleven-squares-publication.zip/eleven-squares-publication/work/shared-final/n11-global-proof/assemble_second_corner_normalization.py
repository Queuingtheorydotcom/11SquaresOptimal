"""Join exact obstruction exclusion and axis checks into a second replacement."""
from pathlib import Path
from fractions import Fraction as F
import json
from corner_obstruction_seed import foundation,load_seed,sha,BASE
from marker_cases import S,A_LO,A_HI,POINTS

def checked(path):
 d=json.loads(Path(path).read_text())
 for p,h in d['source_hashes'].items():assert sha(p)==h,p
 return d

def main():
 base=foundation();top=Path('exploration/top-obstruction-certified-journal.json.verified-exclusion.json');axes=Path('second-corner-axes-verification.json');a=checked(top);b=checked(axes)
 assert a['verdict']=='VERIFIED GEOMETRIC OBSTRUCTION EXCLUSION' and a['obstructor']==7 and a['normalized_corner_owner']==4 and a['ancestry_discharged']
 assert any(v==0 for v in a['checks'][-1]['active'])
 assert b['verdict']=='VERIFIED second-corner replacement against all owners except 7' and b['corner_owner']==3 and b['reserved_owner']==7 and b['conditioned_owner']==9 and b['ancestry_discharged']
 assert {x['other_owner'] for x in b['records']}==set(range(11))-{3,7}
 assert F(b['minimum_margin'])>0
 topseed=Path('exploration/top-obstruction-certified-seed.json');innerseed=Path('exploration/inner-obstruction-certified-seed.json')
 d,_,_=load_seed(topseed);e,_,_=load_seed(innerseed);assert d['obstructor']==7 and e['obstructor']==9
 assert a['seed_sha256']==sha(topseed) and str(innerseed) in b['source_hashes']
 for x,y in base['history'][-1]['hulls'][4]:assert 0<=F(x)<=A_LO and S-A_LO<=F(y)<=S
 assert 2*A_HI<S
 for i,(x,y) in enumerate(POINTS):
  inward=(S-x,S-y)
  if i==2:assert all(0<v<A_LO for v in inward)
  else:assert any(v>=A_HI for v in inward)
 paths=[top,axes,topseed,innerseed,Path('corner-normalization-verification.json'),Path('SECOND_CORNER_NORMALIZATION.md'),Path(__file__)]
 r={'verdict':'VERIFIED global existence-preserving normalization of both upper corners','case':6,'corners':{'3':'[S-a,S] x [S-a,S]','4':'[0,a] x [S-a,S]'},'hypothesis_ancestry_discharged':True,'obstruction_checked_new_vertices':sum(x.get('checked_new_vertices',0) for x in a['checks']),'obstruction_checked_incompatible_edges':sum(x['exact_incompatible_edges'] for x in a['checks']),'inner_neighbor_excluded_non_inward_axes':b['non_inward_signed_axes_excluded'],'statement':'Every hypothetical improvement has a representative with both upper corner squares canonical; the other nine squares are unchanged.','proof':'SECOND_CORNER_NORMALIZATION.md','global_optimality_proved':False,'source_hashes':{str(p):sha(p) for p in paths}}
 Path('second-corner-normalization-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='source_hashes'},indent=2))
if __name__=='__main__':main()
