"""Discharge a vacuous spatial branch and preserve its verified global state."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
from retained_spatial_state import load_seed
from corner_obstruction_seed import sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('state');ap.add_argument('output');args=ap.parse_args()
    d,poses,dom=load_seed(args.state)
    assert d['method']=='exact_retained_spatial_state' and all(dom)
    for cut in d['spatial_cut']['inequalities']:
        nx,ny,b=map(F,cut);assert nx==ny==0 and b>=0
    sources=[Path(args.state),Path(__file__),Path('retained_spatial_state.py')]
    out={k:d[k] for k in ['case','bins','normalized_corners','groups','hulls','owners']}
    out.update(method='exact_two_corner_seed',global_retained_parent=args.state,
        source_hashes={str(p):sha(p) for p in sources},
        scope='Global necessary pose domains: the only added branch inequalities are identically true.')
    Path(args.output).write_text(json.dumps(out));print([len(o) for o in out['owners']])
if __name__=='__main__':main()
