# Foundation and exhaustive ownership reduction

This immutable excerpt records the foundational portion of the proof. The final global closure is in GLOBAL_OPTIMALITY.md.

## 1. The target and a rational normalization

Let L* be the known construction's side,

    L* = 3.87708359002281417730789706010096...

It is the root in the interval

    (3.87708359002281417730789706010096,
     3.87708359002281417730789706010097)

of

    P(L) = L^8 - 20L^7 + 178L^6 - 842L^5 + 1923L^4
           - 496L^3 - 6754L^2 + 12420L - 6865.

The polynomial and construction are recorded in the
[current packing catalogue](https://kingbird.myphotos.cc/packing/squares_in_squares.html).
The checker verifies a sign change and positive derivative throughout this
rational interval.

Set S = 97/25 = 3.88 and a* = S/L*. Exact rational comparisons give

    4003/4000 = 1.00075 < a* < 1.00076 = 25019/25000.

Suppose eleven unit squares fit in a square of side L < L*. Choose

    a* < a < min(25019/25000, S/L).

After scaling the packing by a and enlarging its container to [0,S]^2, we
obtain eleven squares of a common side a in that fixed rational container.
Consequently it suffices to exclude a > a*. All reductions below are valid
on the slightly wider rational interval 1.00075 < a < 1.00076. They therefore
include the record construction at a = a*, which is a useful control.

An owner contains its points in its **open interior**. An excluded point may
lie on a square's boundary. These conventions are essential.

## 2. Twelve unavoidable markers

Write m = S/2 = 1.94. Use the following exact rational points:

| Index | Name | Coordinates |
|---|---|---|
| 0 | C0 | (1, 1) |
| 1 | C1 | (2.88, 1) |
| 2 | C2 | (2.88, 2.88) |
| 3 | C3 | (1, 2.88) |
| 4 | W0 | (1.94, .75) |
| 5 | W1 | (3.13, 1.94) |
| 6 | W2 | (1.94, 3.13) |
| 7 | W3 | (.75, 1.94) |
| 8 | I0 | (1.59, 1.59) |
| 9 | I1 | (2.29, 1.59) |
| 10 | I2 | (2.29, 2.29) |
| 11 | I3 | (1.59, 2.29) |

**Covering theorem.** Every open square of side greater than 1, whose closed
square lies in [0,S]^2, contains at least one of these twelve markers.

The local facts used are the rectangle, triangle, and wall-quadrilateral
nonavoidance lemmas (Lemmas 1, 2, and 4) in
[Stromquist's paper](https://www.combinatorics.org/ojs/index.php/eljc/article/download/v10i1r8/pdf).
In brief: a center in a corner rectangle with sides at most 1 forces its
inner corner; a center in a triangle with sides at most 1 forces a vertex;
and the wall-quadrilateral lemma forces one of its two non-wall vertices
under the inequality checked below. Wall intersections are impossible for
an open box contained in the container. For a center on a triangle edge,
the two edge endpoints cannot both be outside the box: a center chord has
length at least the box's side, which is greater than the edge length.

Here is a complete partition to which those facts apply:

1. Four 1-by-1 corner rectangles force C0,...,C3.
2. Eight boundary quadrilaterals join a corner marker to the adjacent side
   marker. Each has horizontal width .94 and endpoint heights 1 and .75,
   in coordinates with its container wall horizontal.
3. The remaining octagon has boundary
   C0,W0,C1,W1,C2,W2,C3,W3. Triangulate its ring by the four rotations of
   (C0,W0,I0), (C0,I0,W3), and (W0,I1,I0). Triangulate the middle by
   (I0,I1,I3) and (I1,I2,I3).

All fourteen triangles have sides at most 1. `verify_reduction.py` checks
every squared length, every triangle's orientation, the cancellation of
interior edges, the octagon boundary, and the total partition area exactly.

For the boundary quadrilaterals put alpha = .94 and beta = .75. The
wall-quadrilateral condition follows if, for every 0 < theta < pi/2,

    cos(theta)/(1+cos(theta))
        + (1-alpha*cos(theta))/sin(theta) > beta.

With t = tan(theta/2), multiply the difference by 100t. The result is

    3 - 25t + 97t^2 - 50t^3.

For 0 < t <= 1/2 this is at least 3-25t+72t^2, a positive quadratic
(discriminant -239). For 1/2 <= t < 1 it is at least 3-25t+47t^2, which
is increasing there and is 9/4 at t=1/2. The other hypotheses are

    2sqrt(2)-2 < .94 < 1,
    .94^2 + (1-.75)^2 < 1.

This proves the covering theorem using the stated local lemmas.

## 3. Exhaustive ownership classification

Eleven disjoint boxes own eleven disjoint nonempty subsets of a twelve-point
set. Hence precisely one of the following happens:

* Exactly eleven markers are owned, each by a different square; one marker
  is unused.
* All twelve markers are owned; one square owns a pair, and each of the other
  ten squares owns one marker.

A square cannot own three markers in such a packing, because that would
leave too few markers for the other ten squares.

Two points in one box have distance less than sqrt(2)*a. Since a < 1.00076,
this diameter test leaves exactly 26 of the 66 possible pairs. Under the
eight rotations/reflections of the container these form five orbits. The
unused-marker alternatives form three orbits. Representatives are:

| Case ID | Ownership exception |
|---|---|
| 0 | C0 unused |
| 1 | W0 unused |
| 2 | I0 unused |
| 3 | C0 and W0 share an owner |
| 4 | C0 and I0 share an owner |
| 5 | W0 and I0 share an owner |
| 6 | I0 and I1 share an owner |
| 7 | I0 and I2 share an owner |

Every marker not specified as unused is owned. In a pair case, every other
marker has a distinct singleton owner. The classifier enumerates the full
labelled possibilities and the actual permutations, rather than assuming
this list from a picture.

**Case 7 is impossible.** Translate its inner marker square to vertices
(0,0), (d,0), (d,d), (0,d), where d=.7. Its proposed owner contains (0,0)
and (d,d), and excludes the other two. Choose perpendicular side normals
u=(c,s), v=(-s,c), with c,s >= 0 and c^2+s^2=1. Both excluded points have
u-projections between those of the owned points, so they are inside the
owner's u-strip. The v-strip must exclude them at opposite ends. Its width
is therefore at most d(c+s) <= d*sqrt(2) < 1, contradicting a>1.

Thus **seven ownership cases** suffice before any computational propagation.
The known construction belongs to case 6, up to a half-turn. This is a
classification of arbitrary packings, not an assumption about a contact graph.

## 4. Compulsory polygons from moving markers

If a square owns only marker p, and replacing p by q preserves the covering
theorem, that square must own q: it still avoids every other marker. Any
finite convex hull of such forced points lies strictly inside the owner.

For I0 use the pentagonal star with boundary

    C0, W0, I1, I3, W3.

Moving I0 to a point q inside this star and within distance 1 of every star
vertex leaves its five triangles valid. The code selects the following
nineteen rational vertices from that admissible region:

    (1.30,1.45), (1.32,1.35), (1.33,1.33), (1.35,1.32),
    (1.45,1.30), (1.51,1.30), (1.55,1.34), (1.61,1.43),
    (1.67,1.55), (1.69,1.60), (1.71,1.66), (1.71,1.70),
    (1.70,1.71), (1.66,1.71), (1.60,1.69), (1.55,1.67),
    (1.43,1.61), (1.34,1.55), (1.30,1.51).

A singleton I0 owner contains their entire convex hull. Rotate to obtain
the other three inner singleton polygons. This rule is not applied to an
inner marker belonging to the pair owner.

A singleton W0 owner contains

    (1.94,.66), (1.94,.82), (1.92,.74), (1.96,.74).

Each replacement retains the triangulated cover. For the two boundary
quadrilaterals, the general numerator to check is

    (1-alpha)/2 + (1/2-beta)t + (1+alpha)t^2/2 - t^3/2.

The exact checker certifies positivity on [0,1] by rational Bernstein
coefficients on finitely many explicitly reported subintervals. It also
checks all affected triangle lengths. Rotate for W1,W2,W3.

### 4.1 Additional corner polygons

Seven further compulsory points for every singleton corner owner are proved
in `CORNER_MARKERS.md`. Each follows from replacing only that corner marker
in the twelve-point cover and checking the two modified wall quadrilaterals
after scaling by their corner-end heights. `corner_markers.py` verifies the
cover arithmetic exactly, and `check_corner_record.py` checks the record
construction algebraically. These points produce only a small improvement
in the exploratory domains and are not used by the earlier exclusions.

## 5. Continuous pose enclosures and rational replay

These details justify the checking algorithm; the floating search does not
itself establish exclusions.

Represent an orientation by t=tan(theta/2) in [0,1]. Quarter-turn symmetry
of each individual square makes this range exhaustive. In the kth of N
closed intervals, let t0=(k+1/2)/N, and use rational midpoint normals

    u0=((1-t0^2)/(1+t0^2), 2t0/(1+t0^2)),
    v0=(-u0_y,u0_x).

The angular difference from that midpoint is at most 1/N, so
cos(delta)+|sin(delta)| <= q = 1+1/N. Put

    H = (25019/25000)*q/2,
    h = (4003/4000)/(2q).

Every actual square is inside the midpoint-oriented square of half-side H
with the same center, and contains the midpoint-oriented square of
half-side h strictly. Hence:

* Every compulsory owned point imposes four rational linear bounds on the
  center in midpoint coordinates.
* An excluded marker removes the open center rectangle of half-side h
  around that marker.
* Another owner's compulsory hull K removes the interior of the Minkowski
  sum K+[-h,h]^2 from the possible center region (in midpoint coordinates).
* Wall containment supplies a rational center rectangle: the minimum of
  cos(theta)+sin(theta) on a first-quadrant interval is at an endpoint.

The verifier clips rational convex polygons against the resulting lines.
Subtracting a forbidden convex polygon is a finite union of outside-edge
halfplanes. Convexifying the retained pieces only enlarges the allowed set,
so it is a safe relaxation. All N orientation intervals, including their
endpoints, are processed.

Discarding a zero-area piece is safe here because every actual feasible
center satisfies the outer approximation's genuine bounds with slack:
the actual side is strictly between the two rational side bounds, and the
inner comparison square has strictly smaller side. Partition lines added
only to split a union do not remove the closures of adjacent positive-area
pieces. Thus a true pose remains in at least one retained closed polygon.

For each retained center polygon and midpoint orientation, the intersection
of the half-side-h squares centered at all of its vertices consists of
points guaranteed to lie in the actual square. Intersect these regions over
every pose enclosure to obtain further compulsory points. Rational proposed
points are accepted only after this universal condition passes exactly.

`exact_poses.py` replays an ordered journal. At each round it uses only
previously justified hulls, checks every new vertex, and then advances the
common state. A terminal empty pose cover can exclude a case only after its
entire input ancestry has passed. There is no inference from an optimization
timeout, a failed numerical search, or a floating-point emptiness result.

### 5.1 Pairwise compatibility as an additional necessary condition

The next checker, `exact_arc_hulls.py`, also compares center polygons for
different owners. This step uses the small midpoint-oriented squares of
half-side h already proved to lie strictly inside the actual squares.

Let P and Q be two possible center polygons, with rational midpoint normals
(u,v) and (u',v'). Along any one of these four normals n, the sum of the two
inner squares' support radii is

    r(n) = h (|n.u| + |n.v| + |n.u'| + |n.v'|).

For one of their own normals this simplifies to

    r = h (1 + |u.u'| + |u.v'|).

For each n compute the largest possible absolute center separation

    D(n) = max(max(P.n)-min(Q.n), max(Q.n)-min(P.n)).

The extrema occur at polygon vertices. If D(n) < r(n) for all four normals,
every pair of centers in P and Q produces overlapping inner squares, by
the separating-axis theorem. Consequently these two pose enclosures cannot
both occur in a packing. All four decisive comparisons use rational numbers.

Give each owner a domain consisting of all its surviving pose enclosures.
Delete a pose if some other owner's domain contains no compatible pose.
Repeat until no deletion is possible or a domain is empty. This operation
cannot delete any member of an actual packing: its companion pose in every
other owner domain supplies a compatible choice, and induction preserves
all those choices. An empty domain therefore excludes the case.

After these deletions, compulsory points need only be checked against the
remaining domains. Propagation then continues synchronously as before.
No existence conclusion is drawn from a nonempty set of domains: pairwise
compatibility is only a necessary condition for a joint packing.

The checker has a numerical shortcut that may **retain** an edge without
checking it. This can only weaken the exclusion. Every missing edge used
to justify a deletion is checked exactly with `Fraction` arithmetic. The
default command also replays any stated base ancestry; the direct-from-initial
journals avoid that dependency entirely. The branch field, when present,
restricts one owner's half-angle to a specified union of closed grid bins;
such a verdict excludes only that branch unless exhaustive coverage is
checked separately.

### 5.2 Removing centers that collide with every choice of another owner

A stronger necessary condition operates inside a pose's center polygon.
Fix the midpoint orientation of owner A, and let B range over all of another
owner's pose enclosures. For one B enclosure Q and any of the four inner-square
normals n, every choice y in Q overlaps the A inner square along n precisely
when its center x satisfies

    max(Q.n) - r(n) < x.n < min(Q.n) + r(n).

Intersect these strips over all four normals and all B enclosures. The result
is a convex open region F(A,B). Any A center in F(A,B) overlaps every possible
B inner square, so a genuine A center must lie outside F(A,B). The rational
checker forms the corresponding closed half-plane intersection and removes
only its interior. Convexifying the retained pieces again weakens the bounds
safely. All owners are updated from the same old pose covers in each sweep.

`exact_pair_regions.py` implements this operation using rational support
extrema and polygon clipping. Its numerical shortcut can choose to skip a
cut altogether, which retains extra possibilities. It never supplies an
uncertified bound for a region that is actually removed. Pairwise domain
deletion and compulsory-point verification then use the refined polygons.

This rule is stronger than merely avoiding another owner's compulsory hull:
the intersection of the possible collision regions can be larger than the
collision region generated by the intersection of its possible squares.
Any journal using this rule still needs its own completed rational replay;
the numerical explorations alone are not additional exclusions.

### 5.3 Retaining position information between sweeps

`PERSISTENT_REGIONS.md` proves the safety of retaining angle-dependent center
polygons across sweeps. `exact_persistent_journal.py` implements the rational
replay. It reuses the existing center-pruning and compatibility rules, checks
new compulsory vertices, and rounds retained polygons outward in sixteen
rational directions. Starting a finer-grid journal from the proved hulls
deliberately reconstructs a conservative cover; it does not silently inherit
any unrecorded position restrictions.

The dispatch wrapper `exact_pair_regions_fast.py` calls the unchanged rational
pruning function once per angle bin. It changes multiprocessing overhead,
not the geometric deductions. A prefix-only or assumed-base receipt still
does not establish an unconditional branch exclusion.

## 6. Checked computational exclusions

| Case | Complete rational propagation rounds | Required owner with empty final domain | Result |
|---|---:|---|---|
| 0: C0 unused | 14 | I1 | Excluded |
| 1: W0 unused | 3 | I0 | Excluded |
| 2: I0 unused | 14 at N=96, then 1 at N=384 | W1 | Excluded |
| 3: C0,W0 share an owner | 3 | W2 | Excluded |
| 4: C0,I0 share an owner | 7 | I1 | Excluded |
| 5: W0,I0 share an owner | 5 | W1 | Excluded |

Case 1 uses the center-pruning rule in Section 5.2 as well as pairwise
compatibility. Its complete replay starts from the initial compulsory points,
checks 170 new vertices and 192,787 incompatible pose pairs, and reaches an
empty I0 domain after three rounds of new compulsory-point deductions. It
uses no branch restriction beyond a justified symmetry normalization.

Reflection in x=S/2 fixes the unused marker W0 and the opposite side marker
W2. It permutes the singleton owners and sends the canonical W2-owner angle
theta to pi/2-theta. Thus this owner's orientation can be normalized to
theta <= pi/4, safely enclosed by t < 5/12. As in the other symmetry arguments,
the normalization precedes all deductions and does not assume subsequent
asymmetric hulls are reflection-invariant.

The case-1 journal is
`exploration/regions-case-1-from-initial-N96.json`, with SHA-256
`cd490f69eb2194d9881bf6d13b2e86571eb67a3881ec107daa143acedde621ff`.
Reproduce its complete exclusion with

    python3 exact_arc_hulls.py exploration/regions-case-1-from-initial-N96.json --jobs 4

Case 2 first has fourteen checked compulsory-region rounds at N=96. A finer
cover at N=384 then gives one more round and an empty W1 center domain. Across
both stages, the checker verified 643 new vertices and 264,297 incompatible
pose pairs. Reflection in y=x fixes the unused I0 and the opposite inner
marker I2, so the I2 owner's angle is normalized to theta<=pi/4 before any
deductions, using the same argument as above.

The N=96 base is `exploration/regions-case-2-from-initial-N96.json`, with
SHA-256 `224aff45d57cae109b608eddf4365c9f797ada6456b6b40deb923ef09b3230d2`.
The N=384 continuation is `exploration/regions-case-2-N384.json`, with
SHA-256 `d30a4c8560a2dcf538a954da209013e41655f9554302271a9c74a17c027d419f`.

The complete root ancestry and the implication from its final hulls were
verified independently, then joined with `assemble_replays.py`. The join
checks the immutable journal hashes, completed root prefix, absence of
conditional angle branches, compatible symmetry scopes, and the terminal
empty domain. Thus the continuation's initially stated base assumption has
been discharged; no unverified hull is a premise of the case-2 exclusion.
The assembled record is `exploration/regions-case-2-N384.json.assembled-exclusion.json`.

A fresh complete replay, including the entire base, is a single command:

    python3 exact_arc_hulls.py exploration/regions-case-2-N384.json --jobs 4

Do not add `--assume-base` to that command: that option deliberately proves
only a conditional implication and writes a separate record, not a case-exclusion
verdict. `assemble_replays.py` joins already completed records; it does not
replace a fresh geometric replay.

Case 4 (C0 and I0 share an owner) is now also excluded, using the pairwise
compatibility rule in Section 5.1. Its direct-from-initial journal has seven
rounds of compulsory-region deductions followed by an empty domain. The
complete replay checked 356 new compulsory vertices and 488,697 incompatible
pose pairs, and deleted 2,552 poses across its eight passes. At the terminal
pass the I1 domain became empty.

For this case reflection in y=x fixes both C0 and I0, hence fixes their common
owner and permutes the remaining owners. Normalize this common owner's angle
to theta <= pi/4 exactly as in the case-0 argument below. The rational bound
t < 5/12 again safely encloses every normalized possibility.

The completed case-4 journal is
`exploration/arc-case-4-from-initial-N96.json`, with SHA-256
`74b8bbb69c4d9f749e834072b07d43ece00301d930ea0fa45357b844d91774fc`.
It has no exploratory base dependency. Reproduce it with

    python3 exact_arc_hulls.py exploration/arc-case-4-from-initial-N96.json --jobs 3

The replays use 96 half-angle intervals, refined to 384 for the case-2
continuation. Every new compulsory vertex in every retained round was checked.
In cases 0, 3, and 5 the terminal pose cover is empty directly; in cases 1 and 4
the compatibility deletions empty a domain. In case 2 the refined center
pruning empties a domain.
The terminal contradictions use no clique-search or mixed-integer solver verdict.

Case 0 first uses a legitimate symmetry normalization. Reflection in y=x
fixes the unused marker C0 and the marker I0. It preserves the entire
ownership pattern after the singleton owners are relabelled by their markers.
It sends the I0 owner's canonical edge angle theta in [0,pi/2] to
pi/2-theta. Thus one representative has theta <= pi/4. Its half-angle satisfies

    t <= sqrt(2)-1 < 5/12.

The last inequality follows from (17/12)^2 > 2. The rational enclosure keeps
all intervals with k/96 < 5/12, so it is slightly wider than the required
angle range. The normalization precedes the propagation; the proof does not
assume that an asymmetric intermediate hull is invariant under reflection.

Cases 3 and 5 use no orientation symmetry restriction.

The case-0 replay writes its verdict directly after checking the entire
chain and terminal step. For cases 3 and 5 the complete prefix and terminal
were first checked separately, then joined using the unchanged geometric
states. The delivered journals include the terminal metadata, so the provided
verifier reproduces each full exclusion with a single command. The saved
verdicts bind their journals by SHA-256.

These are computer-assisted deductions using the stated geometric lemmas and
exact rational arithmetic. They are not Lean formalizations.

## 6.1 A certified angle restriction within case 6

The low-angle branch in the last ownership family is now excluded. Reflect
in the vertical midline if necessary so that the common I0,I1 owner's edge
angle satisfies 0<=theta<=pi/4. This reflection interchanges I0 and I1 and
permutes all other owners, so it preserves the ownership case. Put
 t=tan(theta/2). Every normalized case-6 packing in the stated side interval
must satisfy

    5/24 < t <= sqrt(2)-1,
    2 arctan(5/24) < theta <= pi/4.

The lower angle is approximately 23.536577864 degrees. This result does not
assert that the remaining squares share this angle or are axis aligned.

The completed proof consists of 19 compulsory-hull rounds followed by an
empty pose cover. It checks 995 proposed compulsory vertices and 211,092
incompatible pose pairs. Its four immutable stages are:

| Journal | Angle grid | Deduction rounds |
|---|---:|---:|
| `direct-low-root-five-N96.json` | 96 | 5 |
| `direct-low-tail-N96.json` | 96 | 5 |
| `direct-low-N192.json` | 192 | 9 |
| `direct-low-N768.json` | 768 | terminal exclusion |

All paths are under `exploration/`. The branch in every stage is the same
closed physical half-angle interval [0,5/24]. The finer grids cover that
interval, including its endpoints. At the final grid, the W1 and W3 owner
pose covers are empty even before pairwise consistency is applied.

The root was checked from the original necessary geometry. Each subsequent
stage was checked as an implication from the preceding stage's final hulls.
`assemble_branch_replays.py` verified every completed record, immutable input
hash, branch inclusion, case identity, and symmetry scope. Thus all assumed
base hulls have been discharged. The resulting record is
`exploration/direct-low-N768.json.assembled-exclusion.json`.

A fresh complete geometric replay, without cached-base shortcuts, is:

    python3 exact_arc_hulls.py exploration/direct-low-N768.json --jobs 4

It must end with `VERIFIED CONDITIONAL EXCLUSION 6`: the condition is the
stated angle branch. The assembled result is a genuine branch exclusion,
but it leaves all larger normalized angles in case 6 unresolved.

## 6.2 A second angle exclusion: t must exceed 5/16

The closed middle interval [5/24,5/16] is now also excluded, with its entire
ancestry checked. Together with Section 6.1, this gives the stronger necessary
condition

    5/16 < tan(theta/2) <= sqrt(2)-1,
    34.70804927252265... degrees < theta <= 45 degrees.

The four immutable stages, all under `exploration/`, are:

| Journal | Angle grid | Deduction rounds |
|---|---:|---:|
| `direct-middle-root-three-N96.json` | 96 | 3 |
| `direct-middle-tail-N96.json` | 96 | 9 |
| `direct-middle-N192.json` | 192 | 12 |
| `direct-middle-N768.json` | 768 | terminal exclusion |

The exact replays checked 1,072 new compulsory vertices and 240,174
incompatible pose pairs. Terminal rational center pruning empties the I3
owner's domain. The subsequent compatibility check also empties the common
I0,I1 owner's domain. `assemble_branch_replays.py` discharged every assumed
base using completed receipts and matching immutable hashes. The assembled
record is `exploration/direct-middle-N768.json.assembled-exclusion.json`.

A fresh complete replay is:

    python3 exact_arc_hulls.py exploration/direct-middle-N768.json --jobs 4

The exclusions include both endpoints. Their union therefore excludes
the entire closed interval [0,5/16], not merely its interior.

## 6.3 The C2 owner must be close to axis alignment

Write phi in [0,pi/2] for the canonical edge angle of the C2 owner in the
same normalized case-6 representative, and put v=tan(phi/2). A completed
two-stage persistent-region replay excludes the conjunction

    5/16 <= t <= 5/12,
    5/48 <= v <= 43/48.

The first stage, `persistent-direct-upper-corner-middle-N96.json`, checks
20 sweeps directly from the initial compulsory geometry. The second,
`persistent-upper-corner-middle-N192.json`, checks three finer-grid sweeps
and a terminal contradiction. All paths are under `exploration/`.
There are 902 checked new compulsory vertices and 357,652 checked
incompatible pose pairs. The final domain deletion empties the C0 owner.

`assemble_persistent_replays.py` validates the full root receipt, the refined
conditional exclusion, their hashes, and the matching physical cuts. Its
assembled record is
`exploration/persistent-upper-corner-middle-N192.json.assembled-exclusion.json`.
Thus the starting-hull assumption of the refined exclusion is discharged.
A fresh full replay, including the root, is:

    python3 exact_persistent_journal.py exploration/persistent-upper-corner-middle-N192.json --jobs 4

Since sqrt(2)-1<5/12, Sections 6.1 and 6.2 now imply, for every normalized
case-6 packing in the stated side interval,

    v in [0,5/48) union (43/48,1].

Equivalently, phi is less than approximately 11.893726108 degrees or greater
than approximately 83.710085071 degrees. The representations phi=0 and
phi=pi/2 describe the same square orientation. This result forces neither
exact axis alignment nor the record's contact pattern.
Choosing the equivalent edge angle psi near zero combines these two
intervals into the single exact bound

    -5/91 < tan(psi/2) < 5/48.

Indeed, on the near-pi/2 branch,
tan((phi-pi/2)/2)=(v-1)/(v+1), which maps 43/48 to -5/91 and 1 to 0.
`combine_angle_exclusions.py` checks the logical combination of the three
completed exclusion receipts and writes `combined-angle-verification.json`.

