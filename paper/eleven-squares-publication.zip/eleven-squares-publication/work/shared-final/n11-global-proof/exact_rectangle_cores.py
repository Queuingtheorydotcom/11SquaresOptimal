"""Exact enclosing-box cores justified by RECTANGLE_CORES.md."""
from fractions import Fraction as F
from marker_cases import S,A_LO
from forced_markers import hull

def rectangle_cores(poses,dom,gs,hs,N):
 H=A_LO*(1+F(1,N))/2;fresh={g:list(hs[g]) for g in gs};records=[]
 for own,(g,ids) in enumerate(zip(gs,dom)):
  assert ids
  left=bottom=S;right=top=F(0)
  for i in ids:
   p=poses[i];c,s=p['c'],p['s'];rad=H*(c+s);xy=[(c*x-s*y,s*x+c*y) for x,y in p['poly']]
   left=min(left,min(x for x,y in xy)-rad);right=max(right,max(x for x,y in xy)+rad);bottom=min(bottom,min(y for x,y in xy)-rad);top=max(top,max(y for x,y in xy)+rad)
  left=max(F(0),left);right=min(S,right);bottom=max(F(0),bottom);top=min(S,top)
  x0=right-A_LO;x1=left+A_LO;y0=top-A_LO;y1=bottom+A_LO;core=[]
  if x0<=x1 and y0<=y1:
   core=hull([(x,y) for x in [x0,x1] for y in [y0,y1]]);fresh[g]=hull(fresh[g]+core)
  records.append({'owner':own,'enclosing_box':[str(v) for v in [left,right,bottom,top]],'core':[[str(x),str(y)] for x,y in core]})
 return fresh,records
