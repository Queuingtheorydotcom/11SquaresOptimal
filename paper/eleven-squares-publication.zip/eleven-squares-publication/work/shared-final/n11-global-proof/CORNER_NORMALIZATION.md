# A global corner normalization for the remaining eleven-square case

**New structural conclusion.** Every hypothetical improvement on the record
can, after the established symmetry normalization and without increasing its
container, be rearranged so that the owner of

\[
 C_3=(1,S-1),\qquad S=97/25,
\]

is exactly the axis-aligned corner square

\[
 \boxed{[0,a]\times[S-a,S].}
\]

Here A_LO=4003/4000<a<A_HI=25019/25000 is the common square side in the fixed
container normalization. The other ten squares stay in place. Marker
ownership is preserved. This removes the corner square's two center
variables and angle from the remaining search.

This is an existence-preserving normalization, not a claim that every
packing already has this corner square aligned. Global optimality is still
unproved. The earlier local isolation radius remains 1/210.

## 1. The geometric replacement lemma

Use coordinates measured inward from a container corner, so the containing
quadrant is x,y>=0. Let P be any square of side a in this quadrant, and let
E=[0,a]^2. For every n=(n_x,n_y) with n_x,n_y>=0,

\[
 \max_{x\in E}n\cdot x\le\max_{x\in P}n\cdot x. \tag{1}
\]

To prove this, first translate P toward both walls until its bounding box
has lower corner (0,0), obtaining P0. Choose an edge angle in [0,pi/2],
write c=cos(theta), s=sin(theta), and w=c+s. Its center is (aw/2,aw/2).
The two absolute edge coordinates of (a,a) relative to that center are at
most

\[
 a\left(1-\frac w2\right)w\le\frac a2,
\]

because w(2-w)<=1. Thus (a,a) belongs to P0. Translating back adds a vector
with nonnegative coordinates, which cannot decrease support in direction n.
Since E's support in that direction is n·(a,a), (1) follows.

Consequently, if every other square either already misses E or is separated
from P by a line whose normal toward that square has both inward components
nonnegative, replacing P by E preserves nonoverlap. Containment is automatic.

## 2. Coarse bounds for this packing problem

The established ownership reduction leaves case 6. The common I0,I1 owner
has normalized half-angle t satisfying

\[
 5/16<t\le\sqrt2-1<5/12.
\]

Starting from the initial compulsory marker regions, seven completed exact
propagation rounds yield the bounds below. No numerical continuation state
is used. The exact final pose cover, before any further compatibility
pruning, verifies every stated bound.

For the upper-left corner use inward coordinates X=x, Y=S-y. Let P be the
C3 owner and B the I3 owner (marker I3=(1.59,2.29)). Their centers satisfy

\[
\begin{array}{c|cc}
 & X & Y\\\hline
P &[1/2,71/100]&[1/2,71/100]\\
B &[121/100,149/100]&[5/4,77/50].
\end{array} \tag{2}
\]

For B, choose its original edge angle theta in [0,pi/2]. Its edge vectors
in inward coordinates are (c,-s) and (s,c), with c,s>=0 and

\[
 c+s\ge13/10. \tag{3}
\]

Every one of the other nine squares has, in the original container
coordinates, either center x>=43/25 or center y<=54/25. The circumradius
of a small square is less than 71/100, as checked by
A_HI²/2<(71/100)². Hence these nine squares miss E: their entire square is
either to the right of x=1.01>A_HI or below y=2.87<S-A_HI.

Only B needs the separating-direction argument.

## 3. B cannot obstruct the replacement

Write the center difference from P to B as (d_x,d_y). From (2),

\[
 1/2\le d_x\le99/100,\qquad
 27/50\le d_y\le26/25. \tag{4}
\]

Because the squares have disjoint interiors, a separating line exists.
Orient its unit normal n toward B. Each square contains its centered disk
of radius a/2, so separation requires

\[
 n\cdot(d_x,d_y)\ge a>1. \tag{5}
\]

If n_x>=0 and n_y<=0, the left side is at most d_x<=99/100, impossible.
If both components are nonpositive, it is nonpositive. It remains to rule
out n=(-e,f), with e>0, f>=0 and e²+f²=1.

If e>=2/25, then by (4)

\[
 -e d_x+f d_y\le-\frac e2+\frac{26}{25}\le1,
\]

again contradicting (5). If 0<e<2/25, then

\[
 f>249/250,
\]

since 1-(2/25)²>(249/250)². The support radius of B in direction n is

\[
\begin{aligned}
h_B(n)
 &=\frac a2\bigl(|-ec-fs|+|-es+fc|\bigr)\\
 &\ge\frac a2\bigl(f(c+s)+e(c-s)\bigr)\\
 &\ge\frac a2\left(\frac{249}{250}\frac{13}{10}-\frac2{25}\right)
 >\frac{3a}{5}.
\end{aligned}
\]

The support radius of P is at least a/2. Separation therefore requires

\[
 -e d_x+f d_y>\frac{11a}{10}>\frac{11}{10},
\]

whereas (4) gives -e d_x+f d_y<=26/25<11/10. This final contradiction rules
out every normal outside the inward quadrant.

Thus the separating line between P and B has an inward normal. Applying
(1) proves that E also misses B. The nine other squares already miss E,
so the replacement is feasible.

Finally, E contains C3 in its open interior because a>1, and contains none
of the other eleven markers because a<A_HI. The side length, container,
common inner owner's angle and ownership case are unchanged. Therefore
all earlier reductions continue to apply to the resulting packing.

## 4. Exact verification and dependency chain

`exploration/corner-global-root-N96.json` is the first seven rounds of the
previous direct upper-angle journal, frozen as a separate source. It starts
from the initial compulsory regions, has no assumed base, and restricts
only the common inner owner to t in [30/96,40/96]=[5/16,5/12]. This covers
the entire remaining half-angle interval. Its exact replay uses the
established rational kernels unchanged.

`exact_corner_boxes.py` constructs exact pose covers from those verified
hulls. It rounds center polygons outward using sixteen rational directions
on a grid of denominator 10^6, then checks (2), (3), and the nine exterior
conditions. The angle bound (3) holds throughout each bin: c+s is concave
as a function of theta on [0,pi/2], so its minimum on a bin is at an endpoint.
All endpoint sines and cosines are rational in t=tan(theta/2).

`assemble_corner_normalization.py` checks the completed seven-round receipt,
the coarse-box receipt, the immutable input hashes and the prior completed
angle exclusions. It also checks the corner's marker ownership directly.
The geometric proof in Sections 1–3 turns these verified hypotheses into
the stated normalization theorem.

For a fresh replay, without Python's -O option:

    python3 exact_arc_fast.py exploration/corner-global-root-N96.json --jobs 6
    python3 exact_corner_boxes.py
    python3 assemble_corner_normalization.py

The first replay took about six minutes in this environment. The final
assembled receipt is `corner-normalization-verification.json`.

An earlier, more detailed check, `exact_corner_normalization.py`, ruled out
4,500 non-inward signed axes directly, with margin greater than 0.172.
Its conditional receipt is retained for comparison, but the short geometric
argument above makes those 4,500 checks unnecessary for the new theorem.

## 5. Further experiments and limits

The analogous upper-right replacement passes numerical tests in the
narrower near-record branch, but it has not been proved over the full
remaining case. One obstruction in the broader domains is that the top
side-marker square may shift far enough right to interfere with that corner.
It would be incorrect to fix both upper corners globally on the present proof.

Numerical propagation after replacing one or both corners is archived
separately. Those continuations have not been replayed exactly and are not
additional proof premises. The new certified global advance is the ability
to fix the C3 owner exactly; global containment in the local box is still
missing.
