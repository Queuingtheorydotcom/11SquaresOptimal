"""Joint globally necessary cuts from the virtual column and bottom row."""
from fractions import Fraction as F
from pathlib import Path
import json
from virtual_column_cuts import tighten as old_tighten,tighten_float as old_float,validate as old_validate
from exact_edge_arc_compatibility import normal
from exact_poses import clip,area2
from exact_persistent_journal import bounds
from forced_markers import hull
from marker_cases import S,A_LO
from corner_obstruction_seed import sha

CERTIFICATE='virtual-bottom-row-verification.json'

def validate():
    old_validate();d=json.loads(Path(CERTIFICATE).read_text())
    assert d['verdict']=='VERIFIED global virtual-bottom-row obstacle and Common support inequality' and d['ancestry_discharged'] and d['owner']==0
    for p,h in d['source_hashes'].items():assert sha(p)==h,p

def cuts(k,N):
    out=[]
    for j in [k,k+1]:
        c,s=normal(F(j,N));upper=F(1,2*N*N)+s*(S-2*A_LO)-A_LO*c-A_LO/2
        out.append((s,-c,upper))
    return out

BOX=[(F(1),F(0),F(97,50)),(F(-1),F(0),-F(19,10)),(F(0),F(1),F(341,200)),(F(0),F(-1),-F(167,100))]

def tighten(poses,dom,N,branch,global_bounds):
    poses,dom=old_tighten(poses,dom,N,branch,global_bounds);out=[];domains=[]
    for own,ids in enumerate(dom):
        new=set()
        for i in sorted(ids):
            p=poses[i];poly=p['poly'];c,s=p['c'],p['s']
            if own==0:
                for nx,ny,b in BOX:poly=clip(poly,(nx*c+ny*s,-nx*s+ny*c),b)
                pieces=[]
                for nx,ny,b in cuts(p['k'],N):pieces.extend(clip(poly,(nx*c+ny*s,-nx*s+ny*c),b))
                poly=hull(pieces)
            if area2(poly)>0:new.add(len(out));out.append({**p,'poly':poly,'own':bounds(poly)})
        domains.append(new)
    return out,domains

def tighten_float(poses,spans,N,branch,global_bounds):
    from explore_poses import clip as fc,convex_hull,area
    poses,spans=old_float(poses,spans,N,branch,global_bounds);out=[];fresh=[]
    for own,(lo,hi) in enumerate(spans):
        start=len(out)
        for p in poses[lo:hi]:
            poly=p['poly']
            if own==0:
                for nx,ny,b in BOX:poly=fc(poly,(float(nx),float(ny)),float(b))
                pieces=[]
                for nx,ny,b in cuts(p['k'],N):pieces.extend(fc(poly,(float(nx),float(ny)),float(b)+1e-10))
                poly=convex_hull(pieces)
            if area(poly)>1e-13:out.append({**p,'poly':poly})
        fresh.append((start,len(out)))
    return out,fresh
