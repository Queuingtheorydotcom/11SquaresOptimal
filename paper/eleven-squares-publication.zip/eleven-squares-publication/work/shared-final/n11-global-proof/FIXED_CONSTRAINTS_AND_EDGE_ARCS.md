# Persistent fixed constraints and actual-edge arcs

These are necessary-condition deductions for the remaining normalized case.
They do not assume the known construction's contact graph.

## Reapply constraints after outward rounding

The sixteen-direction polygon approximation enlarges each center region.
Its normals are fixed in midpoint edge coordinates, so the enlargement can
cross an already proved global x- or y-bound by more than the rounding unit.
This is safe but unnecessarily weak. Intersecting the enlarged polygon again
with every previously proved spatial halfplane, the current branch's
halfplanes, wall center bounds, and canonical-corner center bounds is safe.
Each actual feasible center satisfies all these inequalities independently
of the approximation. The five global inequalities used here are exactly
those in spatial-bounds-v3-verification.json; that certificate predates this
new kernel, so the use is not circular.

## Actual separating-edge directions

An angle bin is t in [k/N,(k+1)/N], where theta=2 arctan(t). Its angular
width is at most 2/N. For any actual pair of centers, their difference z has
length at most S sqrt(2)<6. For either rotating edge normal n(theta), the
function f(theta)=z dot n(theta) satisfies |f''|<6. Linear interpolation
between the bin endpoints therefore has error at most

    6 (2/N)^2 / 8 = 3/N^2.

Consequently its maximum absolute projection is at most the larger endpoint
absolute projection plus 3/N^2. Maximize these endpoint projections over
the exact center polygons to bound all feasible center choices.

For two actual side-a squares, the sum of support radii along an edge normal
of one square is

    a/2 (1 + |cos(delta)| + |sin(delta)|),

where delta is their relative angle. A lower bound for the parenthesized
trigonometric term is computed exactly from rational bin endpoint normals.
On each quadrant, |cos(delta)|+|sin(delta)| is concave, so its minimum is at
an interval endpoint, or equals 1 at a quadrant boundary. Because both
angles lie in [0,pi/2], their difference lies in [-pi/2,pi/2]; only an
interior crossing of zero needs separate handling. Endpoint quadrant
boundaries are already included by the endpoint evaluations.

Let g be this rational lower bound. If all four endpoint projections for
an owner's two normal directions are strictly below

    A_LO/2 (1+g) - 3/N^2,

none of that owner's actual edge normals can separate the squares. Check
both owners. If neither supplies a possible separating normal, the
separating-axis theorem excludes that pair of pose domains.

All decisive comparisons in exact_edge_arc_compatibility.py are rational.
The floating shortcut may retain extra edges; it cannot certify a missing
edge. Arc consistency then uses the same induction as the earlier checker.
