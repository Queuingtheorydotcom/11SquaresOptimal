"""Rational center pruning against every pose of a different owner.

Numerical shortcuts ONLY skip potential pruning. Every region that is
actually removed is constructed by rational half-plane intersections.
"""
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from marker_cases import A_LO
from exact_poses import clip,subtract_convex,area2

def refine_bin(task):
    poses,dom,bin_id,N=task
    axes={p['k']:(p['c'],p['s']) for p in poses}
    h=A_LO/(2*(1+F(1,N)));rel={};proj={};fp={};fproj={}
    for i,p in enumerate(poses):
        proj[i,p['k']]=p['own'];fproj[i,p['k']]=tuple(map(float,p['own']))
        fp[i]=[tuple(map(float,q)) for q in p['poly']]
    def relative(a,b):
        if (a,b) not in rel:
            c,s=axes[a];C,T=axes[b];d=c*C+s*T;e=-s*C+c*T
            rel[a,b]=(d,e,h*(1+abs(d)+abs(e)))
        return rel[a,b]
    def project(i,k,numeric=False):
        cache=fproj if numeric else proj
        if (i,k) not in cache:
            p=poses[i];d,e,_=relative(p['k'],k)
            if numeric:d=float(d);e=float(e);poly=fp[i]
            else:poly=p['poly']
            xs=[d*x+e*y for x,y in poly];ys=[-e*x+d*y for x,y in poly]
            cache[i,k]=(min(xs),max(xs),min(ys),max(ys))
        return cache[i,k]
    own_summary=[]
    for d in dom:
        bins={}
        for i in d:bins.setdefault(poses[i]['k'],[]).append(poses[i]['own'])
        own_summary.append({k:(min(p[0] for p in ranges),max(p[1] for p in ranges),min(p[2] for p in ranges),max(p[3] for p in ranges)) for k,ranges in bins.items()})
    # For each orientation, the intersection over all center components uses
    # max(maxima) for the lower bound and min(minima) for the upper bound.
    fboxes={};forbiddens={};out=[];regions=0;skips=0
    owner_of={i:owner for owner,d in enumerate(dom) for i in d}
    selected=[i for i in owner_of if poses[i]['k']==bin_id]
    for i in sorted(selected):
        owner=owner_of[i]
        p=poses[i];k=p['k'];poly=p['poly']
        for other,d in enumerate(dom):
            if other==owner:continue
            key=(k,other)
            if key not in fboxes:
                bounds=[]
                for j in d:
                    lo,hi,bottom,top=project(j,k,True);r=float(relative(k,poses[j]['k'])[2])
                    bounds.append((hi-r,lo+r,top-r,bottom+r))
                fboxes[key]=(max(b[0] for b in bounds),min(b[1] for b in bounds),max(b[2] for b in bounds),min(b[3] for b in bounds)) if bounds else (1,0,1,0)
            xmin,xmax,ymin,ymax=fboxes[key]
            xs=[float(q[0]) for q in poly];ys=[float(q[1]) for q in poly]
            if xmin>=xmax or ymin>=ymax or min(xs)>=xmax or max(xs)<=xmin or min(ys)>=ymax or max(ys)<=ymin:
                skips+=1;continue
            if key not in forbiddens:
                bounds=[]
                for j in d:
                    lo,hi,bottom,top=project(j,k);r=relative(k,poses[j]['k'])[2]
                    bounds.append((hi-r,lo+r,top-r,bottom+r))
                x0=max(b[0] for b in bounds);x1=min(b[1] for b in bounds)
                y0=max(b[2] for b in bounds);y1=min(b[3] for b in bounds)
                forbidden=[]
                if x0<x1 and y0<y1:
                    forbidden=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
                    for j,(xminj,xmaxj,yminj,ymaxj) in own_summary[other].items():
                        dd,ee,r=relative(k,j)
                        for n,bound in [((dd,ee),xminj+r),((-dd,-ee),r-xmaxj),((-ee,dd),yminj+r),((ee,-dd),r-ymaxj)]:
                            forbidden=clip(forbidden,n,bound)
                            if not forbidden:break
                        if not forbidden:break
                forbiddens[key]=forbidden;regions+=1
            forbidden=forbiddens[key]
            if area2(forbidden)>0:
                poly=subtract_convex(poly,forbidden)
                if area2(poly)<=0:poly=[];break
        if poly:
            out.append((i,{'k':k,'c':p['c'],'s':p['s'],'poly':poly,'own':(min(x for x,y in poly),max(x for x,y in poly),min(y for x,y in poly),max(y for x,y in poly))}))
    return out,{'bin':bin_id,'before':len(selected),'after':len(out),'constructed_forbidden_regions':regions,'heuristic_skips':skips}

def refine(poses,dom,N,jobs=1):
    tasks=[(poses,dom,k,N) for k in sorted({p['k'] for p in poses})]
    if jobs>1:
        with ProcessPoolExecutor(max_workers=jobs) as pool:results=list(pool.map(refine_bin,tasks))
    else:results=[refine_bin(task) for task in tasks]
    newposes=[];newdom=[set() for d in dom];checks=[];old_owner={i:owner for owner,d in enumerate(dom) for i in d};retained={}
    for ps,record in results:
        retained.update(ps);checks.append(record)
    for i in sorted(retained):
        newdom[old_owner[i]].add(len(newposes));newposes.append(retained[i])
    return newposes,newdom,checks
