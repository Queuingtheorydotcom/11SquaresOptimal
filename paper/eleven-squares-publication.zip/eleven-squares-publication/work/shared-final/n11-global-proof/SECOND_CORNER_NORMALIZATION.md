# Both upper corners can be fixed

Every hypothetical improvement of the eleven-unit-square record has a
representative, in the established fixed-container normalization, with

\[
 C_3\text{ owner}=[0,a]\times[S-a,S],\qquad
 C_2\text{ owner}=[S-a,S]^2,
\]

where \(S=97/25\) and \(4003/4000<a<25019/25000\). The other nine squares
are unchanged by these two replacements. This is an existence-preserving
normalization; it does not say every packing already has aligned corners.
**Global optimality is still unproved.**

The first replacement was proved in `CORNER_NORMALIZATION.md`. This document
proves the second by isolating, and exactly excluding, its only difficult
geometric obstruction. All calculations below start from the completed
seven-round root, not from later numerical exploration states.

## 1. The proposed replacement and its possible obstructions

Assume the C3 replacement has been made. Let P be the C2 owner, and set
\(E=[S-a,S]^2\). Owner indices throughout are

| Owner | Markers |
|---|---|
| 0 | I0,I1 |
| 1,2,3,4 | C0,C1,C2,C3, respectively |
| 5,6,7,8 | W0,W1,W2,W3, respectively |
| 9,10 | I2,I3, respectively |

The corner-support lemma from the first proof, reflected into this corner,
says that the support of E is at most that of P in every inward direction
\(n_x,n_y\le0\). Therefore a separator from P toward another square in
such a direction also separates E from that square.

Exact outer pose bounds show that owners 0,1,2,4,5,6,8,10 all miss E directly.
The only remaining owners are W2 (owner 7) and I2 (owner 9).

## 2. Condition on interference, rather than unrelated positions

Write \(E_+=[S-A_{\rm HI},S]^2\), which contains E. For an angle bin of
width \(1/N\) in \(t=\tan(\theta/2)\), the square is contained in the
reference square with the bin's midpoint orientation and half-side

\[
 H=\frac{A_{\rm HI}}2\left(1+\frac1N\right).
\]

If a square Q intersects E, its center must therefore belong to the
Minkowski sum of E+ and this centrally symmetric reference square.
`corner_obstruction_seed.py` intersects Q's exact rational center polygon
with this necessary region. This is an outer approximation, so it retains
every possible interior obstruction. It may also retain harmless boundary
contacts; excluding this larger set remains valid.

The seed also uses the proved common-inner-owner angle restriction, the
proved C2 angle alternatives, and the exact canonical C3 center. All other
center constraints come directly from the verified root hulls.

## 3. W2 cannot interfere

Impose the necessary interference condition on owner 7. The exact seed has
owner pose counts

\[
(10,128,138,20,1,74,101,14,140,52,30).
\]

`obstruction_journal.py` proposed one round of compulsory-hull deductions
followed by a contradiction. `exact_obstruction_journal.py` replayed these
deductions using rational arithmetic and the established conservative
center-pruning and overlap kernels. It checked every newly proposed hull
vertex against every surviving pose before using it. It then found an empty
domain under arc consistency. No floating decision is used as a premise.

The completed receipt is
`exploration/top-obstruction-certified-journal.json.verified-exclusion.json`.
Thus, in a packing with canonical C3, W2 cannot have interior overlap with E.

## 4. I2 cannot prevent the replacement

Now impose the necessary interference condition on owner 9. We need not
exclude this branch: I2 may be close to E. It suffices to show that P and I2
have a separator whose normal toward I2 is inward.

Disjoint convex squares have a separating axis parallel to an edge normal
of one of the squares. For each pair of angle bins, the checker considers
the two axes of both squares, with both signs. Any axis interval entirely
in the inward quadrant is harmless by the corner-support lemma. For all
other signed intervals it proves separation impossible.

Here is the exact inequality used. Let \(D=C_Q-C_P\) and
\(n(\theta)\) be one of the signed unit edge normals. Separation requires

\[
 n(\theta)\cdot D\ \ge\ \frac a2\bigl(1+g(\phi-\theta)\bigr),
 \qquad g(u)=|\cos u|+|\sin u|.
\]

The binwise minimum g_min is computed from rational half-angle endpoints,
including the value 1 when the relative-angle interval crosses zero.
Relative angles lie in [-pi/2,pi/2], so these candidates suffice. The center
polygons are rounded outward in sixteen rational directions before support
maxima are computed.

Throughout the container \(|D|<6\). The angular interval has width at most
\(2/N\). Linear interpolation of \(n(\theta)\cdot D\), whose second
derivative has absolute value below 6, gives

\[
 n(\theta)\cdot D
 \le \max\{n(\theta_0)\cdot D,n(\theta_1)\cdot D\}+\frac3{N^2}.
\]

Both endpoint normals are rational in the half-angle parameter. The checker
verifies, for every non-inward signed interval,

\[
 \max_{j=0,1}\left(
 \max_{C_Q} n(\theta_j)\cdot C_Q-
 \min_{C_P} n(\theta_j)\cdot C_P\right)
 <\frac{A_{\rm LO}}2(1+g_{\min})-\frac3{N^2}.
\]

All 5,760 such checks pass. The smallest exact margin is positive and its
decimal value exceeds 0.09075. The receipt is
`second-corner-axes-verification.json`; the checker is
`exact_second_corner_axes.py`.

If I2 already misses E there is nothing to prove. Otherwise its true center
belongs to the interference-conditioned seed, so these checks apply. Some
separating axis between P and I2 exists; all non-inward alternatives have
been excluded. The corner-support lemma therefore shows that E also misses
I2 in interior.

## 5. Conclusion, ancestry, and replay

Every other square misses E, either directly, by the W2 exclusion, or by
the I2 separator argument. Replacing P by E is feasible. E contains C2 in
its interior and none of the other eleven markers, as checked exactly in
the assembly script. It is disjoint from canonical C3 since 2a<S. Thus all
previous case and common-inner-angle reductions remain valid.

`assemble_second_corner_normalization.py` joins the two completed checks,
verifies their input hashes and the seed ancestry, and checks marker
ownership. It also checks explicitly that the inherited C3 compulsory hull
lies in every canonical C3 square in the side interval. Its output is
`second-corner-normalization-verification.json`.

To replay the new checks from the archived verified root:

```sh
python3 corner_obstruction_seed.py --owner 7 --jobs 4 --output exploration/top-obstruction-certified-seed.json
python3 exact_obstruction_journal.py exploration/top-obstruction-certified-journal.json --jobs 6
python3 corner_obstruction_seed.py --owner 9 --jobs 4 --output exploration/inner-obstruction-certified-seed.json
python3 exact_second_corner_axes.py
python3 assemble_second_corner_normalization.py
```

Do not use Python's -O option. Root and earlier-angle replays are described
in `CORNER_NORMALIZATION.md` and `NEXT_STEPS.md`. Receipts include immutable
source hashes; replaying a receipt with elapsed-time fields changes its hash,
so regenerate downstream joins after replaying upstream checks.

This removes six center/angle variables from an existence search. The
remaining task is to force the other squares into the certified local
isolation neighborhood, or obtain a different global contradiction.
