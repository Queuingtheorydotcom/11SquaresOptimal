"""Rational center pruning from actual-edge endpoint strip intersections."""
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from exact_edge_arc_compatibility import Compatibility
from exact_poses import clip,subtract_convex,area2
from exact_persistent_journal import bounds as polygon_bounds

def initialize(poses,dom,N):
    global SHARED
    SHARED=poses,dom,N

def worker(k):
    poses,dom,N=SHARED;cc=Compatibility(poses,N)
    owner_of={i:own for own,d in enumerate(dom) for i in d}
    selected=[i for i in owner_of if poses[i]['k']==k]
    C,T=poses[selected[0]]['c'],poses[selected[0]]['s']
    cache={};out=[];regions=0;strips=0
    for i in sorted(selected):
        p=poses[i];poly=p['poly'];own=owner_of[i]
        for other,domain in enumerate(dom):
            if other==own:continue
            if other not in cache:
                agg={}
                for j in sorted(domain):
                    l=poses[j]['k'];R=cc.threshold(k,l)
                    for q in sorted(set([k,k+1,l,l+1])):
                        x0,x1,y0,y1=cc.endpoint_project(j,q)
                        values=(x1-R,x0+R,y1-R,y0+R)
                        if q in agg:
                            a,b,c,d=agg[q];e,f,g,h=values
                            agg[q]=max(a,e),min(b,f),max(c,g),min(d,h)
                        else:agg[q]=values
                forbidden=[(F(-10),F(-10)),(F(10),F(-10)),(F(10),F(10)),(F(-10),F(10))]
                for q,(x0,x1,y0,y1) in agg.items():
                    c,s=cc.endpoint[q];u=c*C+s*T;v=-c*T+s*C
                    for n,b in [((u,v),x1),((-u,-v),-x0),((-v,u),y1),((v,-u),-y0)]:
                        forbidden=clip(forbidden,n,b);strips+=1
                        if not forbidden:break
                    if not forbidden:break
                cache[other]=forbidden;regions+=1
            forbidden=cache[other]
            if area2(forbidden)>0:
                poly=subtract_convex(poly,forbidden)
                if area2(poly)<=0:poly=[];break
        if poly:out.append((i,{**p,'poly':poly,'own':polygon_bounds(poly)}))
    return out,{'bin':k,'before':len(selected),'after':len(out),'actual_edge_forbidden_regions':regions,'rational_strip_clips':strips}

def refine(poses,dom,N,jobs=1):
    bins=sorted({poses[i]['k'] for d in dom for i in d})
    if jobs>1:
        with ProcessPoolExecutor(max_workers=jobs,initializer=initialize,initargs=(poses,dom,N)) as pool:results=list(pool.map(worker,bins))
    else:
        initialize(poses,dom,N);results=[worker(k) for k in bins]
    retained={};checks=[];owner={i:own for own,d in enumerate(dom) for i in d}
    for ps,record in results:retained.update(ps);checks.append(record)
    out=[];fresh=[set() for d in dom]
    for i in sorted(retained):fresh[owner[i]].add(len(out));out.append(retained[i])
    return out,fresh,checks
