"""Run the unchanged arc checker with the equivalent low-copy dispatcher."""
import sys
import exact_pair_regions_fast
import exact_arc_hulls

if __name__=='__main__':
    sys.modules['exact_pair_regions']=exact_pair_regions_fast
    exact_arc_hulls.main()
