"""Exact spatial branch of the proved two-corner normalized pose cover."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
from corner_obstruction_seed import sha,foundation
from exact_persistent_journal import bounds
from exact_poses import clip,area2

def validate_root(path):
 foundation();d=json.loads(Path(path).read_text());assert d['method']=='exact_two_corner_seed' and d['case']==6 and d['normalized_corners']==[3,4]
 for p,h in d['source_hashes'].items():assert sha(p)==h,p
 r=json.loads(Path('second-corner-normalization-verification.json').read_text());assert r['hypothesis_ancestry_discharged']
 for p,h in r['source_hashes'].items():assert sha(p)==h,p
 return d

def load_seed(path):
 d=json.loads(Path(path).read_text());assert d['method']=='exact_spatial_branch_seed' and d['case']==6 and d['normalized_corners']==[3,4]
 validate_root(d['root'])
 for p,h in d['source_hashes'].items():assert sha(p)==h,p
 poses=[];dom=[]
 for owner in d['owners']:
  ids=set()
  for p in owner:
   poly=[tuple(map(F,q)) for q in p['poly']];ids.add(len(poses));poses.append({'k':p['k'],'c':F(p['c']),'s':F(p['s']),'poly':poly,'own':bounds(poly)})
  dom.append(ids)
 return d,poses,dom

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='exploration/two-corner-global-certified-seed.json');ap.add_argument('--owner',type=int,required=True);ap.add_argument('--cut',nargs=3,action='append',required=True);ap.add_argument('--output',required=True);args=ap.parse_args();d=validate_root(args.root);assert 0<=args.owner<11
 cuts=[list(map(F,cut)) for cut in args.cut];owners=[]
 for own,ps in enumerate(d['owners']):
  out=[]
  for p in ps:
   c,s=F(p['c']),F(p['s']);poly=[tuple(map(F,z)) for z in p['poly']]
   if own==args.owner:
    for nx,ny,b in cuts:poly=clip(poly,(nx*c+ny*s,-nx*s+ny*c),b)
   if area2(poly)>0:out.append({**p,'poly':[[str(x),str(y)] for x,y in poly]})
  owners.append(out)
 paths=[Path(args.root),Path(__file__),Path('exact_poses.py'),Path('exact_persistent_journal.py')]
 seed={**d,'method':'exact_spatial_branch_seed','root':args.root,'owners':owners,'spatial_cut':{'owner':args.owner,'inequalities':[[str(v) for v in cut] for cut in cuts]},'source_hashes':{str(p):sha(p) for p in paths},'scope':'Necessary exact outer domains, conditional on stated spatial halfplanes after two-corner normalization.'}
 Path(args.output).write_text(json.dumps(seed));print('seed',[len(o) for o in owners],flush=True)
if __name__=='__main__':main()
