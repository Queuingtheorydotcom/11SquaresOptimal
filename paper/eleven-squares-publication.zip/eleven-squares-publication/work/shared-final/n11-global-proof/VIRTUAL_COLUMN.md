# A virtual two-square column for the I2 owner

Let P be the C1 owner, Q the W1 owner, and R the I2 owner in the normalized
packing. The actual common side is a. Put

\[
 E=[S-a,S]\times[0,2a].
\]

The conclusion is that the interiors of R and E are disjoint. This does
not move P or Q and does not assert a column normalization for all neighbors.

## Why the virtual obstacle is valid

The proved bound x_C1>3.1 and the exact global pose cover place both complete
squares P and Q in x>=S-3a/2. `lower-right-strip-verification.json` checks
this with positive rational margins. STRIP_SUPPORT_DOMINATION.md therefore
gives h_E(n)<=max(h_P(n),h_Q(n)) for every inward normal n=(-v,u), u,v>=0.

Suppose R intersects the interior of E. Its center then lies in E enlarged
by its outer reference square. `column_neighbor_axes.py` imposes precisely
this necessary condition, using the conservative larger rectangle
[S-A_HI,S] x [0,2 A_HI]. For every resulting R pose and every Q pose it
rules out all separating axes except the NW edge normal n=(-sin(theta_R),
cos(theta_R)) of R. The endpoint-normal estimates and curvature error are
proved in FIXED_CONSTRAINTS_AND_EDGE_ARCS.md. There are 5,852 signed-axis
checks, all with positive margins. Thus actual nonoverlap of Q and R
forces h_Q(n)<=l_R(n), where l_R is R's lower support.

For that same normal, 506 further exact checks give h_P(n)<l_R(n).
They bound the sum of radii above by A_HI*(1+99/70)/2, using
sqrt(2)<99/70, and bound the center separation below by its endpoint
minimum minus 3/N^2. It follows that

\[
 h_E(n)\le\max(h_P(n),h_Q(n))\le l_R(n),
\]

contradicting interior intersection of R and E. The obstruction hypothesis
is thereby discharged, and the virtual obstacle holds globally after the
established normalizations.

## A precise necessary inequality

The upper-left corner p(a)=(S-a,2a) of E cannot lie in the interior of R.
The unconditioned exact pose cover puts R's center in
[2.4,2.7] x [2.3,2.6]. Endpoint projection checks, with curvature error
1/(2N^2), put p(a) strictly inside R's strip parallel to (cos(theta),sin(theta))
for every a in [A_LO,A_HI]. Also p_x-X>0 and p_y-Y<0. Thus p(a) can be
excluded only by the lower edge with normal (-sin(theta),cos(theta)).
Consequently every surviving actual R satisfies

\[
 -\sin\theta\,X+\cos\theta\,Y
 \ge-\sin\theta\,S+a\bigl(\sin\theta+2\cos\theta+\tfrac12\bigr). \tag{1}
\]

Replacing a on the right by A_LO weakens the inequality strictly. If

\[
 F(\theta)=\sin\theta(S-X-A_{LO})
       +\cos\theta(Y-2A_{LO})-A_{LO}/2,
\]

then F(actual theta)>0. The global center bounds also give
|(S-X-A_LO,Y-2A_LO)|<1. For an angle bin of width at most 2/N,
linear interpolation bounds its deviation from the endpoint chord by
1/(2N^2). At least one endpoint must therefore satisfy

\[
 F(\theta_{endpoint})>-1/(2N^2). \tag{2}
\]

This is a union of two rational halfplanes for the center. Intersect each
with the retained center polygon and convexify their union. This operation
can only enlarge the feasible set. Reapply it after each outer rounding.
The strict weakening from a>A_LO ensures that discarding zero-area pieces
does not discard an actual feasible center.
