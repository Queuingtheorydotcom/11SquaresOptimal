"""Exact pose domains after C3 normalization and a proposed C2 obstruction."""
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse,json,hashlib,time
from marker_cases import S,A_LO,A_HI,all_cases,groups
from forced_markers import hull
from exact_poses import clip,area2
from exact_arc_hulls import make_owner
from exact_persistent_journal import bounds

BASE=Path('exploration/corner-global-root-N96.json')
NORMALIZATION=Path('corner-normalization-verification.json')
ANGLES=Path('combined-angle-verification.json')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def foundation():
 d=json.loads(BASE.read_text());r=json.loads(Path(str(BASE)+'.verified-prefix.json').read_text());v=json.loads(NORMALIZATION.read_text());a=json.loads(ANGLES.read_text())
 assert d['base'] is None and d['case']==6 and d['branch']==[0,30,40] and d['bins']==96
 assert r['journal_sha256']==sha(BASE) and not r['base_assumed'] and r['completed_round']==len(d['history'])-1==6
 assert v['hypothesis_ancestry_discharged'] and v['corner_owner']==4
 for p,h in v['source_hashes'].items():assert sha(p)==h,p
 assert a['pair_half_angle']=='5/16 < t <= sqrt(2)-1' and a['C2_half_angle']=='[0,5/48) union (43/48,1]'
 for x in a['sources']:assert sha(x['receipt'])==x['sha256']
 return d

def intersect(poly,region):
 for a,b in zip(region,region[1:]+region[:1]):
  n=(b[1]-a[1],a[0]-b[0]);poly=clip(poly,n,n[0]*a[0]+n[1]*a[1])
 return poly

def constrained_owner(arg):
 own,N,gs,hs,obstructor=arg
 branch=(int(F(5,16)*N),int(F(5,12)*N)) if own==0 else ((0,1) if own==4 else None)
 ps=make_owner((gs[own],N,gs,hs,{gs[0]:F(5,12)},branch));out=[];H=A_HI*(1+F(1,N))/2
 E=[(S-A_HI,S-A_HI),(S,S-A_HI),(S,S),(S-A_HI,S)]
 for p in ps:
  k=p['k'];c=p['c'];s=p['s'];poly=p['poly']
  if own==3 and not (F(k,N)<F(5,48) or F(k+1,N)>F(43,48)):continue
  if own==4:
   for n,b in [((c,-s),A_HI/2),((-c,s),-A_LO/2),((s,c),S-A_LO/2),((-s,-c),-(S-A_HI/2))]:poly=clip(poly,n,b)
  if own==obstructor:
   forbidden=hull([(c*x+s*y+i*H,-s*x+c*y+j*H) for x,y in E for i in [-1,1] for j in [-1,1]])
   poly=intersect(poly,forbidden)
  if area2(poly)>0:out.append({'k':k,'c':str(c),'s':str(s),'poly':[[str(x),str(y)] for x,y in poly]})
 return out

def make_seed(N,obstructor,jobs):
 base=foundation();assert N%48==0 and obstructor in [7,9]
 gs=groups(all_cases()[0][6]);hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,base['history'][-1]['hulls'])}
 hs[gs[4]]=hull(hs[gs[4]]+[(F(0),S-A_LO),(A_LO,S-A_LO),(A_LO,S),(F(0),S)])
 tasks=[(own,N,gs,hs,obstructor) for own in range(11)]
 with ProcessPoolExecutor(max_workers=jobs) as pool:owners=list(pool.map(constrained_owner,tasks))
 paths=[BASE,Path(str(BASE)+'.verified-prefix.json'),NORMALIZATION,ANGLES,Path(__file__),Path('exact_arc_hulls.py'),Path('exact_poses.py'),Path('exact_persistent_journal.py'),Path('forced_markers.py'),Path('marker_cases.py')]
 return {'method':'exact_corner_obstruction_seed','case':6,'bins':N,'obstructor':obstructor,'normalized_corner_owner':4,'groups':[list(g) for g in gs],'hulls':[[[str(x),str(y)] for x,y in hs[g]] for g in gs],'owners':owners,'source_hashes':{str(p):sha(p) for p in paths},'scope':'Necessary domains for a canonical-C3 packing whose stated owner intersects the proposed canonical C2 square in interior. All interval cuts are outer approximations.'}

def load_seed(path):
 d=json.loads(Path(path).read_text());assert d['method']=='exact_corner_obstruction_seed' and d['case']==6 and d['normalized_corner_owner']==4 and d['obstructor'] in [7,9]
 for p,h in d['source_hashes'].items():assert sha(p)==h,(p,h)
 r=json.loads(Path(str(path)+'.verified.json').read_text());assert r['seed_sha256']==sha(path) and r['ancestry_discharged']
 poses=[];dom=[]
 for owner in d['owners']:
  ids=set()
  for p in owner:
   poly=[tuple(map(F,q)) for q in p['poly']];ids.add(len(poses));poses.append({'k':p['k'],'c':F(p['c']),'s':F(p['s']),'poly':poly,'own':bounds(poly)})
  dom.append(ids)
 return d,poses,dom

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--bins',type=int,default=96);ap.add_argument('--owner',type=int,default=7);ap.add_argument('--jobs',type=int,default=4);ap.add_argument('--output',required=True);args=ap.parse_args();start=time.time();d=make_seed(args.bins,args.owner,args.jobs);p=Path(args.output);p.write_text(json.dumps(d))
 r={'verdict':'VERIFIED necessary seed domains under geometric obstruction hypothesis','seed_sha256':sha(p),'ancestry_discharged':True,'counts':[len(o) for o in d['owners']],'seconds':time.time()-start,'scope':'No exclusion conclusion. The hypothesized obstruction is a branch condition.'}
 Path(str(p)+'.verified.json').write_text(json.dumps(r,indent=2)+'\n');print(r,flush=True)
if __name__=='__main__':main()
