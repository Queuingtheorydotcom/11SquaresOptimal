"""Exact corner-replacement checks conditional on a fixed journal's final hulls.
A separate assembly checks that the hull ancestry has completed its replay.
"""
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import json,hashlib,time
from marker_cases import S,A_LO,A_HI,all_cases,groups
from forced_markers import hull
from exact_arc_hulls import make_owner
from exact_poses import clip

SOURCE=Path('exploration/corner-global-root-N96.json')
NORMALS=[(1,0),(2,1),(1,1),(1,2),(0,1),(-1,2),(-1,1),(-2,1),(-1,0),(-2,-1),(-1,-1),(-1,-2),(0,-1),(1,-2),(1,-1),(2,-1)]
D=10**6

def direction(t):return ((1-t*t)/(1+t*t),2*t/(1+t*t))
def dot(n,p):return n[0]*p[0]+n[1]*p[1]
def rot(n):return (-n[1],n[0])
def project(n,poly):
 vals=[dot(n,p) for p in poly];return min(vals),max(vals)
def outer_poly(p):
 c,s=p['c'],p['s'];xy=[(c*x-s*y,s*x+c*y) for x,y in p['poly']];poly=[(F(0),F(0)),(S,F(0)),(S,S),(F(0),S)]
 for n in NORMALS:
  v=max(dot(n,q) for q in xy);bound=F(-((-v*D).__floor__()),D);poly=clip(poly,n,bound)
 return {'k':p['k'],'c':c,'s':s,'poly':poly}
def task(t):return [outer_poly(p) for p in make_owner(t)]
def gmin(k,l,N):
 a=[direction(F(k,N)),direction(F(k+1,N))];b=[direction(F(l,N)),direction(F(l+1,N))]
 vals=[abs(dot(x,y))+abs(dot(rot(x),y)) for x in a for y in b]
 if k<=l+1 and l<=k+1:vals.append(F(1))
 return min(vals)

def main():
 start=time.time();raw=SOURCE.read_bytes();d=json.loads(raw);N=d['bins'];assert d['case']==6 and d['branch']==[0,30,40] and N==96
 gs=groups(all_cases()[0][6]);hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,d['history'][-1]['hulls'])}
 tasks=[(g,N,gs,hs,{gs[0]:F(5,12)},(30,40) if i==0 else None) for i,g in enumerate(gs)]
 with ProcessPoolExecutor(max_workers=2) as pool:owners=list(pool.map(task,tasks))
 print('Exact outer pose covers',[len(x) for x in owners],time.time()-start,flush=True)
 own=4;sx,sy=1,-1;P=owners[own];box=[(F(0),S),(A_HI,S),(A_HI,S-A_HI),(F(0),S-A_HI)];H=A_HI*(1+F(1,N))/2;error=F(3,N*N)
 records=[];cache={};minimum=None;badchecks=0
 for other,Q in enumerate(owners):
  if other==own:continue
  direct=0;checked=0
  for q in Q:
   dirs=[(F(1),F(0)),(F(0),F(1)),(q['c'],q['s']),(-q['s'],q['c'])]
   separate=False
   for n in dirs:
    support=H*(abs(n[0]*q['c']+n[1]*q['s'])+abs(-n[0]*q['s']+n[1]*q['c']));lo,hi=project(n,q['poly']);a,b=project(n,box)
    if lo-support>b or a>hi+support:separate=True;break
   if separate:direct+=1;continue
   for p in P:
    key=(p['k'],q['k'])
    if key not in cache:cache[key]=A_LO*(1+gmin(*key,N))/2-error
    threshold=cache[key]
    for ownerpose in [p,q]:
     endpoints=[direction(F(ownerpose['k'],N)),direction(F(ownerpose['k']+1,N))]
     for axis in [0,1]:
      ns=[rot(n) if axis else n for n in endpoints]
      for sign in [-1,1]:
       normals=[(sign*n[0],sign*n[1]) for n in ns]
       if all(sx*n[0]>=0 and sy*n[1]>=0 for n in normals):continue
       upper=max(project(n,q['poly'])[1]-project(n,p['poly'])[0] for n in normals)
       margin=threshold-upper
       assert margin>0,('non-inward axis not excluded',other,p['k'],q['k'],axis,sign,float(margin))
       minimum=margin if minimum is None else min(minimum,margin);checked+=1
  records.append({'other_owner':other,'poses':len(Q),'directly_separated_from_new_corner':direct,'excluded_non_inward_signed_axes':checked});badchecks+=checked
  print('owner',other,records[-1],flush=True)
 sources=[SOURCE,Path(__file__),Path('exact_arc_hulls.py'),Path('exact_poses.py'),Path('forced_markers.py'),Path('marker_cases.py')]
 receipt={'verdict':'VERIFIED corner replacement conditional on stated compulsory hulls','corner_owner':4,'corner_marker':3,'hypothesis_journal':str(SOURCE),'hypothesis_sha256':hashlib.sha256(raw).hexdigest(),'owner_pose_counts':[len(x) for x in owners],'records':records,'excluded_non_inward_signed_axes':badchecks,'minimum_axis_exclusion_margin':str(minimum),'minimum_margin_decimal':float(minimum),'conclusion':'The C3 owner may be replaced by [0,a] x [S-a,S], preserving nonoverlap, container side, and all marker ownership.','scope':'Requires the geometric corner-support lemma and a completed ancestry replay; this receipt alone is conditional.','source_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'seconds':time.time()-start}
 Path('corner-normalization-conditional.json').write_text(json.dumps(receipt,indent=2)+'\n');print('VERIFIED conditional corner replacement',badchecks,float(minimum),time.time()-start,flush=True)
if __name__=='__main__':main()
