"""Exact diagnostic for a virtual right column and the I2 owner.

Only a complete pass certifies the geometric hypotheses. Inconclusive
pose pairs are reported and are not counterexamples or proof premises.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
from spatial_branch_seed import validate_root
from corner_obstruction_seed import sha,intersect
from exact_persistent_journal import bounds
from exact_poses import area2
from forced_markers import hull
from marker_cases import S,A_HI
from exact_edge_arc_compatibility import Compatibility

def main():
    ap=argparse.ArgumentParser();ap.add_argument('seed');ap.add_argument('output');args=ap.parse_args()
    d=validate_root(args.seed);N=d['bins'];H=A_HI*(1+F(1,N))/2;poses=[];dom=[]
    E=[(x,y) for x in [S-A_HI,S] for y in [F(0),2*A_HI]]
    for own,owner in enumerate(d['owners']):
        ids=[]
        for pp in owner:
            c,s=F(pp['c']),F(pp['s']);poly=[tuple(map(F,p)) for p in pp['poly']]
            if own==9:
                forbidden=hull([(c*x+s*y+i*H,-s*x+c*y+j*H) for x,y in E for i in [-1,1] for j in [-1,1]])
                poly=intersect(poly,forbidden)
            if area2(poly)>0:
                ids.append(len(poses));poses.append({'k':pp['k'],'c':c,'s':s,'poly':poly,'own':bounds(poly)})
        dom.append(ids)
    cc=Compatibility(poses,N);bad=[];checks=0;minmargin=None;farbad=[];farchecks=0;farmin=None
    for i in dom[9]:
        for j in dom[6]:
            threshold=cc.threshold(poses[i]['k'],poses[j]['k'])
            for axisowner in [i,j]:
                for axis in [0,1]:
                    for sign in [-1,1]:
                        if axisowner==i and axis==1 and sign==1:continue
                        separation=[]
                        for k in [poses[axisowner]['k'],poses[axisowner]['k']+1]:
                            a=cc.endpoint_project(i,k);b=cc.endpoint_project(j,k)
                            lo,hi=2*axis,2*axis+1
                            separation.append(a[hi]-b[lo] if sign==1 else b[hi]-a[lo])
                        margin=threshold-max(separation);checks+=1
                        if minmargin is None or margin<minmargin:minmargin=margin
                        if margin<=0:bad.append({'I2_bin':poses[i]['k'],'W1_bin':poses[j]['k'],'axis_owner':'I2' if axisowner==i else 'W1','axis':axis,'sign':sign,'margin':str(margin)})
        for j in dom[2]:
            lower=[]
            for k in [poses[i]['k'],poses[i]['k']+1]:
                a=cc.endpoint_project(i,k);b=cc.endpoint_project(j,k);lower.append(a[2]-b[3])
            margin=min(lower)-F(3,N*N)-A_HI*F(169,140);farchecks+=1
            if farmin is None or margin<farmin:farmin=margin
            if margin<=0:farbad.append({'I2_bin':poses[i]['k'],'C1_bin':poses[j]['k'],'margin':str(margin)})
    sources=[Path(args.seed),Path(__file__),Path('exact_edge_arc_compatibility.py'),Path('FIXED_CONSTRAINTS_AND_EDGE_ARCS.md')]
    out={'verdict':'VERIFIED I2 virtual-column separator hypotheses' if not bad and not farbad else 'INCONCLUSIVE virtual-column separator hypotheses','counts':[len(v) for v in dom],'excluded_axis_checks':checks,'unresolved_axis_checks':len(bad),'minimum_axis_margin':str(minmargin),'C1_separation_checks':farchecks,'unresolved_C1_checks':len(farbad),'minimum_C1_margin':str(farmin),'unresolved_axes':bad,'unresolved_C1':farbad,'source_hashes':{str(p):sha(p) for p in sources},'scope':'I2 is conditioned on possible intersection with the canonical column. A complete pass forces its NW edge to separate W1 and also separates C1 along that same edge. The support-domination theorem is needed to discharge the obstruction.'}
    Path(args.output).write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['unresolved_axes','unresolved_C1','source_hashes']})
if __name__=='__main__':main()
