"""Reimpose independently proved center constraints after outer rounding."""
from fractions import Fraction as F
from pathlib import Path
import json
from corner_obstruction_seed import sha
from marker_cases import S,A_LO,A_HI
from exact_persistent_journal import bounds
from exact_poses import clip,area2

CERTIFICATE='spatial-bounds-v3-verification.json'

def load_bounds():
    d=json.loads(Path(CERTIFICATE).read_text())
    assert d['ancestry_discharged'] and d['normalized_corners']==[3,4]
    assert d['verdict']=='VERIFIED necessary spatial bounds after two-corner normalization'
    for p,h in d['source_hashes'].items():assert sha(p)==h,p
    return d['necessary_halfplanes']

def constraints(own,k,N,branch,global_bounds):
    w=lambda z:(1+2*z-z*z)/(1+z*z)
    wall=A_LO*min(w(F(k,N)),w(F(k+1,N)))/2
    cs=[(F(1),F(0),S-wall),(F(-1),F(0),-wall),(F(0),F(1),S-wall),(F(0),F(-1),-wall)]
    for b in global_bounds:
        if b['owner']==own:cs.append((*map(F,b['normal']),F(b['upper'])))
    if branch['owner']==own:cs += [tuple(map(F,c)) for c in branch['inequalities']]
    if own in [3,4]:
        xlo,xhi=(S-A_HI/2,S-A_LO/2) if own==3 else (A_LO/2,A_HI/2)
        cs += [(F(1),F(0),xhi),(F(-1),F(0),-xlo),(F(0),F(1),S-A_LO/2),(F(0),F(-1),-(S-A_HI/2))]
    return cs

def tighten(poses,dom,N,branch,global_bounds):
    fresh=[];domains=[]
    for own,ids in enumerate(dom):
        new=set()
        for i in sorted(ids):
            p=poses[i];c,s=p['c'],p['s'];poly=p['poly']
            for nx,ny,b in constraints(own,p['k'],N,branch,global_bounds):
                poly=clip(poly,(nx*c+ny*s,-nx*s+ny*c),b)
            if area2(poly)>0:
                new.add(len(fresh));fresh.append({**p,'poly':poly,'own':bounds(poly)})
        domains.append(new)
    return fresh,domains

def tighten_float(poses,spans,N,branch,global_bounds):
    from explore_poses import clip as fc,area
    fresh=[];out=[]
    for own,(a,b) in enumerate(spans):
        start=len(fresh)
        for p in poses[a:b]:
            poly=p['poly']
            for nx,ny,upper in constraints(own,p['k'],N,branch,global_bounds):
                poly=fc(poly,(float(nx),float(ny)),float(upper))
            if area(poly)>1e-13:fresh.append({**p,'poly':poly})
        out.append((start,len(fresh)))
    return fresh,out
