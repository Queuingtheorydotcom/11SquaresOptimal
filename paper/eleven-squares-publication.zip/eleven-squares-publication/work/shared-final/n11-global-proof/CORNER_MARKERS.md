# Additional compulsory points for singleton corner owners

Let `S=97/25`, `a>4003/4000`, and retain the twelve markers of `RESEARCH.md`.
If a square owns C0=(1,1) and no other marker, it contains each of

    (489/500,4003/4000), (981/1000,997/1000),
    (493/500,991/1000), (991/1000,493/500),
    (997/1000,981/1000), (4003/4000,489/500),
    (4003/4000,4003/4000).

Consequently their convex hull is compulsory. The rotated statement holds
for each other singleton corner owner.

For each listed q=(x,y), replace C0 by q while retaining all other markers.
The original covering argument remains valid:

* The modified corner rectangle has side lengths x,y at most 4003/4000,
  strictly less than a. Its inner corner q is therefore forced for square
  centers in that rectangle.
* The adjacent bottom wall quadrilateral has width m-x and endpoint heights
  y and b, where m=97/50 and b=3/4. Scale lengths by y and apply the original
  wall-quadrilateral lemma with parameters (m-x)/y and b/y. The square's
  scaled side is a/y>1. The adjacent left quadrilateral uses (m-y)/x and b/x.
* The other six wall quadrilaterals and three corner rectangles are unchanged.
* The original fourteen triangles with C0 replaced by q still have positive
  orientation and edge lengths at most 1<a. Their oriented interior edges
  cancel, and their boundary is the modified central octagon.

`corner_markers.py` verifies every squared-length comparison, both scaled
wall inequalities, the triangulation, and the exact area identity

    xy + 3 + 6*(47/50)*(1+b)/2
       + (m-x)*(y+b)/2 + (m-y)*(x+b)/2 + central_area = S^2.

The wall inequalities are certified with rational Bernstein coefficient
bounds on a partition of the half-angle interval. Thus every square under
consideration contains a marker of each modified cover. The singleton C0
owner avoids the unchanged eleven markers, so it must contain q. Applying
this argument separately to the seven covers gives the assertion.

Reproduce the arithmetic with `python3 corner_markers.py`; the record is
`corner-marker-verification.json`. An independent algebraic check confirms
that the known packing contains all of these additional corner points; see
`corner-marker-record-control.json`, reproduced by `python3 check_corner_record.py`.

These points gave only a small improvement in the exploratory upper-angle
pose covers. They are an auxiliary geometric deduction, not a proof of
optimality or an assumption used by the completed earlier exclusions.
