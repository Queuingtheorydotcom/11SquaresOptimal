"""Floating discovery of conservative pose covers. NOT a proof certificate.

Every test has an exact rational analogue, to be replayed for any claimed
exclusion. The angle grid is a cover of intervals, not a sample of angles.
"""
import argparse, json, math, time
from pathlib import Path
import numpy as np
from marker_cases import POINTS, S, A_LO, A_HI, all_cases, groups,SYMMETRY_OWNER
from forced_markers import owned_points

def convex_hull(ps):
    ps=sorted(set(tuple(p) for p in ps));a=[];b=[]
    if len(ps)<2:return ps
    cross=lambda o,p,q:(p[0]-o[0])*(q[1]-o[1])-(p[1]-o[1])*(q[0]-o[0])
    for p in ps:
        while len(a)>1 and cross(a[-2],a[-1],p)<=0:a.pop()
        a.append(p)
    for p in reversed(ps):
        while len(b)>1 and cross(b[-2],b[-1],p)<=0:b.pop()
        b.append(p)
    return a[:-1]+b[:-1]

def area(poly):return abs(sum(poly[i][0]*poly[(i+1)%len(poly)][1]-poly[i][1]*poly[(i+1)%len(poly)][0] for i in range(len(poly))))/2 if len(poly)>2 else 0.

def subtract_convex(poly,forbidden):
    out=[];rem=poly
    for a,b in zip(forbidden,forbidden[1:]+forbidden[:1]):
        n=(b[1]-a[1],a[0]-b[0]);d=n[0]*a[0]+n[1]*a[1]
        outside=clip(rem,(-n[0],-n[1]),-d)
        if area(outside)>1e-13:out.append(outside)
        rem=clip(rem,n,d)
        if not rem:break
    return out

def clip(poly,n,d):
    if not poly:return []
    out=[]
    prev=poly[-1]; a=prev[0]*n[0]+prev[1]*n[1]-d
    for p in poly:
        b=p[0]*n[0]+p[1]*n[1]-d
        if (a<=1e-12)!=(b<=1e-12):
            f=a/(a-b);out.append((prev[0]+f*(p[0]-prev[0]),prev[1]+f*(p[1]-prev[1])))
        if b<=1e-12:out.append(p)
        prev=p;a=b
    return out

def subtract(poly,x0,x1,y0,y1):
    # Remove the OPEN rectangle; its boundary is safely retained.
    if not poly:return []
    xx=[p[0] for p in poly]; yy=[p[1] for p in poly]
    if max(xx)<=x0 or min(xx)>=x1 or max(yy)<=y0 or min(yy)>=y1:return [poly]
    out=[]
    for n,d in [((1,0),x0),((-1,0),-x1)]:
        p=clip(poly,n,d)
        if p:out.append(p)
    mid=clip(clip(poly,(-1,0),-x0),(1,0),x1)
    for n,d in [((0,1),y0),((0,-1),-y1)]:
        p=clip(mid,n,d)
        if p:out.append(p)
    return out

def pose_cover(ids,N,allgroups=None,owned_hulls=None,angle_limits=None):
    p=np.array(POINTS,float); S0=float(S);lo=float(A_LO);hi=float(A_HI)
    getowned=lambda g:owned_hulls[tuple(g)] if owned_hulls is not None else owned_points(g)
    owned=np.array(getowned(ids),float)
    other_hulls=[np.array(getowned(g),float) for g in allgroups if g!=ids] if allgroups is not None else []
    ans=[]
    for k in range(N):
        if angle_limits is not None and ids in angle_limits and k/N>=angle_limits[ids]:continue
        t0=k/N;t1=(k+1)/N;t=(t0+t1)/2; dt=(t1-t0)/2
        c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
        uv=p@np.array([[c,-s],[s,c]])
        uvown=owned@np.array([[c,-s],[s,c]])
        q=1+2*dt; H=hi*q/2;h=lo/(2*q)
        x0=max(uvown[:,0]-H);x1=min(uvown[:,0]+H)
        y0=max(uvown[:,1]-H);y1=min(uvown[:,1]+H)
        if x0>x1 or y0>y1:continue
        poly=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
        w=lambda t:(1+2*t-t*t)/(1+t*t)
        wall=lo*min(w(t0),w(t1))/2
        for n,d in [((c,-s),S0-wall),((-c,s),-wall),((s,c),S0-wall),((-s,-c),-wall)]:poly=clip(poly,n,d)
        polys=[poly] if poly else []
        for j in range(12):
            if j in ids:continue
            polys=[piece for poly in polys for piece in subtract(poly,uv[j,0]-h,uv[j,0]+h,uv[j,1]-h,uv[j,1]+h)]
        for hull in other_hulls:
            hu=hull@np.array([[c,-s],[s,c]])
            forbidden=convex_hull([(x+dx*h,y+dy*h) for x,y in hu for dx,dy in [(-1,-1),(-1,1),(1,-1),(1,1)]])
            # Convexify each original component separately. This weakens the
            # enclosure safely and avoids fragment growth at curved hulls.
            nxt=[]
            for poly in polys:
                pieces=subtract_convex(poly,forbidden)
                if pieces:nxt.append(convex_hull([p for piece in pieces for p in piece]))
            polys=nxt
        for poly in polys:
            xy=[(c*x-s*y,s*x+c*y) for x,y in poly]
            ans.append({'k':k,'t':t,'dt':dt,'c':c,'s':s,'poly':xy})
    return ans

def compatibility(poses):
    n=len(poses);V=max(len(p['poly']) for p in poses)
    polys=np.array([p['poly']+[p['poly'][0]]*(V-len(p['poly'])) for p in poses])
    c=np.array([p['c'] for p in poses]);s=np.array([p['s'] for p in poses]);dt=np.array([p['dt'] for p in poses])
    angle=2*np.arctan([p['t'] for p in poses]);da=2*dt
    delta=angle[None,:]-angle[:,None]
    # Distance of the interval of relative angles from multiples of pi/2.
    d=np.abs((delta+np.pi/4)%(np.pi/2)-np.pi/4)
    lower=np.maximum(0,d-da[:,None]-da[None,:]);upper=np.minimum(np.pi/4,d+da[:,None]+da[None,:])
    w=np.minimum(np.cos(lower)+np.sin(lower),np.cos(upper)+np.sin(upper))
    radius=float(A_LO)*(1+w)/2
    directed=np.zeros((n,n),bool)
    for i,p in enumerate(poses):
        u=np.array([p['c'],p['s']]);v=np.array([-p['s'],p['c']])
        a=polys@u;b=polys@v
        amin=a.min(axis=1);amax=a.max(axis=1);bmin=b.min(axis=1);bmax=b.max(axis=1)
        mu=np.maximum(abs(amax-amin[i]),abs(amin-amax[i]))
        mv=np.maximum(abs(bmax-bmin[i]),abs(bmin-bmax[i]))
        eu=2*p['dt']*mv+2*p['dt']**2*mu
        ev=2*p['dt']*mu+2*p['dt']**2*mv
        directed[i]=(mu+eu>=radius[i]-1e-10)|(mv+ev>=radius[i]-1e-10)
    return directed|directed.T

def reduce_domains(dom, adj):
    changed=True
    while changed:
        changed=False
        for i in range(len(dom)):
            if not dom[i]:return False
            rem=0
            b=dom[i]
            while b:
                bit=b&-b;b-=bit;v=bit.bit_length()-1
                if any(j!=i and not(adj[v]&d) for j,d in enumerate(dom)):rem|=bit
            if rem:dom[i]&=~rem;changed=True
    return all(dom)

def solve(dom,adj,limit):
    nodes=0; witness=None; stopped=False
    def dfs(d):
        nonlocal nodes,witness,stopped
        nodes+=1
        if nodes>limit:stopped=True;return False
        if any(not x for x in d):return False
        opts=[(x.bit_count(),i) for i,x in enumerate(d) if x.bit_count()>1]
        if not opts:witness=[x.bit_length()-1 for x in d];return True
        _,i=min(opts);b=d[i]
        while b:
            bit=b&-b;b-=bit;v=bit.bit_length()-1
            nd=[x&adj[v] if j!=i else bit for j,x in enumerate(d)]
            if dfs(nd):return True
            if stopped:return False
        return False
    dfs(dom)
    return {'nodes':nodes,'stopped':stopped,'witness':witness}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--bins',type=int,default=64);ap.add_argument('--case',type=int,default=-1);ap.add_argument('--limit',type=int,default=1000000);ap.add_argument('--hulls')
    args=ap.parse_args();cases,_=all_cases();out=Path(__file__).parent/'exploration';out.mkdir(exist_ok=True)
    for ci,case in enumerate(cases):
        if args.case>=0 and ci!=args.case:continue
        start=time.time(); gs=groups(case);poses=[];dom=[];hs=None;limits=None
        if args.hulls:
            data=json.loads(Path(args.hulls).read_text());assert data['case']==ci
            hdata=data['history'][-1]['hulls'] if 'history' in data else data['hulls']
            hs={tuple(g):[tuple(map(float,p)) for p in h] for g,h in zip(data['groups'],hdata)}
            if data.get('symmetry_restricted'):limits={SYMMETRY_OWNER[ci]:5/12}
        for g in gs:
            ps=pose_cover(g,args.bins,gs,hs,limits);off=len(poses);poses.extend(ps);dom.append(((1<<len(ps))-1)<<off)
        print('CASE',ci,case,'poses',[d.bit_count() for d in dom],flush=True)
        if not all(dom):result={'witness':None,'nodes':0,'stopped':False}
        else:
            compat=compatibility(poses)
            adj=[int.from_bytes(np.packbits(row,bitorder='little').tobytes(),'little') for row in compat]
            reduced=reduce_domains(dom,adj)
            print('after AC',[d.bit_count() for d in dom],flush=True)
            result=solve(dom,adj,args.limit) if reduced else {'witness':None,'nodes':0,'stopped':False}
        result.update(case=case,index=ci,bins=args.bins,seconds=time.time()-start,domains=[d.bit_count() for d in dom],scope='FLOATING EXPLORATION ONLY')
        if result['witness'] is not None:result['witness_poses']=[poses[i] for i in result['witness']]
        (out/f'case-{ci}-N{args.bins}.json').write_text(json.dumps(result,indent=2))
        print({k:v for k,v in result.items() if k not in ['witness_poses']},flush=True)

if __name__=='__main__':main()
