"""Exact coarse center/angle bounds sufficient for the corner-normalization lemma."""
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import json,hashlib,time
from marker_cases import S,A_LO,A_HI,all_cases,groups
from forced_markers import hull
from exact_corner_normalization import task,direction,SOURCE

def main():
 start=time.time();raw=SOURCE.read_bytes();d=json.loads(raw);N=d['bins'];assert d['case']==6 and N==96 and d['branch']==[0,30,40] and d['base'] is None
 gs=groups(all_cases()[0][6]);hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,d['history'][-1]['hulls'])}
 tasks=[(g,N,gs,hs,{gs[0]:F(5,12)},(30,40) if i==0 else None) for i,g in enumerate(gs)]
 with ProcessPoolExecutor(max_workers=2) as pool:owners=list(pool.map(task,tasks))
 records=[]
 for own,poses in enumerate(owners):
  xy=[p for q in poses for p in q['poly']];lo=[min(p[j] for p in xy) for j in [0,1]];hi=[max(p[j] for p in xy) for j in [0,1]]
  if own==4:
   assert F(1,2)<=lo[0]<=hi[0]<=F(71,100)
   assert S-F(71,100)<=lo[1]<=hi[1]<=S-F(1,2)
   rule='C3 center x in [1/2,71/100], distance to top in [1/2,71/100]'
  elif own==10:
   assert F(121,100)<=lo[0]<=hi[0]<=F(149,100)
   assert S-F(77,50)<=lo[1]<=hi[1]<=S-F(5,4)
   for p in poses:
    assert 0<=p['k']<N
    for k in [p['k'],p['k']+1]:
     c,s=direction(F(k,N));assert c>=0 and s>=0 and c+s>=F(13,10)
   rule='I3 center x in [121/100,149/100], distance to top in [5/4,77/50], cos(theta)+sin(theta)>=13/10'
  else:
   assert lo[0]>=F(43,25) or hi[1]<=F(54,25),(own,lo,hi)
   rule='center x >= 43/25' if lo[0]>=F(43,25) else 'center y <= 54/25'
  records.append({'owner':own,'pose_count':len(poses),'center_min':list(map(str,lo)),'center_max':list(map(str,hi)),'rule':rule})
 # Exact constants in the human-readable geometric lemma.
 assert A_HI*A_HI/2<F(71,100)**2
 assert F(43,25)-F(71,100)>A_HI
 assert F(54,25)+F(71,100)<S-A_HI
 assert F(26,25)-F(1,2)*F(2,25)==1<A_LO
 assert 1-F(2,25)**2>F(249,250)**2
 assert F(249,250)*F(13,10)-F(2,25)>F(6,5)
 assert F(11,10)>F(26,25)
 sources=[SOURCE,Path(__file__),Path('exact_corner_normalization.py'),Path('exact_arc_hulls.py'),Path('exact_poses.py'),Path('forced_markers.py'),Path('marker_cases.py')]
 receipt={'verdict':'VERIFIED coarse bounds for corner normalization, conditional on journal hulls','hypothesis_journal':str(SOURCE),'hypothesis_sha256':hashlib.sha256(raw).hexdigest(),'records':records,'scope':'Exact finite enclosure checks. The geometric replacement lemma and completed ancestry supply the normalization conclusion.','source_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'seconds':time.time()-start}
 Path('corner-boxes-conditional.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['verdict'],len(records),'owners',time.time()-start,flush=True)
if __name__=='__main__':main()
