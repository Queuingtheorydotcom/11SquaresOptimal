"""Rational replay of compulsory-region propagation with arc consistency.

The only numerical heuristic retains extra compatibility edges; it cannot
justify a deletion. All deleted edges are checked with Fraction arithmetic.
Default operation replays the entire base ancestry as well as the arc journal.
"""
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse,hashlib,json,subprocess,sys,time
from marker_cases import A_LO,SYMMETRY_OWNER,all_cases,groups
from forced_markers import owned_points,hull
from exact_poses import pose_bin,contains

def make_owner(args):
    g,N,gs,hs,limits,branch=args;out=[]
    for k in range(N):
        if branch and not branch[0]<=k<branch[1]:continue
        c,s,h,polys=pose_bin(g,N,k,gs,hs,limits)
        for p in polys:
            out.append({'k':k,'c':c,'s':s,'poly':p,
                        'own':(min(x for x,y in p),max(x for x,y in p),
                               min(y for x,y in p),max(y for x,y in p))})
    return out

class Compatibility:
    def __init__(self,poses,N):
        self.poses=poses;self.h=A_LO/(2*(1+F(1,N)))
        self.axes={p['k']:(p['c'],p['s']) for p in poses}
        self.ranges={};self.answers={};self.rotation={};self.exact_edges=0
        for i,p in enumerate(poses):
            self.ranges[i,p['k']]=p['own']
            p['floatpoly']=[tuple(map(float,q)) for q in p['poly']]

    def relative(self,a,b):
        key=(a,b)
        if key not in self.rotation:
            c,s=self.axes[a];C,T=self.axes[b]
            d=c*C+s*T;e=-s*C+c*T
            self.rotation[key]=(d,e,self.h*(1+abs(d)+abs(e)))
        return self.rotation[key]

    def project(self,i,k):
        key=(i,k)
        if key not in self.ranges:
            p=self.poses[i];d,e,_=self.relative(p['k'],k)
            x=[d*u+e*v for u,v in p['poly']]
            y=[-e*u+d*v for u,v in p['poly']]
            self.ranges[key]=(min(x),max(x),min(y),max(y))
        return self.ranges[key]

    def heuristic_compatible(self,i,j):
        # This heuristic only adds edges, so no rounding claim is needed.
        for a,b in ((i,j),(j,i)):
            p=self.poses[a];q=self.poses[b]
            d,e,r=map(float,self.relative(q['k'],p['k']))
            xy=q['floatpoly'];x=[d*u+e*v for u,v in xy];y=[-e*u+d*v for u,v in xy]
            a0,a1,b0,b1=map(float,p['own'])
            if max(abs(max(x)-a0),abs(min(x)-a1),abs(max(y)-b0),abs(min(y)-b1))>=r-1e-9:return True
        return False

    def compatible(self,i,j):
        key=(min(i,j),max(i,j))
        if key in self.answers:return self.answers[key]
        if self.heuristic_compatible(i,j):self.answers[key]=True;return True
        for a,b in ((i,j),(j,i)):
            p=self.poses[a];q=self.poses[b]
            _,_,r=self.relative(p['k'],q['k'])
            a0,a1,b0,b1=p['own'];x0,x1,y0,y1=self.project(b,p['k'])
            if max(abs(x1-a0),abs(x0-a1),abs(y1-b0),abs(y0-b1))>=r:
                self.answers[key]=True;return True
        self.answers[key]=False;self.exact_edges+=1;return False

def reduce_domains(dom,compat):
    deleted=[];witness={};changed=True
    while changed:
        changed=False
        for i,d in enumerate(dom):
            for p in sorted(d):
                for j,other in enumerate(dom):
                    if j==i:continue
                    old=witness.get((p,j))
                    if old in other:continue
                    found=next((q for q in sorted(other) if compat.compatible(p,q)),None)
                    if found is None:
                        d.remove(p);deleted.append((i,p,j));changed=True;break
                    witness[p,j]=found
            if not d:return False,deleted
    return True,deleted

def main():
    ap=argparse.ArgumentParser();ap.add_argument('journal');ap.add_argument('--jobs',type=int,default=1);ap.add_argument('--skip-base',action='store_true',help='Require an already completed exact base replay with the matching SHA256.')
    ap.add_argument('--assume-base',action='store_true',help='Check only the implication from the stated base hulls; never issue a case-exclusion verdict.');args=ap.parse_args()
    path=Path(args.journal);raw=path.read_bytes();data=json.loads(raw);digest=hashlib.sha256(raw).hexdigest()
    N=data['bins'];gs=groups(all_cases()[0][data['case']]);assert [list(g) for g in gs]==data['groups']
    hs={g:hull(owned_points(g)) for g in gs}
    assert not args.assume_base or data.get('base'),'An assumed-base implication needs a stated base.'
    if data.get('base'):
        base=Path(data['base']);br=base.read_bytes();bh=hashlib.sha256(br).hexdigest();assert bh==data['base_sha256']
        bd=json.loads(br);assert bd['case']==data['case']
        assert base.resolve()!=path.resolve(),'A journal cannot be its own ancestor.'
        if bd.get('branch'):
            old=bd['branch'];new=data.get('branch')
            assert new and old[0]==new[0] and F(old[1],bd['bins'])<=F(new[1],N)<=F(new[2],N)<=F(old[2],bd['bins'])
        base_checker='exact_arc_hulls.py' if 'terminal' in bd and 'base' in bd else 'exact_poses.py'
        if not args.skip_base and not args.assume_base:subprocess.run([sys.executable,str(Path(__file__).with_name(base_checker)),str(base),'--jobs',str(args.jobs)],check=True)
        if not args.assume_base:
            receipt=json.loads(Path(str(base)+'.verified-prefix.json').read_text())
            assert receipt['journal_sha256']==bh and receipt['completed_round']==len(bd['history'])-1
        assert not bd.get('symmetry_restricted') or data.get('symmetry_restricted')
        hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,bd['history'][-1]['hulls'])}
    limits={SYMMETRY_OWNER[data['case']]:F(5,12)} if data.get('symmetry_restricted') else None
    branch=data.get('branch');checks=[];start=time.time()
    entries=data['history']+([None] if data.get('terminal') else [])
    for rnd,entry in enumerate(entries):
        tasks=[(g,N,gs,hs,limits,(branch[1],branch[2]) if branch and i==branch[0] else None) for i,g in enumerate(gs)]
        if args.jobs>1:
            with ProcessPoolExecutor(max_workers=args.jobs) as pool:owner_poses=list(pool.map(make_owner,tasks))
        else:owner_poses=[make_owner(t) for t in tasks]
        poses=[];dom=[]
        for ps in owner_poses:
            dom.append(set(range(len(poses),len(poses)+len(ps))));poses+=ps
        initial=[len(d) for d in dom];print('rational covers',rnd,initial,flush=True)
        region_checks=[]
        for sweep in range(data.get('pair_regions',0)):
            if not all(dom):break
            from exact_pair_regions import refine
            poses,dom,rr=refine(poses,dom,N,args.jobs);region_checks.append(rr)
            print('rational center pruning',rnd,sweep,[len(d) for d in dom],flush=True)
        cc=Compatibility(poses,N);ok,deletions=reduce_domains(dom,cc)
        record={'round':rnd,'initial':initial,'active':[len(d) for d in dom], 'deleted_poses':len(deletions),'exact_incompatible_edges':cc.exact_edges,'seconds':time.time()-start}
        if region_checks:record['center_pruning']=region_checks
        checks.append(record);print({k:v for k,v in record.items() if k!='center_pruning'},flush=True)
        if not ok:
            verdict={'verdict':'VERIFIED CONDITIONAL EXCLUSION' if branch else 'VERIFIED CASE EXCLUSION','case':data['case'],'branch':branch,'journal_sha256':digest,'base_sha256':data.get('base_sha256'),'checks':checks}
            suffix='.verified-exclusion.json'
            if args.assume_base:
                verdict['verdict']='VERIFIED IMPLICATION FROM ASSUMED BASE';verdict['base_assumed']=True;suffix='.verified-implication.json'
            Path(str(path)+suffix).write_text(json.dumps(verdict,indent=2));print(verdict['verdict'],data['case'],flush=True);return
        assert entry is not None,'Terminal exclusion did not replay'
        new={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,entry['hulls'])}
        total=0
        for g,d in zip(gs,dom):
            added=[p for p in new[g] if not contains(hs[g],p)];total+=len(added)
            for i in d:
                p=poses[i];c=p['c'];s=p['s'];h=cc.h
                x0,x1,y0,y1=p['own']
                for q in added:
                    x=c*q[0]+s*q[1];y=-s*q[0]+c*q[1]
                    assert x1-h<=x<=x0+h and y1-h<=y<=y0+h,('uncertified point',rnd,g,p['k'],tuple(map(str,q)))
        record['checked_new_vertices']=total;hs=new
        suffix='.verified-conditional-prefix.json' if args.assume_base else '.verified-prefix.json'
        Path(str(path)+suffix).write_text(json.dumps({'journal_sha256':digest,'base_sha256':data.get('base_sha256'),'base_assumed':args.assume_base,'completed_round':rnd,'checks':checks,'scope':'Compulsory region implications only, conditional on the stated branch and base ancestry.'},indent=2))
    print('VERIFIED implications from assumed base; no ancestry asserted' if args.assume_base else 'VERIFIED compulsory hull ancestry; no case exclusion asserted',flush=True)

if __name__=='__main__':main()
