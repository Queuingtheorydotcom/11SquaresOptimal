# Center pruning using actual separating edges

Fix an angle bin k for square A and a pose j for another square B.
Let T(k,j) be the rational lower bound for their support-radius sum,
minus 3/N^2, defined in FIXED_CONSTRAINTS_AND_EDGE_ARCS.md.
For each of the two edge normals at both endpoints of both angle bins,
write m_j(n), M_j(n) for the extrema of n dot center(B) over pose j.

If a candidate center z of A satisfies, for all these endpoint normals,

    M_j(n) - T(k,j) < n dot z < m_j(n) + T(k,j),

then no actual edge of either square can separate the pair. Indeed every
endpoint projection of the difference of actual centers is less than T;
the endpoint chord error is at most 3/N^2, whereas the actual support sum
is strictly greater than the lower bound using A_LO, since a>A_LO.
The same conclusion therefore holds with non-strict displayed inequalities.

Intersect all these strips, and then intersect the resulting forbidden
sets over every pose j of B. Every center in the resulting polygon overlaps
B for every allowed choice of B's pose. Remove this polygon from A's center
region and convexify what remains. This preserves every feasible packing.
Convexification can retain extra points and cannot remove a feasible point.

The implementation aggregates parallel strip bounds using exact rational
minima and maxima. Normals with the same endpoint index are combined before
clipping. A bounding box [-10,10]^2 in A's midpoint coordinates contains
every feasible center strictly, because the physical container has side
S=3.88. A floating calculation may skip a proposed pruning operation; every
pruning that is applied by the exact checker is recomputed with Fractions.

Compared with the earlier inner-square pruning, this uses the actual edge
directions and a quadratic angular chord error. It makes no assumption
about which contacts the final packing has.
