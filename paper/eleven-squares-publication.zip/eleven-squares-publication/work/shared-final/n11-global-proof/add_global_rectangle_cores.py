"""Add rational enclosing-box cores to an ancestry-checked global pose cover."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
from spatial_branch_seed import validate_root
from exact_persistent_journal import bounds
from exact_rectangle_cores import rectangle_cores
from forced_markers import hull
from exact_poses import contains
from corner_obstruction_seed import sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('seed');ap.add_argument('output');ap.add_argument('--point',nargs=3,action='append',default=[]);args=ap.parse_args()
    d=validate_root(args.seed);gs=[tuple(g) for g in d['groups']]
    hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,d['hulls'])}
    poses=[];dom=[]
    for owner in d['owners']:
        ids=set()
        for p in owner:
            poly=[tuple(map(F,q)) for q in p['poly']];ids.add(len(poses))
            poses.append({'k':p['k'],'c':F(p['c']),'s':F(p['s']),'poly':poly,'own':bounds(poly)})
        dom.append(ids)
    hs,records=rectangle_cores(poses,dom,gs,hs,d['bins'])
    for own,x,y in args.point:
        assert contains(hs[gs[int(own)]],(F(x),F(y))),(own,x,y)
    sources=[Path(args.seed),Path(__file__),Path('exact_rectangle_cores.py'),Path('RECTANGLE_CORES.md'),Path('spatial_branch_seed.py'),Path('exact_poses.py')]
    out={**d,'hulls':[[[str(x),str(y)] for x,y in hs[g]] for g in gs],
         'rectangle_core_parent':args.seed,'rectangle_core_records':records,
         'verified_points':args.point,'source_hashes':{str(p):sha(p) for p in sources},
         'scope':'Global necessary pose cover augmented by proved compulsory rectangles; global optimality remains unproved.'}
    Path(args.output).write_text(json.dumps(out));print('VERIFIED GLOBAL RECTANGLE CORES; requested points:',args.point)
if __name__=='__main__':main()
