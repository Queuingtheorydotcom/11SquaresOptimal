# Compulsory rectangles from enclosing rectangles

Let Q be a square of side a contained in the axis-aligned rectangle
\([L,R]\times[B,T]\), with \(R-L\le2a\) and \(T-B\le2a\). Then

\[
 \boxed{[R-a,L+a]\times[T-a,B+a]\subseteq Q.}
\]

This statement concerns every orientation of Q. The core rectangle may
degenerate to a segment or a point.

To prove it, write edge vectors \((c,s),(-s,c)\) with c,s>=0 and
c²+s²=1, and put w=c+s. Containment places the center (X,Y) in

\[
 L+aw/2\le X\le R-aw/2,\qquad
 B+aw/2\le Y\le T-aw/2.
\]

For any point (x,y) of the claimed core,

\[
 |x-X|,|y-Y|\le a(1-w/2).
\]

Each of its two absolute edge coordinates is therefore at most

\[
 a(c+s)(1-w/2)=a(w-w^2/2)\le a/2,
\]

the last inequality being \((w-1)^2\ge0\). This proves containment.

## Use with the fixed side interval

An actual packing square has side a>A_LO. Its concentric subsquare of side
A_LO has the same center and orientation and lies strictly inside the actual
square. Enclose this subsquare using the current exact pose cover. The lemma
then supplies a rational rectangle of compulsory points for the actual square.
This can include the line y=A_LO for a bottom square, or x=S-A_LO for a
right-side square. Such points can be much closer to a true contact than the
inner reference squares used by the ordinary angle-bin deductions.

For each angle bin at resolution N, the concentric A_LO subsquare is inside
the reference square with midpoint orientation and half-side
H=A_LO(1+1/N)/2. Its axis-aligned support radius is H(c+s). Maximizing this
outer box over all surviving poses yields an enclosing rectangle. Intersect
that rectangle with the physical container [0,S]² before applying the lemma.
All these operations use rational arithmetic in the exact kernel.

The core vertices are compulsory by this lemma, even if they are not in every
smaller inner reference square. A verifier must therefore incorporate the
lemma explicitly; treating their numerical discovery as an ordinary verified
inner-reference deduction would be invalid.

This lemma also gives a simpler route to the proposed lower-right cap point
when a sufficiently narrow enclosing rectangle has been proved. The separate
sharp two-square strip theorem remains valid, but is not necessary for that
particular application.
