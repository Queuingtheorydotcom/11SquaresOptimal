"""Exact replay of angle-dependent center regions retained between sweeps.

All cuts use rational arithmetic. Outward polygon rounding is proved by
support maxima. Existing exact pose, overlap, and center-cut routines are
reused. This program does not infer feasibility from surviving domains.
"""
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse,hashlib,json,subprocess,sys,time
from marker_cases import A_LO,A_HI,all_cases,groups,SYMMETRY_OWNER
from forced_markers import owned_points,hull
from exact_poses import contains,clip,subtract_convex,area2
from exact_arc_hulls import make_owner,Compatibility,reduce_domains
from exact_pair_regions_fast import refine

NORMALS=[(1,0),(2,1),(1,1),(1,2),(0,1),(-1,2),(-1,1),(-2,1),(-1,0),(-2,-1),(-1,-1),(-1,-2),(0,-1),(1,-2),(1,-1),(2,-1)]

def bounds(poly):
    return (min(x for x,y in poly),max(x for x,y in poly),min(y for x,y in poly),max(y for x,y in poly))

def cut_and_round(poses,dom,gs,hs,N,den):
    h=A_LO/(2*(1+F(1,N)));H=A_HI*(1+F(1,N))/2
    projections={};forbidden={};out=[];domains=[set() for g in gs]
    for owner,(g,d) in enumerate(zip(gs,dom)):
        for i in sorted(d):
            p=poses[i];k=p['k'];c=p['c'];s=p['s'];poly=p['poly']
            for other in gs:
                key=(k,other)
                if key not in projections:projections[key]=[(c*x+s*y,-s*x+c*y) for x,y in hs[other]]
            xy=projections[k,g];x0,x1,y0,y1=bounds(xy)
            for n,v in [((1,0),x0+H),((-1,0),H-x1),((0,1),y0+H),((0,-1),H-y1)]:poly=clip(poly,n,v)
            for other in gs:
                if other==g or not poly:continue
                key=(k,other)
                if key not in forbidden:forbidden[key]=hull([(x+dx*h,y+dy*h) for x,y in projections[key] for dx,dy in [(-1,-1),(-1,1),(1,-1),(1,1)]])
                poly=subtract_convex(poly,forbidden[key])
            if area2(poly)<=0:continue
            # Every genuine center has UV coordinates strictly between -8
            # and 8, since the physical container has side 3.88.
            rounded=[(F(-8),F(-8)),(F(8),F(-8)),(F(8),F(8)),(F(-8),F(8))]
            for nx,ny in NORMALS:
                support=max(nx*x+ny*y for x,y in poly)
                ceil=-((-support*den).__floor__())
                upper=F(ceil+1,den)
                assert upper>support
                rounded=clip(rounded,(nx,ny),upper)
            assert area2(rounded)>0
            domains[owner].add(len(out))
            out.append({'k':k,'c':c,'s':s,'poly':rounded,'own':bounds(rounded)})
    return out,domains

def physical_cuts(data):
    cuts=data.get('cuts',[])+([data['branch']] if data.get('branch') else [])
    out={}
    for owner,lo,hi in cuts:
        a,b=F(lo,data['bins']),F(hi,data['bins']);assert 0<=a<b<=1
        if owner in out:a=max(a,out[owner][0]);b=min(b,out[owner][1])
        assert a<b;out[owner]=(a,b)
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('journal');ap.add_argument('--jobs',type=int,default=1)
    ap.add_argument('--assume-base',action='store_true');args=ap.parse_args()
    path=Path(args.journal);raw=path.read_bytes();data=json.loads(raw);digest=hashlib.sha256(raw).hexdigest()
    assert data['method']=='persistent';N=data['bins'];den=data['rounding_denominator'];assert N>0 and isinstance(den,int) and den>0
    gs=groups(all_cases()[0][data['case']]);assert data['groups']==[list(g) for g in gs]
    hs={g:hull(owned_points(g)) for g in gs};cuts=physical_cuts(data)
    assert all(0<=i<len(gs) for i in cuts)
    assert not args.assume_base or data.get('base')
    if data.get('base'):
        bp=Path(data['base']);br=bp.read_bytes();base=json.loads(br);bh=hashlib.sha256(br).hexdigest()
        assert bp.resolve()!=path.resolve() and bh==data['base_sha256'] and base['case']==data['case']
        for i,(lo,hi) in physical_cuts(base).items():assert i in cuts and lo<=cuts[i][0]<=cuts[i][1]<=hi
        assert not base.get('symmetry_restricted') or data.get('symmetry_restricted')
        if not args.assume_base:
            checker='exact_persistent_journal.py' if base.get('method')=='persistent' else ('exact_arc_hulls.py' if 'base' in base else 'exact_poses.py')
            subprocess.run([sys.executable,str(Path(__file__).with_name(checker)),str(bp),'--jobs',str(args.jobs)],check=True)
            receipt=json.loads(Path(str(bp)+'.verified-prefix.json').read_text())
            assert receipt['journal_sha256']==bh and receipt['completed_round']==len(base['history'])-1 and not receipt.get('base_assumed')
        hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,base['history'][-1]['hulls'])}
    if data.get('corner_markers'):
        from corner_markers import extend
        hs=extend(gs,hs)
    limits={SYMMETRY_OWNER[data['case']]:F(5,12)} if data.get('symmetry_restricted') else None
    tasks=[]
    for i,g in enumerate(gs):
        branch=None
        if i in cuts:
            lo,hi=cuts[i];assert (lo*N).denominator==(hi*N).denominator==1
            branch=(int(lo*N),int(hi*N))
        tasks.append((g,N,gs,hs,limits,branch))
    if args.jobs>1:
        with ProcessPoolExecutor(max_workers=args.jobs) as pool:owners=list(pool.map(make_owner,tasks))
    else:owners=[make_owner(t) for t in tasks]
    poses=[];dom=[]
    for pp in owners:dom.append(set(range(len(poses),len(poses)+len(pp))));poses+=pp
    checks=[];start=time.time();entries=data['history']+([None] if data.get('terminal') else [])
    for rnd,entry in enumerate(entries):
        initial=[len(d) for d in dom];print('persistent exact start',rnd,initial,flush=True)
        region=[]
        if all(dom):poses,dom,region=refine(poses,dom,N,args.jobs)
        cc=Compatibility(poses,N);ok,deletions=reduce_domains(dom,cc)
        record={'round':rnd,'initial':initial,'active':[len(d) for d in dom],'deleted_poses':len(deletions),'exact_incompatible_edges':cc.exact_edges,'seconds':time.time()-start,'center_pruning':region}
        checks.append(record)
        if not ok:
            verdict={'verdict':'VERIFIED PERSISTENT CONDITIONAL EXCLUSION','case':data['case'],'cuts':data['cuts'],'journal_sha256':digest,'base_sha256':data.get('base_sha256'),'base_assumed':args.assume_base,'checks':checks}
            suffix='.verified-exclusion.json'
            if args.assume_base:verdict['verdict']='VERIFIED PERSISTENT IMPLICATION FROM ASSUMED BASE';suffix='.verified-implication.json'
            Path(str(path)+suffix).write_text(json.dumps(verdict,indent=2));print(verdict['verdict'],flush=True);return
        assert entry is not None,'Floating terminal exclusion did not replay'
        new={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,entry['hulls'])};total=0
        for g,d in zip(gs,dom):
            added=[p for p in new[g] if not contains(hs[g],p)];total+=len(added)
            for i in d:
                p=poses[i];x0,x1,y0,y1=p['own'];c=p['c'];s=p['s']
                for X,Y in added:
                    x=c*X+s*Y;y=-s*X+c*Y
                    assert x1-cc.h<=x<=x0+cc.h and y1-cc.h<=y<=y0+cc.h,('uncertified vertex',rnd,g,p['k'],str(X),str(Y))
        hs=new;poses,dom=cut_and_round(poses,dom,gs,hs,N,den)
        record['checked_new_vertices']=total;record['after_hulls']=[len(d) for d in dom]
        suffix='.verified-conditional-prefix.json' if args.assume_base else '.verified-prefix.json'
        Path(str(path)+suffix).write_text(json.dumps({'method':'persistent','journal_sha256':digest,'base_sha256':data.get('base_sha256'),'base_assumed':args.assume_base,'completed_round':rnd,'checks':checks,'scope':'Verified implications on the stated cuts; no global optimality claim.'},indent=2))
        print('persistent exact checked',rnd,record['after_hulls'],'new vertices',total,'seconds',round(time.time()-start,1),flush=True)
    print('VERIFIED PERSISTENT PREFIX',flush=True)

if __name__=='__main__':main()
