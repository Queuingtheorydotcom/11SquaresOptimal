"""Certify the geometric premise of the two-square support theorem globally."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
from spatial_branch_seed import validate_root
from marker_cases import S,A_LO,A_HI
from corner_obstruction_seed import sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('seed');ap.add_argument('output');args=ap.parse_args()
    d=validate_root(args.seed);N=d['bins'];H=A_HI*(1+F(1,N))/2;minimum=S-3*A_LO/2
    checks=[]
    for own in [2,6]:
        left=S
        for p in d['owners'][own]:
            c,s=F(p['c']),F(p['s']);xy=[c*F(u)-s*F(v) for u,v in p['poly']]
            left=min(left,min(xy)-H*(c+s))
        assert left>=minimum,(own,str(left),str(minimum))
        checks.append({'owner':own,'entire_actual_square_left_bound':str(left),'required_left_bound':str(minimum),'positive_margin':str(left-minimum)})
    theorem=Path('strip-support-identities-verification.json');r=json.loads(theorem.read_text())
    for p,h in r['source_hashes'].items():assert sha(p)==h,p
    sources=[Path(args.seed),Path(__file__),Path('spatial_branch_seed.py'),Path('STRIP_SUPPORT_DOMINATION.md'),theorem]
    out={'verdict':'VERIFIED global lower-right two-square support domination after normalization','ancestry_discharged':True,'owners':[2,6],'checks':checks,'inward_coordinates':'U=y,V=S-x','strip':'0<=V<=3a/2, U>=0','dominated_rectangle':'[S-a,S] x [0,2a]','normal_cone':'(-v,u), u>=0,v>=0','source_hashes':{str(p):sha(p) for p in sources},'scope':'Every common separating line in this cone is preserved by the canonical-column replacement. Existence of such common separators for all other squares, and global optimality, remain unproved.'}
    Path(args.output).write_text(json.dumps(out,indent=2)+'\n');print(out['verdict']);print([(q['owner'],float(F(q['positive_margin']))) for q in checks])
if __name__=='__main__':main()
