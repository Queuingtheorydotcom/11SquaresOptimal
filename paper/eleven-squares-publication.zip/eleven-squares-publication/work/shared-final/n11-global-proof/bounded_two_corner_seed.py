"""Add proved global center halfplanes to a two-corner seed."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json
from spatial_branch_seed import validate_root
from exact_poses import clip,area2
from corner_obstruction_seed import sha

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='exploration/two-corner-global-certified-seed.json');ap.add_argument('--bounds',required=True);ap.add_argument('--output',required=True);args=ap.parse_args();d=validate_root(args.root);r=json.loads(Path(args.bounds).read_text());assert r['verdict']=='VERIFIED necessary spatial bounds after two-corner normalization' and r['ancestry_discharged'] and r['normalized_corners']==[3,4]
 for p,h in r['source_hashes'].items():assert sha(p)==h,p
 owners=[]
 for own,ps in enumerate(d['owners']):
  out=[]
  for p in ps:
   c,s=F(p['c']),F(p['s']);poly=[tuple(map(F,z)) for z in p['poly']]
   for b in r['necessary_halfplanes']:
    if b['owner']!=own:continue
    nx,ny=map(F,b['normal']);poly=clip(poly,(nx*c+ny*s,-nx*s+ny*c),F(b['upper']))
   if area2(poly)>0:out.append({**p,'poly':[[str(x),str(y)] for x,y in poly]})
  owners.append(out)
 sources=[Path(args.root),Path(args.bounds),Path(__file__),Path('spatial_branch_seed.py'),Path('exact_poses.py')]
 out={**d,'owners':owners,'global_spatial_bounds':args.bounds,'unbounded_root':args.root,'source_hashes':{str(p):sha(p) for p in sources},'scope':'Exact necessary domains after two-corner normalization and proved center bounds; strict bounds are relaxed to closed halfplanes.'}
 Path(args.output).write_text(json.dumps(out));print([len(o) for o in owners],flush=True)
if __name__=='__main__':main()
