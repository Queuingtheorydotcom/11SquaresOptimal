# Compact separator proofs and an earlier virtual column

This note gives two new geometric compressions of the archived argument.
The first proves the virtual right column from the **seven-bound** pose
cover, before the additional C1-center bound `x > 3.1`. The second replaces
the 5,760 signed-axis checks for the second corner's I2 obstruction by a
short argument using two rectangles and two angular intervals.

`check_compact_envelopes.py` freshly verifies all stated envelope constants
against the two named archived pose covers, using exact rational arithmetic.
It also verifies the 18 scalar inequalities used below. It does **not**
replay the earlier deductions establishing those covers for every packing.
Thus these are replacements of downstream geometric arguments with exactly
identified earlier premises, not an independent proof of the entire problem.

All decimal constants below are terminating decimals and denote exact
rationals. The square side satisfies

    1 < a < 1.001,    S = 3.88.

The source has the stronger interval 4003/4000 < a < 25019/25000.

## 1. Two elementary lemmas

### A direction-dependent strip theorem

For a fixed r > 0 put

    alpha(r) = (r+1)/(sqrt(1+r^2)+1).

If two interior-disjoint unit squares are in x >= 0, 0 <= y <= H, and

    H <= 1 + alpha(r),

then their union has support at least 2r+1 in direction (r,1).

**Proof.** The already proved forced-point assertion puts p=(1,alpha) in
every square below the cap rx+y <= 2r+1. If the cap is strict, p is interior
to every genuinely rotated square. For an axis-aligned square, bottom <=
H-1 <= alpha < 1 <= top, left < 1 <= right. Therefore
p+epsilon(-1,+1) is interior for every sufficiently small positive epsilon.
A common epsilon for two squares contradicts interior-disjointness. This
uses exactly the original algebra; the uniform height 3/2 was unnecessarily
restrictive for a known supporting direction. No sharpness claim is made.

### Interpolation of lower support bounds through a cone

Let n0,n1 be unit vectors spanning an angle less than pi. If a vector z
satisfies n0.z >= d and n1.z >= d for d >= 0, then n.z >= d for every unit
vector n in their positive cone.

**Proof.** Write n = ((1-t)n0+t n1)/|(1-t)n0+t n1|, 0 <= t <= 1. The numerator
has scalar product at least d with z, and its norm is at most 1.

In particular, if every point p of P and every possible centre C of a
square R satisfy n_j.(C-p) >= d at the two endpoints, the same lower bound
holds for every intervening unit normal. When that normal is an edge
normal of R, d > a/2 proves strict separation of P and R along it.

## 2. The virtual right column follows from the seven-bound cover

Let P=C1, Q=W1, R=I2. The source is

    exploration/seven-spatial-bounds-certified-seed.json

Its spatial-bound premise is `spatial-bounds-v4-verification.json`, which
contains seven bounds, including x_C1 > 2.8. It does not contain x_C1 > 3.1.
The extraction uses its existing global pose cover, without conditioning
on intersection with the proposed column.

### The compact envelope

The centres satisfy:

| Square | x interval | y interval |
|---|---:|---:|
| R | [2.49, 2.63] | [2.34, 2.495] |
| Q | [3.23, 3.38] | [1.485, 1.62] |

Write the angle of R as theta. Write the angle of Q modulo a right angle
as phi, allowing small negative angles. Then

    2 atan(1/4) <= theta <= 2 atan(1/2),
    -2 atan(2/11) <= phi <= 2 atan(1/16).

Both complete squares P and Q lie in

    x >= S - 7a/4.

Finally, there are only two required support bounds:

| Unit normal n | n.C_R is at least | h_P(n) is at most |
|---|---:|---:|
| (-8/17,15/17) | 0.876 | -0.032 |
| (-4/5,3/5) | -0.648 | -1.153 |

These bounds include all points of P, not only its centre. The extraction
uses the conservative outer reference square for each source angle bin.
The smaller difference between the table's two columns is 0.505, exceeding
a/2 by more than 0.0045. Cone interpolation consequently gives

    h_P(nu_R) < ell_R(nu_R),    nu_R=(-sin(theta),cos(theta)).       (C1)

### Why Q and R must separate along nu_R

Put C_R-C_Q=(-X,Y). The rectangles give

    0.60 <= X <= 0.89,    0.72 <= Y <= 1.01.

For equal side-a squares, the sum of their projection radii along *any*
edge normal of either square is the same number

    rho = a/2 [1 + cos(theta-phi) + sin(theta-phi)].

The relative angle is between theta0-alpha and theta1+beta, where

    theta0=2 atan(1/4), theta1=2 atan(1/2),
    alpha=2 atan(1/16), beta=2 atan(2/11).

This interval is inside (0,pi/2). On that interval cos+sin is concave.
Its value at theta1+beta is exactly 31/25, because

    (cos(theta1+beta),sin(theta1+beta)) = (7/25,24/25),

and its value at theta0-alpha is greater than 31/25. Hence

    rho > 28/25 = 1.12.                                          (C2)

Along R's other edge normal e_R=(cos(theta),sin(theta)), the projection
-X cos(theta)+Y sin(theta) has absolute value at most 1.01. The reverse of
nu_R has negative projection. These axes cannot separate.

For Q, write its edge normals e_Q=(cos(phi),sin(phi)) and nu_Q=(-sin(phi),
cos(phi)). If phi >= 0, the absolute e_Q projection is at most 0.89. Its
nu_Q projection is at most

    0.89 sin(alpha)+1.01 cos(alpha) = 1.112957... < 1.12.

Here the upper bound is attained at alpha: differentiation, or the
positive scalar inequality 0.89 cos(alpha)-1.01 sin(alpha)>0, verifies
monotonicity throughout [0,alpha].

If phi=-u <= 0, the absolute nu_Q projection is at most 1.01. The other
projection is X cos(u)+Y sin(u). This is where the right container wall
matters. Containment of Q gives

    x_Q <= S - a/2 [cos(u)+sin(u)].

Using x_R >= 2.49, Y <= 1.01, and a > 1, we obtain

    X cos(u)+Y sin(u)
      <= F(u) := 1.39 cos(u)+1.01 sin(u)
                 - (1/2)cos(u)[cos(u)+sin(u)].

F is increasing on [0,beta]. Indeed, writing C=cos(beta)=117/125 and
T=sin(beta)=44/125, differentiation and cos(2u)<=cos(u) give

    F'(u) >= C(1.01-1/2) - T(1.39-C) = 0.317552 > 0.

The endpoint value is

    F(beta)=1.053776 < 1.12.

Thus neither normal of Q can separate the squares. The separating-axis
theorem forces the sole remaining possibility:

    h_Q(nu_R) <= ell_R(nu_R).                                    (C3)

All of this holds unconditionally on the stated global envelope. There is
no hypothesized intersection with the column and no pose-pair case split.

### Applying the stronger strip theorem

In inward coordinates U=y, V=S-x, the pair P,Q lies in a strip of width
7a/4. The desired normal nu_R corresponds to weights (cos(theta),sin(theta)),
so r=cot(theta) >= 3/4. The function alpha(r) is increasing, and

    1+alpha(3/4) = 16/9 > 7/4.

The direction-dependent strip theorem therefore gives, for
E=[S-a,S] x [0,2a],

    h_E(nu_R) <= max(h_P(nu_R),h_Q(nu_R)) <= ell_R(nu_R).

The virtual right column follows. This bypasses the additional x_C1>3.1
branch chain as a premise for this obstacle, the 5,852 conditioned signed
axis checks, and the 506 additional C1 checks.

### The necessary inequality needs no endpoint projection checks

For p=(S-a,2a), the coarse R rectangle and 1<a<1.001 give

    0.249 < p_x-x_R < 0.390,
    -0.495 < p_y-y_R < -0.338.

Since the two components have opposite signs,

    |e_R.(p-C_R)| < 0.495 < a/2,    nu_R.(p-C_R) < 0.

The corner p cannot be interior to R because R and E have disjoint
interiors. It is therefore below R's lower nu_R edge. Consequently

    -sin(theta)x_R + cos(theta)y_R
      >= -sin(theta)S + a[sin(theta)+2cos(theta)+1/2].

This replaces the original 1,056 endpoint strip checks as well.

## 3. The second corner: replace 5,760 signed checks by one short lemma

Here the premise remains the existing **interference-conditioned** cover

    exploration/inner-obstruction-certified-seed.json.

Thus this result simplifies the I2 separator argument, but does not remove
the independent W2 obstruction exclusion or the derivation of this cover.
Let P=C2 and Q=I2. The cover supplies:

| Centre | x interval | y interval |
|---|---:|---:|
| P | [2.89,3.38] | [2.90,3.38] |
| Q | [2.45,2.67] | [2.35,2.51] |

P's angle modulo a right angle lies in
[-2 atan(1/16), 2 atan(5/48)]. Q's angle lies in
[2 atan(3/32), 2 atan(19/32)].

**Claim.** Every interior-disjoint pair of squares satisfying these bounds
has an inward separator from P toward Q, meaning a normal with both
coordinates nonpositive.

Put C_Q-C_P=(-X,-Y), where

    0.22 <= X <= 0.93,    0.39 <= Y <= 1.03.

Along every edge normal, the sum of the two square radii is at least a>1.
It is therefore enough to exclude all mixed-sign edge normals.

For Q the mixed-sign projection is X sin(theta)-Y cos(theta). Monotonicity
in theta bounds its positive and negative parts by

    0.93 sin(theta_max)-0.39 cos(theta_max) < 0.630,
    1.03 cos(theta_min)-0.22 sin(theta_min) < 0.972.

For a negative folded angle phi of P, its mixed-sign projection has
absolute value at most max(0.93,1.03 sin(2 atan(1/16)))=0.93.

It remains to consider 0<=phi<=2 atan(5/48). Write c=cos(phi), s=sin(phi).
The positive mixed-sign projection sX-cY is at most 0.93. For the negative
one, the top wall gives y_P<=S-a(c+s)/2, and hence

    cY-sX <= f(phi):=1.53c-0.22s-c(c+s)/2.

Throughout this interval phi<pi/8, so

    f'(phi)=-1.53s-0.22c-[cos(2phi)-sin(2phi)]/2 < 0.

At phi0=2 atan(1/40), exact substitution gives f(phi0)<0.994<1. Thus
phi>=phi0 is excluded. If 0<=phi<phi0, then f(phi)<=f(0)=1.03, while the
relative angle to Q lies in

    [2 atan(3/32)-phi0, 2 atan(19/32)].

At both endpoints cos+sin is greater than 1.1, and concavity gives the
same bound throughout. The radius sum is consequently greater than
(1+1.1)/2=1.05>1.03. The remaining mixed-sign axis is excluded too.

Every remaining separating axis points inward. The corner-support lemma
therefore transfers it to the canonical C2 square [S-a,S]^2. This proves
the I2 part of the second-corner normalization using the compact envelope.

## 4. Limits and unsuccessful earlier extensions

* This does not prove the seven-bound envelope without computation. It
  compresses its downstream use and removes one later bound from the
  virtual-column argument. Whether a rebuilt global capture can now omit
  that branch chain completely requires further work.
* The preceding `five-bound-eight-core-rounds-certified-seed.json` does
  satisfy the wider strip condition, but the direct global endpoint
  separator from C1 to I2 fails at its upper I2 angle: the tested margin
  is approximately -0.0168011. This failure is a failure of that coarse
  sufficient criterion, not a counterexample to the packing theorem.
* The late row cover admits a similar elementary treatment, but a proof
  replacing its dependencies has not been completed here. Earlier bottom
  row covers allow a wide range of W0 centres, so the same simple envelope
  is not available automatically.
* Pairwise nonoverlap alone still cannot justify a virtual replacement.
  For example, P=[0,1]x[0,1], Q=[2,3]x[0,1], R=[1,2]x[0,1] have disjoint
  interiors, and P,Q dominate the support of E=[0,2]x[0,1] in every
  nonnegative direction, but R overlaps the interior of E. The common
  separator established above is indispensable.

The fresh result file reports exact extraction slacks and all scalar
margins, with hashes of the input covers. It deliberately labels global
ancestry replay and Lean verification as outside its scope.
