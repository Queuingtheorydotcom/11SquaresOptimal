# A virtual bottom row before the final spatial bounds

This argument uses the archived cover
`exploration/virtual-column-global-N192-certified-seed.json`.
It precedes `spatial-bounds-v6-verification.json`, which adds the ninth and
tenth bounds, and precedes the N=384 refinement used by the original
bottom-row checks. This is a replacement **local geometric argument** from
that cover. It does not establish or replace the cover's global ancestry.

Write S=3.88 and 4003/4000 <= a <= 25019/25000. Let P=C1 (owner 2),
Q=W0 (owner 5), and R be the common owner (owner 0). All are side-a squares
in [0,S]^2 with pairwise disjoint interiors. Angles are modulo pi/2.

## The compact interface

Put e=(cos theta,sin theta), n=(-sin theta,cos theta) for R and let phi
be Q's small signed angle. The following enclosures are sufficient:

- R's center is in [1.880,1.931] x [1.655,1.703], and
  2 atan(1/3) <= theta <= 2 atan(3/8).
- Q's center is in [2.297,2.381] x [.500,.552], and
  -2 atan(3/125) <= phi <= gamma=2 atan(1/26).
- Both whole squares P,Q lie below y=1.08, and the whole square P lies
  to the right of x=2.78.
- R's bottom vertex

      b=C_R - (a/2)(e+n)

  obeys b_y <= .9968 and n_gamma dot b <= n_gamma dot b*, where
  b*=(1.844,.9968) and n_gamma=(-sin gamma,cos gamma).
- The center support in direction e_1=(55,48)/73 is at most 2.568.

All decimal constants here denote exact rationals.
`check_bottom_row_envelope.py` freshly checks this interface against the
archived cover, using only the Python standard library. The bottom-vertex
conditions require sixteen scalar support checks, two per R angle bin.
The other conditions are coordinate/support extrema over rational polygons.

To see why the bottom-vertex extraction covers entire angle bins, write
C=cos gamma, T=sin gamma. On 0<=theta<=pi/4 both

    cos theta+sin theta,
    (C-T) cos theta+(C+T) sin theta

increase. For each pose polygon, take its maximum center projection and
subtract a/2 times the corresponding expression at the lower angle
endpoint, replacing a by its lower bound. These are valid upper bounds for
b_y and n_gamma dot b. Crucially, the slanted projection retains the
correlation between the two center coordinates.

## Only R's north-west edge can separate Q from R

Write C_R-C_Q=(-X,Y). The center boxes give

    .366 <= X <= .501,    1.103 <= Y <= 1.203.

The sum of the projection radii of two side-a squares in any unit direction
is at least a>1. Along either sign of R's edge e, the center projection
has absolute value at most max(.501,1.203 sin(theta_1))<1. The same is
true along Q's edge when phi>=0, with sin gamma in place of sin theta_1.
When phi=-u<=0, the absolute projection is at most
.501+1.203 sin(2 atan(3/125))<1. Thus neither square's edge direction
can separate them. Their north-west normals have positive center
projection, so their negatives cannot separate them either.

It remains to exclude Q's own north-west normal n_phi. Throughout these
angle ranges 0<theta-phi<pi/2, so R's minimum support in that direction
is attained at its bottom vertex b.

First suppose phi=-u<=0 and put C=cos u,T=sin u. Because theta<pi/4,
b_x<=X_R<=1.931<2.297<=X_Q, while b_y<=.9968<1<a. Hence

    n_phi dot b < T X_Q + C a.

The bottom wall requires Y_Q>=a(C+T)/2, and

    h_Q(n_phi) >= T X_Q + (a/2)[C(C+T)+1] >= T X_Q+C a,

the last inequality being (1-C)^2+CT>=0. Thus this normal cannot
separate Q below R.

Now suppose 0<=phi<=gamma. The two bottom-vertex bounds imply
n_phi dot b <= n_phi dot b*: n_phi is a positive linear combination of
(0,1) and n_gamma. Using X_Q<=2.381 and the bottom-wall inequality gives

    ell_R(n_phi)-h_Q(n_phi)
      <= .9968 cos phi + .537 sin phi
           - (1/2)[1+cos phi(cos phi+sin phi)].

Here replacing a by 1 only increases the right side. Set t=tan(phi/2).
After multiplication by the positive quantity (1+t^2)^2, its numerator is

    -.0032 + .074t + 2.074t^3 - 1.9968t^4.

For 0<=t<=1/26 this is at most

    -.0032 + .074/26 + 2.074/26^3
      = -10363/43940000 < 0.

So Q's north-west normal also fails to separate. The separating-axis
theorem for two squares therefore forces separation along R's n:

    h_Q(n) <= ell_R(n).

## The virtual row and its corner inequality

For every p in P, the compact interface gives

    n dot (C_R-p)
      >= (3/5)(.849)+(55/73)(.575) > a/2.

Thus h_P(n)<ell_R(n) as well. Since both P and Q lie in the strip
0<=y<=1.08<3a/2, the two-square strip-support theorem, reflected
horizontally, gives

    h_{P union Q}(n) >= h_E(n),
    E=[S-2a,S] x [0,a].

Consequently h_E(n)<=ell_R(n): the virtual row E is interior-disjoint
from R. No assumption that R intersects E, and no conditioned pose
cover, was needed.

To obtain the familiar corner inequality, put p=(S-2a,a) and z=C_R-p.
The center box shows 0<z_x<.053 and .654<z_y<.703. Therefore
e_theta dot z increases throughout theta's interval. Using the last
support bound and then a<=25019/25000,

    e_theta dot z - a/2
      <= 2.568 -(55/73)S + a(51/146) < 0.

Hence |e_theta dot(p-C_R)|<a/2. Also
n dot(p-C_R)<= (48/73)(.053)-(55/73)(.654)<0.
The corner p cannot be in R's interior, because every neighborhood of
p meets E's interior. Since it is strictly inside R's edge strip and
below its center in the n direction, it must lie below R's lower n edge.
Thus

    -sin(theta) X_R + cos(theta) Y_R
      >= -sin(theta)S + a[2 sin(theta)+cos(theta)+1/2].

This is the exact virtual-bottom-row inequality used downstream.

## What has and has not been removed

This local argument replaces the original 1,575 signed-axis checks,
180 P-support checks, and 424 corner checks with a compact rational
interface and an elementary polynomial estimate. It establishes the
same inequality from an earlier N=192 cover, so the ninth/tenth spatial
bounds and N=384 refinement are unnecessary **as premises of this lemma**.

The preceding virtual-column cover still depends on its own certified
pruning ancestry. A complete rewritten global proof must either retain
that ancestry or regenerate the earlier cover using the simplified
column argument. No such regeneration is claimed by the checker.
