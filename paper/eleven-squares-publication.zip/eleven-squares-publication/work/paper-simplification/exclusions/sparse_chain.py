"""Discover or replay a shortened ownership-only exclusion chain."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Do not run with Python -O')
HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--source',type=Path,default=HERE.parents[1]/'shared-final/n11-global-proof')
ap.add_argument('--case',type=int,choices=(0,3,5),default=5)
ap.add_argument('--mode',choices=('discover','replay'),default='discover')
ap.add_argument('--plan',type=Path)
ap.add_argument('--output',type=Path)
ap.add_argument('--jobs',type=int,default=4)
ap.add_argument('--max-backsteps',type=int,help='Bound discovery work; an interrupted discovery produces no accepted plan.')
ARGS=ap.parse_args()
SOURCE=ARGS.source.resolve()
PLAN=(ARGS.plan or HERE/f'case{ARGS.case}-plan.json').resolve()
OUTPUT=(ARGS.output or HERE/f'case{ARGS.case}-{ARGS.mode}.json').resolve()
if OUTPUT.is_relative_to(SOURCE) or PLAN.is_relative_to(SOURCE):
    raise ValueError('Research outputs must be outside the source directory')
sys.path.insert(0,str(SOURCE))
from marker_cases import all_cases,groups,A_LO,A_HI,S,SYMMETRY_OWNER
from forced_markers import owned_points,hull
from exact_poses import verify_owner,contains

JOURNAL=SOURCE/f'exploration/journal-case-{ARGS.case}-N96.json'
RAW=JOURNAL.read_bytes();DATA=json.loads(RAW)
GS=groups(all_cases()[0][ARGS.case]);N=DATA['bins']
assert N==96 and DATA['groups']==[list(g) for g in GS]
INITIAL={g:hull(owned_points(g)) for g in GS}
HISTORY=[{g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(GS,row['hulls'])} for row in DATA['history']]
LIMITS={SYMMETRY_OWNER[ARGS.case]:F(5,12)} if DATA.get('symmetry_restricted') else None

def serial(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):serial(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [serial(v) for v in x]
    return x

def owner_task(args):
    return verify_owner(*args)

def target_tasks(hs,target):
    if target['kind']=='hulls':
        r=target['round']
        return [(tuple(g),[p for p in HISTORY[r][tuple(g)] if not contains(hs[tuple(g)],p)],N,GS,hs,LIMITS) for g in target['owners']]
    if target['kind']=='common_point':
        point=tuple(map(F,target['point']))
        return [(tuple(g),[point],N,GS,hs,LIMITS) for g in target['owners']]
    if target['kind']=='empty':
        return [(tuple(target['owner']),[],N,GS,hs,LIMITS)]
    raise ValueError(target['kind'])

def attempt(task):
    r,retained,target=task
    hs={g:HISTORY[r][g] if r>=0 and g in retained else INITIAL[g] for g in GS}
    start=time.monotonic();checks=[]
    try:
        for args in target_tasks(hs,target):
            if target['kind']=='hulls' and not args[1]:continue
            result=verify_owner(*args);checks.append(result)
            if target['kind']=='empty':assert result['poses']==0,('domain_not_empty',result['poses'])
        return {'pass':True,'checks':checks,'seconds':time.monotonic()-start}
    except AssertionError as e:
        return {'pass':False,'failure':str(e),'seconds':time.monotonic()-start}

def discover():
    if ARGS.case in (3,5):
        targets={3:(((11,),(6,)),(F(49,25),F(73,25))),5:(((10,),(5,)),(F(29,10),F(5,2)))}
        owners,point=targets[ARGS.case]
        target={'kind':'common_point','owners':owners,'point':point}
        last=len(HISTORY)-2
    else:
        target={'kind':'empty','owner':tuple(DATA['terminal_group'])}
        last=len(HISTORY)-1
    backwards=[];log=[]
    while True:
        chosen=None
        # Seek the earliest recorded state that proves the desired conclusion.
        for r in range(-1,last+1):
            trial=attempt((r,tuple(GS),target))
            log.append({'phase':'earliest','round':r,'target':target,'result':trial})
            if trial['pass']:
                chosen=r;break
        if chosen is None:raise RuntimeError('Source target failed at every allowed predecessor')
        print(json.dumps({'target':serial(target),'earliest_predecessor':chosen}),flush=True)
        if chosen==-1:
            backwards.append({'premise_round':-1,'premise_owners':[],'conclusion':target})
            break
        with ProcessPoolExecutor(max_workers=ARGS.jobs) as pool:
            removals=list(pool.map(attempt,[(chosen,tuple(g for g in GS if g!=removed),target) for removed in GS]))
        safe=[g for g,t in zip(GS,removals) if t['pass']]
        kept=tuple(g for g in GS if g not in safe)
        combined=attempt((chosen,kept,target))
        log.append({'phase':'owner_pruning','round':chosen,'target':target,'single_removals':[{'owner':g,'result':t} for g,t in zip(GS,removals)],'combined':combined})
        if not combined['pass']:
            removed=[]
            for g in safe:
                trial=attempt((chosen,tuple(x for x in GS if x not in removed+[g]),target))
                if trial['pass']:removed.append(g)
            kept=tuple(g for g in GS if g not in removed)
        backwards.append({'premise_round':chosen,'premise_owners':kept,'conclusion':target})
        print(json.dumps({'predecessor':chosen,'retained_owners':kept}),flush=True)
        # Checkpoints preserve partial research even if later work is interrupted.
        OUTPUT.write_text(json.dumps(serial({'case':ARGS.case,'backwards':backwards,'log':log}),indent=2)+'\n')
        if ARGS.max_backsteps is not None and len(backwards)>=ARGS.max_backsteps:
            print('PARTIAL DISCOVERY ONLY: requested backstep limit reached',flush=True)
            return
        target={'kind':'hulls','round':chosen,'owners':kept}
        last=chosen-1
    plan={'schema':'sparse-ownership-chain-v1','case':ARGS.case,'bins':N,
          'journal_sha256':hashlib.sha256(RAW).hexdigest(),'steps':list(reversed(backwards))}
    PLAN.write_text(json.dumps(serial(plan),indent=2)+'\n')
    OUTPUT.write_text(json.dumps(serial({'plan':plan,'log':log}),indent=2)+'\n')
    print('DISCOVERED',PLAN,flush=True)

def replay():
    start=time.monotonic();plan=json.loads(PLAN.read_text())
    assert plan['case']==ARGS.case and plan['bins']==N
    assert plan['journal_sha256']==hashlib.sha256(RAW).hexdigest()
    known=set();records=[]
    with ProcessPoolExecutor(max_workers=ARGS.jobs) as pool:
        for index,step in enumerate(plan['steps']):
            r=step['premise_round'];owners=tuple(tuple(g) for g in step['premise_owners'])
            assert r==-1 or all((r,g) in known for g in owners),('unproved ancestry',step)
            hs={g:HISTORY[r][g] if r>=0 and g in owners else INITIAL[g] for g in GS}
            target=step['conclusion'];tasks=target_tasks(hs,target)
            if target['kind']=='hulls':tasks=[t for t in tasks if t[1]]
            checks=list(pool.map(owner_task,tasks))
            if target['kind']=='empty':assert checks[0]['poses']==0
            if target['kind']=='hulls':
                known.update((target['round'],tuple(g)) for g in target['owners'])
            elif target['kind']=='common_point':
                assert len(set(tuple(g) for g in target['owners']))>=2
            else:assert target['kind']=='empty'
            records.append({'step':step,'checks':checks})
            print(json.dumps({'step':index,'kind':target['kind'],'new_points':sum(c['points'] for c in checks),'owner_checks':len(checks)}),flush=True)
    assert plan['steps'][-1]['conclusion']['kind'] in ('common_point','empty')
    files=[JOURNAL,SOURCE/'marker_cases.py',SOURCE/'forced_markers.py',SOURCE/'exact_poses.py',Path(__file__),PLAN]
    result={'status':'PASS: SHORTENED OWNERSHIP CASE EXCLUSION FROM SOURCE INITIAL PREMISES',
        'case':ARGS.case,'scope':'Exact replay of retained ownership implications; marker foundation and stated symmetry reduction remain external premises. No other case or capture asserted.',
        'side_interval_open':[A_LO,A_HI],'container':S,'symmetry_limits':LIMITS,
        'records':records,'new_point_count':sum(c['points'] for r in records for c in r['checks']),
        'owner_checks':sum(len(r['checks']) for r in records),
        'elapsed_seconds':time.monotonic()-start,
        'source_sha256':{str(p.relative_to(SOURCE)) if p.is_relative_to(SOURCE) else p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    OUTPUT.write_text(json.dumps(serial(result),indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','case','new_point_count','owner_checks','elapsed_seconds')}),flush=True)

if __name__=='__main__':
    OUTPUT.parent.mkdir(parents=True,exist_ok=True);PLAN.parent.mkdir(parents=True,exist_ok=True)
    discover() if ARGS.mode=='discover' else replay()
