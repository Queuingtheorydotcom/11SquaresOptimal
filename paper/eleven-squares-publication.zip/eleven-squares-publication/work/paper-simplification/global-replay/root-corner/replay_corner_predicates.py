#!/usr/bin/env python3
"""Fresh conditional corner predicates and top-obstruction journal.

Archive receipt flags are never consulted. Accepted seed-producer equality
and root-hull semantics are separate explicitly named premises. Output stays
outside the source archive. All geometric arithmetic is exact.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,time
from concurrent.futures import ProcessPoolExecutor

def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 need(__debug__,'Run without -O')
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--mode',choices=['boxes','axes','top-obstruction'],required=True);ap.add_argument('--jobs',type=int,default=2);a=ap.parse_args()
 source=a.source.resolve();out=a.output.resolve();need(not out.is_relative_to(source),'Output in archive');need(1<=a.jobs<=4,'Worker count');out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source))
 from marker_cases import S,A_LO,A_HI,groups,all_cases
 from forced_markers import hull
 from exact_poses import area2,contains
 from exact_persistent_journal import bounds,cut_and_round
 from exact_corner_normalization import task,outer_poly,direction,dot,rot,project,gmin
 from exact_arc_hulls import Compatibility,reduce_domains
 from exact_pair_regions_fast import refine
 from exact_edge_arc_compatibility import normal
 observed={};start=time.monotonic();checks=[]
 def read(name):
  p=(source/name).resolve();need(p.is_relative_to(source),'Invalid path');observed[name]=sha(p);return json.loads(p.read_text())
 def bind_modules():
  for mod in list(sys.modules.values()):
   f=getattr(mod,'__file__',None)
   if f and Path(f).suffix=='.py' and Path(f).resolve().is_relative_to(source):
    p=Path(f).resolve();name=str(p.relative_to(source));h=sha(p);need(name not in observed or observed[name]==h,'Module changed');observed[name]=h
 bind_modules()
 rootname='exploration/corner-global-root-N96.json';root=read(rootname);gs=groups(all_cases()[0][6]);need(root['case']==6 and root['bins']==96 and root['branch']==[0,30,40] and root['base'] is None and root['groups']==[list(g) for g in gs],'Root schema')
 parent_artifacts=[rootname]
 if a.mode=='boxes':
  N=root['bins'];hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,root['history'][-1]['hulls'])};tasks=[(g,N,gs,hs,{gs[0]:F(5,12)},(30,40) if i==0 else None) for i,g in enumerate(gs)]
  with ProcessPoolExecutor(max_workers=a.jobs) as pool:owners=list(pool.map(task,tasks))
  for own,poses in enumerate(owners):
   xy=[p for q in poses for p in q['poly']];lo=[min(p[j] for p in xy) for j in [0,1]];hi=[max(p[j] for p in xy) for j in [0,1]]
   if own==4:
    need(F(1,2)<=lo[0]<=hi[0]<=F(71,100) and S-F(71,100)<=lo[1]<=hi[1]<=S-F(1,2),'C3 coarse bounds')
   elif own==10:
    need(F(121,100)<=lo[0]<=hi[0]<=F(149,100) and S-F(77,50)<=lo[1]<=hi[1]<=S-F(5,4),'I3 coarse bounds')
    for p in poses:
     need(0<=p['k']<N,'I3 bin')
     for k in [p['k'],p['k']+1]:
      c,s=direction(F(k,N));need(c>=0 and s>=0 and c+s>=F(13,10),'I3 width bound')
   else:need(lo[0]>=F(43,25) or hi[1]<=F(54,25),'Distant owner bound')
   checks.append({'owner':own,'pose_count':len(poses),'center_min':list(map(str,lo)),'center_max':list(map(str,hi))})
  verdict='PASS_FRESH_FIRST_CORNER_COARSE_BOUNDS'
 else:
  seedname='exploration/'+('inner' if a.mode=='axes' else 'top')+'-obstruction-certified-seed.json';seed=read(seedname);parent_artifacts.append(seedname);need(seed['case']==6 and seed['normalized_corner_owner']==4 and seed['obstructor']==(9 if a.mode=='axes' else 7) and seed['groups']==[list(g) for g in gs],'Seed schema');N=seed['bins'];poses=[];dom=[]
  for owner in seed['owners']:
   ids=set()
   for p in owner:
    k=p['k'];c,s=F(p['c']),F(p['s']);need(0<=k<N and (c,s)==normal(F(2*k+1,2*N)),'Pose frame');poly=[tuple(map(F,z)) for z in p['poly']];need(area2(poly)>0,'Degenerate input polygon');ids.add(len(poses));poses.append({'k':k,'c':c,'s':s,'poly':poly,'own':bounds(poly)})
   need(bool(ids),'Empty input owner');dom.append(ids)
  if a.mode=='axes':
   owners=[[outer_poly(poses[i]) for i in sorted(d)] for d in dom];P=owners[3];box=[(S-A_HI,S-A_HI),(S,S-A_HI),(S,S),(S-A_HI,S)];H=A_HI*(1+F(1,N))/2;error=F(3,N*N);cache={};minimum=None;total=0
   for other,Q in enumerate(owners):
    if other in [3,7]:continue
    direct=0;checked=0
    for q in Q:
     separate=False
     for n in [(F(1),F(0)),(F(0),F(1)),(q['c'],q['s']),(-q['s'],q['c'])]:
      support=H*(abs(n[0]*q['c']+n[1]*q['s'])+abs(-n[0]*q['s']+n[1]*q['c']));lo,hi=project(n,q['poly']);l,r=project(n,box)
      if lo-support>r or l>hi+support:separate=True;break
     if separate:direct+=1;continue
     for p in P:
      key=(p['k'],q['k'])
      if key not in cache:cache[key]=A_LO*(1+gmin(*key,N))/2-error
      threshold=cache[key]
      for ownerpose in [p,q]:
       endpoints=[direction(F(ownerpose['k'],N)),direction(F(ownerpose['k']+1,N))]
       for axis in [0,1]:
        ns=[rot(n) if axis else n for n in endpoints]
        for sign in [-1,1]:
         normals=[(sign*n[0],sign*n[1]) for n in ns]
         if all(n[0]<=0 and n[1]<=0 for n in normals):continue
         upper=max(project(n,q['poly'])[1]-project(n,p['poly'])[0] for n in normals);margin=threshold-upper;need(margin>0,'Non-inward separator remains');minimum=margin if minimum is None else min(minimum,margin);checked+=1
    checks.append({'other_owner':other,'poses':len(Q),'directly_separated':direct,'non_inward_signed_axes_excluded':checked});total+=checked;print(checks[-1],flush=True)
   need(minimum is not None and total>0,'Vacuous axis check');details={'non_inward_signed_axes_excluded':total,'minimum_margin':str(minimum)};verdict='PASS_FRESH_SECOND_CORNER_AXES'
  else:
   journalname='exploration/top-obstruction-certified-journal.json';journal=read(journalname);need(journal['method']=='corner_obstruction_persistent' and journal['seed']==seedname and journal['seed_sha256']==observed[seedname] and journal['bins']==N and journal['groups']==seed['groups'],'Obstruction journal schema');need(len(journal['history'])==1 and bool(journal.get('terminal')),'Unexpected obstruction journal');den=journal['rounding_denominator'];need(type(den) is int and den>0,'Rounding denominator');hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,seed['hulls'])};excluded=False
   for rnd,entry in enumerate(journal['history']+[None]):
    initial=[len(d) for d in dom];print('START obstruction',rnd,initial,flush=True);region=[]
    if all(dom):poses,dom,region=refine(poses,dom,N,a.jobs)
    cc=Compatibility(poses,N);ok,deletions=reduce_domains(dom,cc);record={'round':rnd,'initial':initial,'active':[len(d) for d in dom],'deleted_poses':len(deletions),'exact_incompatible_edges':cc.exact_edges,'center_pruning':region};checks.append(record)
    if not ok:excluded=True;break
    need(entry is not None,'Terminal obstruction did not exclude');new={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,entry['hulls'])};total=0
    for g,d in zip(gs,dom):
     need(all(contains(new[g],p) for p in hs[g]),'Hull loses prior points');added=[p for p in new[g] if not contains(hs[g],p)];total+=len(added)
     for i in d:
      p=poses[i];x0,x1,y0,y1=p['own'];c=p['c'];s=p['s']
      for X,Y in added:
       x=c*X+s*Y;y=-s*X+c*Y;need(x1-cc.h<=x<=x0+cc.h and y1-cc.h<=y<=y0+cc.h,'Uncertified obstruction vertex')
    hs=new;poses,dom=cut_and_round(poses,dom,gs,hs,N,den);record['checked_new_vertices']=total;record['after_hulls']=[len(d) for d in dom];print('CHECKED obstruction',rnd,record['after_hulls'],flush=True)
   need(excluded,'No obstruction contradiction');details={'journal':journalname,'journal_sha256':observed[journalname]};verdict='PASS_FRESH_TOP_OBSTRUCTION_EXCLUSION'
 bind_modules()
 for name,h in observed.items():need(sha(source/name)==h,'Source changed')
 result={'verdict':verdict,'mode':a.mode,'checks':checks,'details':details if a.mode!='boxes' else {},'source_inputs':observed,'harness_sha256':sha(__file__),'seconds':time.monotonic()-start,'premise_artifacts_not_discharged_here':parent_artifacts,'scope':'Fresh exact conditional predicates. The parent hull/seed theorems and the corner-support geometric argument are separate typed ancestry premises. Historical PASS fields are never consulted.'}
 (out/(a.mode+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(verdict,round(result['seconds'],2),'seconds',flush=True)
if __name__=='__main__':main()
