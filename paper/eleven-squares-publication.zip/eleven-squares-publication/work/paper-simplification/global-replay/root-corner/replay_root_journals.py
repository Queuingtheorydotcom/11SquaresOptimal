#!/usr/bin/env python3
"""Fresh root/angle journals via unchanged exact checkers in isolated copies.

Only freshly completed parent stages may justify --assume-base. Historical
receipts are never copied or read. Root marker/nonavoidance and boundary
lemmas remain mathematical premises. The source archive is never written.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,os,subprocess,time

def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cuts(d):
 out={}
 for own,lo,hi in d.get('cuts',[])+([d['branch']] if d.get('branch') else []):
  lo,hi=F(lo,d['bins']),F(hi,d['bins']);need(0<=lo<hi<=1,'Malformed angle cut')
  if own in out:lo,hi=max(lo,out[own][0]),min(hi,out[own][1])
  need(lo<hi,'Empty conjunction');out[own]=(lo,hi)
 return out
SOURCES=['exact_arc_fast.py','exact_arc_hulls.py','exact_pair_regions_fast.py','exact_pair_regions.py','exact_poses.py','forced_markers.py','marker_cases.py','exact_persistent_journal.py','corner_markers.py','verify_reduction.py']

def main():
 need(__debug__,'Run without -O')
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--stage',required=True);p.add_argument('--jobs',type=int,default=2);a=p.parse_args()
 source=a.source.resolve();out=a.output.resolve();need(not out.is_relative_to(source),'Output in archive');need(1<=a.jobs<=4,'Unexpected worker count')
 out.mkdir(parents=True,exist_ok=True);selected=out/'selected_source';selected.mkdir(exist_ok=True);(out/'fresh').mkdir(exist_ok=True)
 stages=json.loads(a.manifest.read_text())['stages'];stage=next(x for x in stages if x['journal']==a.stage);need(stage['checker'] in ['exact_arc_fast.py','exact_persistent_journal.py'],'This runner handles root/angle journals only')
 observed={}
 def copy(name):
  src=(source/name).resolve();need(src.is_relative_to(source),'Invalid source');b=src.read_bytes();observed[name]=hashlib.sha256(b).hexdigest();dst=selected/name;dst.parent.mkdir(parents=True,exist_ok=True)
  if dst.exists():need(dst.read_bytes()==b,'Selected immutable copy changed: '+name)
  else:dst.write_bytes(b)
  return json.loads(b) if name.endswith('.json') else None
 for name in SOURCES:copy(name)
 d=copy(a.stage);need(d['case']==6 and d['symmetry_restricted'],'Unexpected branch context');need(stage['rounds']==len(d['history']) and stage['terminal']==d.get('terminal'),'Manifest mismatch')
 need(d['groups']==[[8,9],[0],[1],[2],[3],[4],[5],[6],[7],[10],[11]],'Wrong owner labels')
 parent=None
 if d.get('base'):
  b=copy(d['base']);need(sha(selected/d['base'])==d['base_sha256'],'Base journal hash mismatch')
  pp=out/'fresh'/(Path(d['base']).stem+'-accepted.json');parent=json.loads(pp.read_text())
  need(parent['verdict']=='PASS_FRESH_ROOT_ANGLE_STAGE' and parent['journal_sha256']==d['base_sha256'],'Parent not freshly accepted')
  need(parent['harness_sha256']==sha(__file__),'Different parent harness')
  pr=out/parent['fresh_checker_receipt'];need(sha(pr)==parent['fresh_checker_receipt_sha256'],'Fresh parent receipt changed')
  need(not parent['terminal'] and parent['completed_hull_rounds']==len(b['history']),'Parent is not completed hull theorem')
  for name,h in parent['copied_source_inputs'].items():need(sha(source/name)==h,'Parent source changed')
  need(b['case']==d['case'] and b['groups']==d['groups'],'Base geometry mismatch')
  need(not b.get('symmetry_restricted') or d.get('symmetry_restricted'),'Dropped symmetry')
  childcuts=cuts(d)
  for own,(lo,hi) in cuts(b).items():need(own in childcuts and lo<=childcuts[own][0]<childcuts[own][1]<=hi,'Parent angle branch not inherited')
  parent={'id':str(pp.relative_to(out)),'sha256':sha(pp),'journal':d['base']}
 else:need(stage.get('base') is None,'Unexpected manifest parent')
 cmd=[sys.executable,'-B',stage['checker'],a.stage,'--jobs',str(a.jobs)]
 if parent:cmd+=['--assume-base']
 tag=Path(a.stage).stem;log=out/'fresh'/(tag+'-console.log')
 manifest={'journal':a.stage,'journal_sha256':observed[a.stage],'copied_source_inputs':observed,'fresh_parent':parent,'harness_sha256':sha(__file__),'command':cmd,'source_archive':str(source),'scope':'Fresh exact implication; no historical receipt acceptance.'}
 (out/'fresh'/(tag+'-input.json')).write_text(json.dumps(manifest,indent=2)+'\n')
 start=time.monotonic();print('START',a.stage,'parent',parent,'log',log,flush=True)
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
 with log.open('w') as f:subprocess.run(cmd,cwd=selected,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 terminal=bool(d.get('terminal'));suffix='.verified-implication.json' if terminal and parent else '.verified-exclusion.json' if terminal else '.verified-conditional-prefix.json' if parent else '.verified-prefix.json'
 rp=selected/(a.stage+suffix);r=json.loads(rp.read_text());need(r['journal_sha256']==observed[a.stage],'Fresh receipt journal mismatch');need(r.get('base_sha256')==d.get('base_sha256'),'Fresh receipt base mismatch');need(bool(r.get('base_assumed'))==bool(parent),'Fresh assumption mismatch')
 checks=r['checks'];need([x['round'] for x in checks]==list(range(len(checks))),'Nonsequential receipt')
 if terminal:
  need(checks and any(n==0 for n in checks[-1]['active']),'Terminal does not exclude')
  need(len(checks)<=len(d['history'])+1,'Unexpected terminal round')
  prefix=checks[:-1]
 else:
  need(r['completed_round']==len(d['history'])-1 and len(checks)==len(d['history']),'Incomplete prefix');prefix=checks
 need(all('checked_new_vertices' in x and all(x['active']) for x in prefix),'Missing hull checks')
 for name,h in observed.items():need(sha(source/name)==h and sha(selected/name)==h,'Immutable input changed')
 result={**manifest,'verdict':'PASS_FRESH_ROOT_ANGLE_STAGE','fresh_checker_receipt':str(rp.relative_to(out)),'fresh_checker_receipt_sha256':sha(rp),'completed_hull_rounds':len(prefix),'terminal':terminal,'angle_cuts':{str(i):list(map(str,v)) for i,v in cuts(d).items()},'fresh_checks':checks,'seconds':time.monotonic()-start,'scope':'Fresh exact stage with any base hull premise discharged only by the named freshly accepted parent. Initial marker/nonavoidance, side-bracket, symmetry and boundary lemmas remain mathematical premises. Not a complete global packing theorem.'}
 ap=out/'fresh'/(tag+'-accepted.json');ap.write_text(json.dumps(result,indent=2)+'\n');print(result['verdict'],a.stage,round(result['seconds'],2),'seconds',flush=True)
if __name__=='__main__':main()
