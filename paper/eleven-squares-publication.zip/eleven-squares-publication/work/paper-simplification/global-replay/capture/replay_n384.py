#!/usr/bin/env python3
"""Fresh exact N384 journal implications, with immutable upstream inputs.

Input seed, global spatial bounds, virtual obstacles, and analytic pruning
lemmas are explicit upstream premises. Archived verdict/ancestry flags are
never used to establish a newly replayed implication. Every output is outside
source. The mathematical operations are imported unchanged from that source.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,importlib,json,time

def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def semantic(v):
 if isinstance(v,dict):return {k:semantic(x) for k,x in v.items() if k!='seconds'}
 if isinstance(v,list):return [semantic(x) for x in v]
 return v

def main():
 need(__debug__,'Do not run with Python -O')
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--jobs',type=int,default=4);ap.add_argument('--rounds',type=int,default=12);args=ap.parse_args()
 source=args.source.resolve();out=args.output.resolve();need(not out.is_relative_to(source),'Output must be outside immutable source');need(args.jobs>0,'Invalid worker count')
 out.mkdir(parents=True,exist_ok=True);(out/'states').mkdir(exist_ok=True)
 sys.path.insert(0,str(source))
 from exact_persistent_journal import bounds,cut_and_round
 from retained_spatial_state import serialize
 from forced_markers import hull
 from exact_poses import contains,area2
 from exact_rectangle_cores import rectangle_cores
 from exact_arc_hulls import reduce_domains
 from exact_edge_arc_compatibility import Compatibility,normal
 from exact_actual_edge_pair_regions import refine
 from two_virtual_cuts import tighten
 observed={};historical_flags=[]
 def resolve(label):
  p=Path(label)
  if p.is_absolute():
   # Preserve the archived label while locating its identical file locally.
   pieces=p.parts;need('n11-global-proof' in pieces,'Unknown archived absolute path '+str(p));p=Path(*pieces[pieces.index('n11-global-proof')+1:])
  q=(source/p).resolve();need(q.is_relative_to(source),'Source path escapes archive');need(q.is_file(),'Missing source '+str(p));return q
 def bind(p):
  p=Path(p);name=str(p.relative_to(source));h=sha(p)
  need(name not in observed or observed[name]==h,'Input changed during replay: '+name);observed[name]=h;return h
 def read(label,check=True):
  p=resolve(label);bind(p);d=json.loads(p.read_text())
  if check:
   for label,h in d.get('source_hashes',{}).items():need(bind(resolve(label))==h,'Archived input hash mismatch: '+label)
  flags={k:v for k,v in d.items() if k in ('verdict','ancestry_discharged','hypothesis_ancestry_discharged','scope')}
  if flags:historical_flags.append({'input':str(p.relative_to(source)),'historical_metadata_not_replayed_here':flags})
  return d
 journal_name='exploration/two-virtual-actual-N384-journal.json';journal=read(journal_name)
 need(journal['method']=='corner_obstruction_persistent' and journal['case']==6,'Wrong journal')
 seed_name=journal['seed'];seed=read(seed_name);need(bind(resolve(seed_name))==journal['seed_sha256'],'Journal seed hash mismatch')
 need(seed['method']=='exact_spatial_branch_seed' and seed['case']==6 and seed['bins']==journal['bins']==384,'Wrong initial seed')
 need(seed['normalized_corners']==[3,4] and seed['groups']==journal['groups']==[[8,9],[0],[1],[2],[3],[4],[5],[6],[7],[10],[11]],'Wrong labels/corners')
 need(seed['spatial_cut']=={'owner':0,'inequalities':[['0','0','1']]},'Unexpected branch restriction')
 need(journal.get('terminal') is None and 0<=args.rounds<=len(journal['history'])==12,'Wrong prefix length')
 N=384;den=journal['rounding_denominator'];need(type(den) is int and den>0,'Bad rounding denominator')
 gs=[tuple(g) for g in seed['groups']];hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,seed['hulls'])}
 need(len(hs)==11 and len(seed['owners'])==11,'Incomplete seed')
 poses=[];dom=[]
 for owner in seed['owners']:
  ids=set()
  for p in owner:
   k=p['k'];need(type(k) is int and 0<=k<k+1<=N,'Bad angle bin');c,s=F(p['c']),F(p['s']);need((c,s)==normal(F(2*k+1,2*N)),'Wrong pose frame')
   poly=[tuple(map(F,q)) for q in p['poly']];need(area2(poly)>0,'Degenerate initial polygon')
   ids.add(len(poses));poses.append({'k':k,'c':c,'s':s,'poly':poly,'own':bounds(poly)})
  need(bool(ids),'Empty initial owner');dom.append(ids)
 # Same order and exact deduplication as load_inherited_bounds, but without
 # interpreting archived ancestry/verdict labels as newly proved theorems.
 bound_sources={'spatial-bounds-v3-verification.json'}
 fixed=list(read('spatial-bounds-v3-verification.json')['necessary_halfplanes']);seen=set()
 def visit(label):
  p=resolve(label);key=str(p)
  if key in seen:return
  seen.add(key);d=read(label)
  if d.get('global_spatial_bounds'):
   name=d['global_spatial_bounds'];r=read(name);need(r['case']==6 and r['normalized_corners']==[3,4],'Wrong inherited bound labels');bound_sources.add(name);fixed.extend(r['necessary_halfplanes'])
  for field in ['root','parent_seed','global_retained_parent','unbounded_root','rectangle_core_parent']:
   if d.get(field):visit(d[field])
 visit(seed_name)
 unique={}
 for b in fixed:unique[(b['owner'],tuple(b['normal']),b['upper'])]=b
 fixed=list(unique.values())
 for name,owner in [('virtual-column-verification.json',9),('virtual-bottom-row-verification.json',0)]:
  d=read(name);need(d['owner']==owner,'Wrong virtual-support owner')
 for name in ['VIRTUAL_BOTTOM_ROW.md','VIRTUAL_COLUMN.md','ACTUAL_EDGE_CENTER_PRUNING.md','FIXED_CONSTRAINTS_AND_EDGE_ARCS.md','RECTANGLE_CORES.md']:bind(resolve(name))
 # Bind all actually imported source modules, including transitive helpers.
 for mod in list(sys.modules.values()):
  f=getattr(mod,'__file__',None)
  if f and Path(f).resolve().is_relative_to(source) and Path(f).suffix=='.py':bind(Path(f).resolve())
 archived_names=['exploration/two-virtual-actual-N384-journal.json.verified-prefix.json','exploration/two-virtual-actual-N384-state.json','exploration/two-virtual-actual-N384-certified-seed.json']
 archived={name:read(name,check=False) for name in archived_names}
 assumptions=['The original N384 seed covers every surviving normalized legal packing and its compulsory hulls are valid.','The inherited spatial halfplanes and both virtual-obstacle support inequalities are necessary.','The source analytic pose, actual-edge, rectangle-core, strict-cut and outward-rounding lemmas are valid.']
 manifest={'source_inputs':observed,'harness_sha256':sha(Path(__file__)),'journal':journal_name,'seed':seed_name,'inherited_bound_sources':sorted(bound_sources),'upstream_assumptions':assumptions,'historical_metadata':historical_flags}
 (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 start=time.monotonic();checks=[];states=[]
 def save_state(prefix):
  path=out/'states'/f'prefix-{prefix:02d}.json'
  state={'method':'fresh_exact_N384_prefix','case':6,'bins':N,'groups':seed['groups'],'hulls':[[[str(x),str(y)] for x,y in hs[g]] for g in gs],'owners':serialize(poses,dom),'normalized_corners':[3,4],'spatial_cut':seed['spatial_cut'],'fresh_completed_rounds':prefix,'input_manifest_sha256':sha(out/'input-manifest.json'),'scope':'Fresh exact conditional prefix from the source initial seed; upstream validity and analytic lemmas remain explicit. Historical PASS flags are not proof premises.'}
  path.write_text(json.dumps(state,indent=2)+'\n');states.append({'prefix':prefix,'file':str(path.relative_to(out)),'sha256':sha(path),'counts':[len(d) for d in dom]})
 poses,dom=tighten(poses,dom,N,seed['spatial_cut'],fixed);save_state(0);print('EXPORTED PREFIX 0',states[-1]['counts'],flush=True)
 for rnd,entry in enumerate(journal['history'][:args.rounds]):
  initial=[len(d) for d in dom];print('START',rnd+1,initial,flush=True)
  region=[]
  if all(dom):poses,dom,region=refine(poses,dom,N,args.jobs)
  cc=Compatibility(poses,N);ok,deletions=reduce_domains(dom,cc);need(ok,'Unexpected fresh exclusion')
  record={'round':rnd,'initial':initial,'active':[len(d) for d in dom],'deleted_poses':len(deletions),'exact_incompatible_edges':cc.exact_edges,'actual_edge_arc_exclusions':cc.arc_edges,'seconds':time.monotonic()-start,'center_pruning':region}
  certified_base,core_records=rectangle_cores(poses,dom,gs,hs,N);record['rectangle_cores']=core_records
  record['certified_core_vertices']=sum(sum(not contains(hs[g],tuple(map(F,p))) for p in r['core']) for g,r in zip(gs,core_records))
  new={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,entry['hulls'])};total=0
  for g,d in zip(gs,dom):
   need(all(contains(new[g],p) for p in hs[g]),'Hull loses prior compulsory points')
   added=[p for p in new[g] if not contains(certified_base[g],p)];total+=len(added)
   for i in d:
    p=poses[i];x0,x1,y0,y1=p['own'];c=p['c'];s=p['s']
    for X,Y in added:
     x=c*X+s*Y;y=-s*X+c*Y;need(x1-cc.h<=x<=x0+cc.h and y1-cc.h<=y<=y0+cc.h,f'Uncertified new compulsory vertex at round{rnd}, owner{g}, bin{p["k"]}')
  hs=new;poses,dom=cut_and_round(poses,dom,gs,hs,N,den);poses,dom=tighten(poses,dom,N,seed['spatial_cut'],fixed)
  record['checked_new_vertices']=total;record['after_hulls']=[len(d) for d in dom];checks.append(record);save_state(rnd+1)
  (out/'fresh-prefix-receipt.json').write_text(json.dumps({'verdict':'PASS_FRESH_CONDITIONAL_N384_PREFIX','completed_rounds':rnd+1,'states':states,'checks':checks,'upstream_assumptions':assumptions,'input_manifest_sha256':sha(out/'input-manifest.json')},indent=2)+'\n')
  print('EXPORTED PREFIX',rnd+1,record['after_hulls'],'seconds',round(time.monotonic()-start,2),flush=True)
 comparisons={}
 if args.rounds==12:
  fresh=json.loads((out/'states/prefix-12.json').read_text())
  fields=['case','bins','groups','hulls','owners','normalized_corners']
  for name in archived_names[1:]:
   old=archived[name];same=all(fresh[k]==old[k] for k in fields);need(same,'Fresh geometry differs from archive: '+name);comparisons[name]='EXACT_EQUALITY_OF_ALL_GEOMETRIC_FIELDS'
  historic=archived[archived_names[0]];same=semantic(checks)==semantic(historic['checks']);need(same,'Fresh check detail differs from historical replay');comparisons['historical_checks_except_elapsed_seconds']='EXACT_EQUALITY'
 for name,digest in observed.items():need(sha(source/name)==digest,'Immutable source changed: '+name)
 report={'verdict':'PASS_FRESH_N384_CONDITIONAL_REPLAY','completed_rounds':args.rounds,'states':states,'comparisons':comparisons,'source_immutability_checked_files':len(observed),'input_manifest_sha256':sha(out/'input-manifest.json'),'harness_sha256':sha(Path(__file__)),'seconds':time.monotonic()-start,'upstream_assumptions':assumptions,'scope':'Every exported prefix follows by freshly checked exact operations from the named input seed and explicit upstream lemmas; no historical PASS/ancestry flag is treated as a fresh proof. Full earlier seed ancestry remains outside this replay.'}
 (out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(report['verdict'],flush=True)
if __name__=='__main__':main()
