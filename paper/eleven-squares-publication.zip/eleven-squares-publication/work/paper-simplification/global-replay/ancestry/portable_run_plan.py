#!/usr/bin/env python3
"""Generate the selected case-6 replay command plan without executing it.

Paths and working directories are relative to the extracted project root.
The runtime must replace {python} with its interpreter and {jobs} with a
positive worker count (default 2), execute commands in order, and then use
the final assembler. This plan neither trusts saved PASS files nor proves
the displayed continuous mathematical lemmas.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


BASE = Path("work/paper-simplification/global-replay")
ANCESTRY = BASE / "ancestry"
SOURCE = Path("work/shared-final/n11-global-proof")
SNAPSHOT = Path("work/paper-simplification/audit/dependency-snapshot.json")


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_plan(root, jobs=2):
    root = Path(root).resolve()
    need(type(jobs) is int and 1 <= jobs <= 4, "Workers must be between 1 and 4")
    read = lambda path: json.loads((root / path).read_text())
    graph = read(ANCESTRY / "acceptance-graph.json")
    root_manifest = read(ANCESTRY / "root-journal-manifest.json")
    spatial_manifest = read(ANCESTRY / "spatial-chain-manifest.json")
    roots = {row["journal"]: row for row in root_manifest["stages"]}
    spatial = {row["journal"]: row for chain in spatial_manifest["chains"]
               for row in chain["stages"]}
    need(len(roots) == len(root_manifest["stages"]) == 12, "Wrong root-stage inventory")
    need(len(spatial) == sum(len(c["stages"]) for c in spatial_manifest["chains"]) == 25,
         "Wrong spatial-stage inventory")
    commands = []

    def add(name, category, script, args, receipt, verdict, nodes=(), **detail):
        need(all(row["id"] != name for row in commands), "Duplicate command id")
        need((root / script).is_file(), "Missing replay script: " + str(script))
        command = {
            "id": name, "category": category, "cwd": ".",
            "argv": ["{python}", "-B", str(script), *map(str, args)],
            "completion_artifact": str(receipt),
            "completion_field": "verdict", "completion_value": verdict,
            "semantic_nodes": list(nodes), **detail,
        }
        commands.append(command)

    add("foundation", "foundation", BASE / "check_foundation.py",
        ["--source", SOURCE, "--output", BASE / "foundation.json"],
        BASE / "foundation.json", "PASS_FRESH_FOUNDATIONAL_ARITHMETIC_AND_CONSTRUCTION",
        ["@foundation"])
    for name, script, artifact, verdict in [
        ("interfaces", "check_interfaces.py", "interface-result.json",
         "PASS_FRESH_CONDITIONAL_ANCESTRY_INTERFACES"),
        ("domain-producers", "check_domain_producers.py", "domain-result.json",
         "PASS_ALL_SELECTED_DOMAIN_PRODUCERS"),
    ]:
        add(name, "conditional_producer", ANCESTRY / script,
            ["--source", SOURCE, "--snapshot", SNAPSHOT, "--output", ANCESTRY / "fresh"],
            ANCESTRY / "fresh" / artifact, verdict)
    add("compact-supports", "conditional_producer", ANCESTRY / "replay_compact_supports.py",
        ["--source", SOURCE, "--output", ANCESTRY / "fresh"],
        ANCESTRY / "fresh/compact-support-result.json", "PASS_FRESH_COMPACT_SUPPORT_INTERFACES",
        ["@virtual-column", "@virtual-bottom"])

    seen_roots, seen_spatial, seen_shared = set(), set(), set()
    seen_nodes = set()
    for node_id in graph["topological_order"]:
        node = graph["nodes"][node_id]
        need(node["id"] == node_id and all(p in seen_nodes for p in node["parents"]),
             "Graph is not a complete topological ordering")
        seen_nodes.add(node_id)
        if node["kind"] == "exact_geometric_predicate":
            modes = {"@corner-coarse-boxes": ("boxes", "PASS_FRESH_FIRST_CORNER_COARSE_BOUNDS"),
                     "@second-corner-axes": ("axes", "PASS_FRESH_SECOND_CORNER_AXES")}
            need(node_id in modes, "Unknown corner predicate")
            mode, verdict = modes[node_id]
            add("corner-" + mode, "corner_predicate", BASE / "root-corner/replay_corner_predicates.py",
                ["--source", SOURCE, "--output", BASE / "root-corner/fresh", "--mode", mode,
                 "--jobs", "{jobs}"], BASE / "root-corner/fresh" / (mode + "-result.json"),
                verdict, [node_id])
        if node["kind"] not in ("journal_prefix", "journal_exclusion"):
            continue
        journal = node["candidate_journal"]
        stem = Path(journal).stem
        if journal in roots:
            stage = roots[journal]
            need(not stage.get("base") or stage["base"] in seen_roots,
                 "Root --assume-base would run before its fresh parent")
            seen_roots.add(journal)
            if stage["checker"] == "exact_obstruction_journal.py":
                add("corner-top-obstruction", "corner_predicate",
                    BASE / "root-corner/replay_corner_predicates.py",
                    ["--source", SOURCE, "--output", BASE / "root-corner/fresh",
                     "--mode", "top-obstruction", "--jobs", "{jobs}"],
                    BASE / "root-corner/fresh/top-obstruction-result.json",
                    "PASS_FRESH_TOP_OBSTRUCTION_EXCLUSION", [node_id], journal=journal,
                    hull_rounds=stage["rounds"], terminal=bool(stage["terminal"]))
            else:
                add("root-" + stem, "root_journal", BASE / "root-corner/replay_root_journals.py",
                    ["--source", SOURCE, "--manifest", ANCESTRY / "root-journal-manifest.json",
                     "--output", BASE / "root-corner", "--stage", journal, "--jobs", "{jobs}"],
                    BASE / "root-corner/fresh" / (stem + "-accepted.json"),
                    "PASS_FRESH_ROOT_ANGLE_STAGE", [node_id], journal=journal,
                    hull_rounds=stage["rounds"], terminal=bool(stage["terminal"]))
        elif journal in spatial:
            stage = spatial[journal]
            seen_spatial.add(journal)
            directory = BASE / "spatial/fresh" / stem
            add("spatial-" + stem, "spatial_journal", BASE / "spatial/replay_spatial.py",
                ["--source", SOURCE, "--manifest", ANCESTRY / "spatial-chain-manifest.json",
                 "--output", directory, "--journal", stem, "--jobs", "{jobs}"],
                directory / "result.json", "PASS_FRESH_SPATIAL_CONDITIONAL_REPLAY", [node_id],
                journal=journal, hull_rounds=stage["rounds"], terminal=bool(stage["terminal"]))
        else:
            need(node["original_checker"] in (
                "exact_rectangle_core_journal.py", "exact_precise_edge_journal.py",
                "exact_adaptive_edge_journal.py", "exact_virtual_column_journal.py"),
                "Unclassified journal " + journal)
            seen_shared.add(journal)
            directory = BASE / "capture/shared" / stem
            add("shared-" + stem, "shared_journal", BASE / "capture/replay_shared_global.py",
                ["--source", SOURCE, "--output", directory, "--journal", stem, "--jobs", "{jobs}"],
                directory / "result.json", "PASS_FRESH_SHARED_GLOBAL_CONDITIONAL_REPLAY",
                [node_id], journal=journal, hull_rounds=node["hull_rounds"], terminal=False)

    need(seen_nodes == set(graph["nodes"]), "Unvisited semantic nodes")
    need(seen_roots == set(roots) and seen_spatial == set(spatial), "Unscheduled manifest stages")
    need(len(seen_shared) == 8, "Wrong shared-stage count")
    need(sum(c.get("hull_rounds", 0) for c in commands if c["category"] == "shared_journal") == 60,
         "Wrong shared-round count")
    need(sum(c.get("hull_rounds", 0) for c in commands if c["category"] == "spatial_journal") == 112,
         "Wrong spatial-round count")
    add("selected-capture-prefix-5", "capture", BASE / "capture/replay_n384.py",
        ["--source", SOURCE, "--output", BASE / "capture/fresh", "--rounds", "5",
         "--jobs", "{jobs}"], BASE / "capture/fresh/result.json",
        "PASS_FRESH_N384_CONDITIONAL_REPLAY", ["@N384-prefix-5"], hull_rounds=5)
    add("selected-mixed-ending", "ending", ANCESTRY / "replay_selected_endpoint.py", [],
        BASE / "early-ending/selected-ending-result.json", "PASS_SELECTED_FIVE_ROUND_ENDING",
        ["@case6-selected-support-ending"])
    add("case6-acceptance", "assembler", ANCESTRY / "refresh_acceptance.py",
        ["--source", SOURCE, "--output", ANCESTRY, "--require-complete"],
        ANCESTRY / "acceptance-status.json", "PASS_FRESH_CASE6_ANCESTRY_CLOSED",
        [graph["target"]])

    return {
        "schema": "selected-case6-portable-command-plan-v1",
        "generated_by_sha256": digest(Path(__file__).resolve()),
        "input_sha256": {str(p): digest(root / p) for p in (
            ANCESTRY / "acceptance-graph.json", ANCESTRY / "root-journal-manifest.json",
            ANCESTRY / "spatial-chain-manifest.json", SNAPSHOT)},
        "placeholders": {"python": "Use the current Python interpreter", "jobs": jobs},
        "path_policy": "Every argv file path and cwd is relative to the extracted project root.",
        "command_count": len(commands), "category_counts": dict(Counter(c["category"] for c in commands)),
        "semantic_nodes": len(graph["nodes"]), "target": graph["target"],
        "commands": commands,
        "scope": "Only a command plan, not a proof receipt. The executor must freshly run every command, bind its inputs and outputs, then require the final acceptance assembler to close all 119 nodes. Bulk producer checks are conditional and can execute before their mathematical parents; only final semantic closure discharges those parents. Other ownership cases and the final all-case assembly are added by the outer runner. Reviewed continuous mathematical lemmas remain explicit human proof inputs.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[4])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    plan = build_plan(args.root, args.jobs)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(plan, indent=2) + "\n")
    print("PLAN ONLY:", plan["command_count"], "commands;", plan["semantic_nodes"], "semantic nodes")


if __name__ == "__main__":
    main()
