#!/usr/bin/env python3
"""Fail-closed composition of this run's reviewed, freshly executed interfaces.

This is a receipt/geometry assembler, not a replacement for executing the
exact checkers. Its trust model includes the displayed mathematical lemmas
and the recorded executions of SHA-pinned reviewed Python harnesses. A future
portable verifier must execute those harnesses before using this assembler.
"""
import argparse,hashlib,json
from pathlib import Path

def need(p,msg):
    if not p:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def graph_digest(graph):
    ignore={'fresh_rule_status','fresh_rule_receipt','transitive_acceptance'}
    data={'target':graph['target'],'topological_order':graph['topological_order'],
          'nodes':{k:{a:b for a,b in v.items() if a not in ignore} for k,v in graph['nodes'].items()}}
    return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--require-complete',action='store_true')
    a=ap.parse_args();source=a.source.resolve();base=a.output.resolve();work=base.parents[2]
    need(not base.is_relative_to(source),'Output in archive')
    graph=read(base/'acceptance-graph.json');pins=read(base/'reviewed-harnesses.json')
    need(graph_digest(graph)==pins['semantic_graph_sha256'],'Semantic DAG differs from reviewed topology/recipes')
    for label,digest in pins['harnesses'].items():
        need(sha(work/label)==digest,'Reviewed harness dependency changed '+label)
    need(sha(base/'mathematical-lemmas.json')==pins['mathematical_lemmas_sha256'],
         'Displayed mathematical lemma registry differs from reviewed version')
    math=read(base/'mathematical-lemmas.json');evidence={};errors={};status={}
    def source_bindings(d,field='source_inputs'):
        values=d.get(field)
        need(type(values) is dict and bool(values),'Missing/nonempty source binding map '+field)
        for name,h in values.items():
            p=(source/name).resolve();need(p.is_relative_to(source) and p.is_file(),'Bad source binding '+name)
            need(sha(p)==h,'Source binding changed '+name)
    def harness(d,relative,field='harness_sha256'):
        p=(base/relative).resolve();label=str(p.relative_to(work))
        need(label in pins['harnesses'],'Unreviewed harness '+label)
        need(sha(p)==pins['harnesses'][label]==d[field],'Changed harness '+label)
    def bound_receipt(path,relative,verdict,field='source_inputs'):
        d=read(path);need(d['verdict']==verdict,'Unexpected fresh verdict '+str(path))
        harness(d,relative)
        if field is not None:source_bindings(d,field)
        return d
    def proof(id):
        m=math['lemmas'][id]
        need(m['status']=='MATHEMATICAL_PROOF_REVIEWED','Unaccepted mathematical lemma')
        need(type(m['files']) is dict and bool(m['files']),'Mathematical lemma has no displayed proof')
        for label,h in m['files'].items():
            p=(work/label).resolve();need(p.is_relative_to(work),'Escaped proof path')
            need(sha(p)==h,'Displayed proof/review changed '+label)
        return {'kind':'displayed_mathematical_proof','certificate':'mathematical-lemmas.json',
                'certificate_sha256':sha(base/'mathematical-lemmas.json'),'id':id,
                'formalized':False,'claim':m['claim']}
    def json_evidence(path,**details):
        return {'kind':'fresh_computational_implication','receipt':str(path.relative_to(base.parent)),
                'receipt_sha256':sha(path),**details}
    def own_interface(node):
        if node.get('fresh_domain_producer'):
            p=base/'fresh/domain-result.json'
            d=bound_receipt(p,'check_domain_producers.py','PASS_ALL_SELECTED_DOMAIN_PRODUCERS')
            row=next(x for x in d['checks'] if x['artifact']==node['fresh_domain_producer'])
            need(row['verdict']=='PASS_FRESH_CONDITIONAL_DOMAIN_PRODUCER','Failed domain producer')
            need(row['sha256']==sha(source/row['artifact']),'Wrong domain target')
            need(row['facts'].get('all_owner_pose_domains_exact_equal') is True,'Incomplete domain equality')
            return json_evidence(p,check=row['artifact'],geometry_sha256=row['sha256'])
        tag=node.get('fresh_interface')
        if tag:
            p=base/'fresh/interface-result.json'
            d=bound_receipt(p,'check_interfaces.py','PASS_FRESH_CONDITIONAL_ANCESTRY_INTERFACES')
            row=next(x for x in d['checks'] if x['id']==tag)
            need(row['status']=='FRESH_EXACT_INTERFACE_PASS','Failed interface')
            if row.get('historical_output_artifact'):
                need(row['historical_output_sha256']==sha(source/row['historical_output_artifact']),'Wrong interface target')
            return json_evidence(p,check=tag)
        raise ValueError('No own interface recipe')
    def root_journal(node):
        jname=node['candidate_journal'];j=read(source/jname)
        p=base.parent/'root-corner/fresh'/(Path(jname).stem+'-accepted.json')
        d=bound_receipt(p,'../root-corner/replay_root_journals.py','PASS_FRESH_ROOT_ANGLE_STAGE','copied_source_inputs')
        need(d['journal']==jname and d['journal_sha256']==sha(source/jname),'Wrong root journal')
        rp=base.parent/'root-corner'/d['fresh_checker_receipt']
        need(sha(rp)==d['fresh_checker_receipt_sha256'],'Fresh checker result changed')
        rr=read(rp);need(rr['journal_sha256']==sha(source/jname),'Checker journal mismatch')
        need(rr['checks']==d['fresh_checks'],'Fresh checks not bound')
        need(bool(d['terminal'])==bool(j.get('terminal')),'Root terminal mismatch')
        if d['terminal']:
            need(d['fresh_checks'] and any(x==0 for x in d['fresh_checks'][-1]['active']),'Missing actual exclusion')
        else:need(d['completed_hull_rounds']==len(j['history']),'Incomplete root prefix')
        if j.get('base'):
            need(d['fresh_parent']['journal']==j['base'],'Wrong fresh base')
            pp=base.parent/'root-corner'/d['fresh_parent']['id']
            need(sha(pp)==d['fresh_parent']['sha256'],'Changed fresh parent receipt')
        else:need(d['fresh_parent'] is None,'Unexpected fresh root base')
        return json_evidence(p,journal=jname,checker_receipt_sha256=sha(rp))
    def predicate(mode,verdict):
        p=base.parent/'root-corner/fresh'/(mode+'-result.json')
        d=bound_receipt(p,'../root-corner/replay_corner_predicates.py',verdict)
        need(d['mode']==mode,'Wrong corner predicate mode')
        if mode=='boxes':need(len(d['checks'])==11,'Incomplete owner boxes')
        elif mode=='axes':need(d['details']['non_inward_signed_axes_excluded']>0,'Empty axis proof')
        else:need(d['checks'] and any(n==0 for n in d['checks'][-1]['active']),'Top obstruction not excluded')
        return json_evidence(p)
    def persistent(node):
        jname=node['candidate_journal'];j=read(source/jname);stem=Path(jname).stem
        spatial=bool(j.get('terminal')) or 'exact-spatial-' in stem or stem.startswith(('tight-central-','tight-C1-'))
        if spatial:
            directory=base.parent/'spatial/fresh'/stem;h='../spatial/replay_spatial.py'
            verdict='PASS_FRESH_SPATIAL_CONDITIONAL_REPLAY'
        else:
            directory=base.parent/'capture/shared'/stem;h='../capture/replay_shared_global.py'
            verdict='PASS_FRESH_SHARED_GLOBAL_CONDITIONAL_REPLAY'
        p=directory/'result.json';d=bound_receipt(p,h,verdict,field=None)
        need(d['journal']==jname and d['completed_rounds']==len(j['history']),'Incomplete/wrong journal')
        mp=directory/'input-manifest.json';need(sha(mp)==d['input_manifest_sha256'],'Changed input manifest')
        m=read(mp);harness(m,h);source_bindings(m)
        need(m['journal']==jname and m['seed']==j['seed'],'Wrong journal parent')
        need(m['source_inputs'][jname]==sha(source/jname) and m['source_inputs'][j['seed']]==sha(source/j['seed']),
             'Wrong journal/seed input bytes')
        need(d['comparisons'].get('historical_checks_except_elapsed_seconds')=='EXACT_EQUALITY','Missing fresh check comparison')
        need([s['prefix'] for s in d['states']]==list(range(len(j['history'])+1)),'Incomplete fresh prefix exports')
        for s in d['states']:
            need(sha(directory/s['file'])==s['sha256'],'Changed fresh state')
        if spatial:need(d['excluded']==bool(j.get('terminal')),'Wrong exclusion outcome')
        if node.get('output_geometry'):
            old=read(source/node['output_geometry']);fresh=read(directory/d['states'][-1]['file'])
            for key in ('case','bins','groups','hulls','owners','normalized_corners','spatial_cut'):
                need(fresh[key]==old[key],'Fresh output geometry mismatch '+key)
        return json_evidence(p,journal=jname,manifest_sha256=sha(mp),
                             output_state_sha256=d['states'][-1]['sha256'])
    def rule(node):
        id=node['id'];kind=node['kind']
        if kind=='mathematical_lemma':return proof(id)
        if kind=='mathematical_root':
            p=base.parent/'foundation.json';d=read(p)
            need(d['verdict']=='PASS_FRESH_FOUNDATIONAL_ARITHMETIC_AND_CONSTRUCTION','Root verdict')
            harness(d,'../check_foundation.py','checker_sha256');source_bindings(d,'source_sha256')
            return {'kind':'root_arithmetic_and_mathematics','arithmetic':json_evidence(p),'mathematics':proof(id)}
        if kind=='global_input_contract':return {'kind':'conjunction','required_parent_count':len(node['parents'])}
        if kind=='fresh_capture_prefix':
            directory=base.parent/'capture/fresh';p=directory/'result.json'
            d=bound_receipt(p,'../capture/replay_n384.py','PASS_FRESH_N384_CONDITIONAL_REPLAY',field=None)
            need(d['completed_rounds']>=node['prefix_rounds'],'Missing required capture rounds')
            mp=directory/'input-manifest.json';need(sha(mp)==d['input_manifest_sha256'],'Changed capture input manifest')
            m=read(mp);harness(m,'../capture/replay_n384.py');source_bindings(m)
            need(m['journal']=='exploration/two-virtual-actual-N384-journal.json'
                 and m['seed']=='exploration/two-virtual-actual-N384-seed.json','Wrong capture input')
            need(m['source_inputs'][m['journal']]==sha(source/m['journal'])
                 and m['source_inputs'][m['seed']]==sha(source/m['seed']),'Capture journal/seed binding missing')
            row=next(x for x in d['states'] if x['prefix']==node['prefix_rounds'])
            need(sha(directory/row['file'])==row['sha256'],'Changed fresh capture prefix')
            fresh=read(directory/row['file']);reference=read(base/'selected-prefix-reference.json')
            for k in ('case','bins','groups','hulls','owners','normalized_corners','spatial_cut'):
                need(fresh[k]==reference[k],'Capture/reference geometric mismatch '+k)
            return json_evidence(p,prefix_rounds=node['prefix_rounds'],fresh_prefix_sha256=row['sha256'],
                                 selected_reference_sha256=sha(base/'selected-prefix-reference.json'),
                                 comparison='Exact geometric equality; provenance/timing metadata may differ.')
        if kind=='mixed_support_endpoint':
            p=base.parent/'early-ending/selected-ending-result.json';d=read(p)
            need(d['verdict']=='PASS_SELECTED_FIVE_ROUND_ENDING' and d['prefix_rounds']==5,'Wrong selected endpoint')
            reference_key='ancestry/selected-prefix-reference.json' if 'ancestry/selected-prefix-reference.json' in d['source_sha256'] else 'capture/fresh/states/prefix-05.json'
            need(d['source_sha256'][reference_key]==sha(base/'selected-prefix-reference.json'),
                 'Selected endpoint refers to different geometric reference')
            for name,h in d['source_sha256'].items():
                # Fresh capture provenance is separately bound by the preceding
                # node; its metadata bytes need not survive a portable replay.
                if name.startswith('capture/fresh/'):continue
                q=base.parent/name;need(sha(q)==h,'Selected endpoint dependency changed '+name)
                if q.suffix=='.py':
                    label=str(q.relative_to(work));need(pins['harnesses'].get(label)==h,'Unreviewed endpoint checker')
            if 'early-ending/portable-replay-binding.json' in d['source_sha256']:
                binding=read(base.parent/'early-ending/portable-replay-binding.json')
                harness(binding,'replay_selected_endpoint.py','adapter_sha256')
                need(binding['fresh_result_sha256']==sha(base.parent/'capture/fresh/result.json'),
                     'Portable reference bound to different fresh replay')
                need(binding['selected_reference_sha256']==sha(base/'selected-prefix-reference.json'),
                     'Portable reference changed')
            need(d['original_point_one_chart_satisfied'] is True,'Selected endpoint changed angle chart')
            geo=read(base.parent/'early-ending/selected-geometric.json')
            mixed=read(base.parent/'early-ending/selected-mixed.json')
            need(geo['verdict']=='PASS_EXACT_MIXED_SUPPORT_GEOMETRIC_PREMISES'
                 and geo['closed_envelope_contains_source_cover'] is True,'Missing geometric premise proof')
            need(geo['source_sha256']['input_pose_cover']==sha(base/'selected-prefix-reference.json'),
                 'Geometric predicates use different reference')
            need(mixed['verdict']=='PASS_MIXED_GLOBAL_ALIGNMENT','Missing mixed-support endpoint')
            return json_evidence(p,reference_sha256=sha(base/'selected-prefix-reference.json'),
                                 continuous_proof_parent='@mixed-support-proof')
        if kind=='label_specific_support':
            p=base/'fresh/compact-support-result.json'
            d=bound_receipt(p,'replay_compact_supports.py','PASS_FRESH_COMPACT_SUPPORT_INTERFACES')
            for label,h in d['checker_sha256'].items():
                need(label in pins['harnesses'] and sha(work/label)==h==pins['harnesses'][label], 'Changed compact checker')
            for label,h in d['outputs'].items():need(sha(p.parent/label)==h,'Changed compact predicate output')
            return json_evidence(p,owner=node['owner'],continuous_proof_parent='@strip-support')
        if kind=='exact_geometric_predicate':
            return predicate('boxes','PASS_FRESH_FIRST_CORNER_COARSE_BOUNDS') if id=='@corner-coarse-boxes' else predicate('axes','PASS_FRESH_SECOND_CORNER_AXES')
        if kind in ('journal_prefix','journal_exclusion'):
            if node['original_checker']=='exact_obstruction_journal.py':
                return predicate('top-obstruction','PASS_FRESH_TOP_OBSTRUCTION_EXCLUSION')
            if node['input_geometry'] is None or node['candidate_journal'].startswith(('exploration/direct-','exploration/persistent-')):
                return root_journal(node)
            return persistent(node)
        return own_interface(node)

    for id in graph['topological_order']:
        n=graph['nodes'][id]
        try:
            for item in n['artifacts']:need(sha(source/item['path'])==item['sha256'],'Graph artifact changed')
            ev=rule(n);evidence[id]=ev;own=True
        except (OSError,ValueError,KeyError,StopIteration,TypeError) as exc:
            own=False;errors[id]=str(exc)
        missing=[p for p in n['parents'] if not status[p]['accepted']]
        status[id]={'own_rule_validated':own,'accepted':own and not missing,'unaccepted_parents':missing}
    closed=status[graph['target']]['accepted']
    result={'verdict':'PASS_FRESH_CASE6_ANCESTRY_CLOSED' if closed else 'OPEN_FRESH_CASE6_ANCESTRY',
            'target':graph['target'],'graph_closed':closed,'accepted_nodes':sum(x['accepted'] for x in status.values()),
            'own_rules_validated':sum(x['own_rule_validated'] for x in status.values()),'total_nodes':len(status),
            'node_status':status,'validated_evidence':evidence,'missing_or_invalid_rule_evidence':errors,
            'graph_sha256':sha(base/'acceptance-graph.json'),'harness_pins_sha256':sha(base/'reviewed-harnesses.json'),
            'mathematical_lemma_pins_sha256':sha(base/'mathematical-lemmas.json'),'assembler_sha256':sha(__file__),
            'trust_model':'Ordinary displayed mathematical lemmas plus recorded fresh exact-rational Python executions under reviewed SHA-pinned harnesses. This assembler does not execute those computations again and is not a Lean proof.',
            'scope':'Surviving ownership case6 through the five-round mixed-support endpoint. Other ownership exclusions and the assembly for all configurations remain separate.'}
    (base/'acceptance-status.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['verdict'],result['accepted_nodes'],'transitively accepted;',result['own_rules_validated'],'rules validated of',len(status))
    if a.require_complete and not closed:raise SystemExit(1)

if __name__=='__main__':main()
