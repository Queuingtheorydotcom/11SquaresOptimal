#!/usr/bin/env python3
"""Fresh exact, inexpensive ancestry interfaces; never writes the archive.

These are conditional producer checks, not an assertion of global ancestry.
No archived verdict, timestamp, or ancestry flag is used as a proof premise.
"""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
from fractions import Fraction as F
import argparse, contextlib, hashlib, io, json, time

def need(p, message):
    if not p:
        raise ValueError(message)

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

FIELDS = ('case', 'bins', 'groups', 'hulls', 'owners', 'normalized_corners')

def main():
    need(__debug__, 'Python -O is forbidden')
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--snapshot', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    need(not output.is_relative_to(source), 'Output is inside immutable source')
    output.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(source))
    from marker_cases import POINTS, S, A_LO, A_HI, all_cases, groups
    from exact_poses import clip, area2, contains
    from forced_markers import hull
    from exact_persistent_journal import bounds
    from exact_rectangle_cores import rectangle_cores
    import verify_reduction
    started = time.monotonic()
    observed, results = {}, []

    def resolve(name):
        p = Path(name)
        if p.is_absolute():
            old = '/workspace/scratch/29ab83b81d6b/n11-global-proof/'
            need(str(p).startswith(old), 'Unknown absolute path: '+str(p))
            p = Path(str(p)[len(old):])
        q = (source/p).resolve()
        need(q.is_relative_to(source) and q.is_file(), 'Invalid input: '+str(p))
        return q

    def bind(p):
        p = Path(p)
        label = str(p.relative_to(source))
        digest = sha(p)
        need(label not in observed or observed[label] == digest, 'Changed input')
        observed[label] = digest
        return digest

    def read(name):
        p = resolve(name)
        bind(p)
        return json.loads(p.read_text())

    def record(name, parents, facts, artifact=None):
        item = {'id': name, 'status': 'FRESH_EXACT_INTERFACE_PASS',
                'premises_not_discharged_here': parents, 'facts': facts}
        if artifact:
            item['historical_output_artifact'] = artifact
            item['historical_output_sha256'] = bind(resolve(artifact))
        results.append(item)
        print(name, 'PASS', flush=True)

    # This script proves rational triangulation/boundary-polynomial and case
    # enumeration facts. Its geometrical covering lemmas remain explicit.
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        verify_reduction.main()
    reduction = json.loads(buf.getvalue())
    record('marker-root-arithmetic', ['mathematical nonavoidance lemmas',
           'marker ownership counting and dihedral symmetry lemma'], reduction)
    gs = [list(g) for g in groups(all_cases()[0][6])]
    need(gs == [[8,9],[0],[1],[2],[3],[4],[5],[6],[7],[10],[11]], 'Case labels')

    # Closed branch exclusions yield the OPEN remaining angle intervals.
    names = ['direct-low-N768', 'direct-middle-N768',
             'persistent-upper-corner-middle-N192']
    a, b, c = [read('exploration/'+p+'.json.assembled-exclusion.json') for p in names]
    need(a['branch_owner_index'] == b['branch_owner_index'] == 0, 'Angle owner')
    need(list(map(F,a['half_angle_interval'])) == [F(0),F(5,24)], 'Low cover')
    need(list(map(F,b['half_angle_interval'])) == [F(5,24),F(5,16)], 'Middle cover')
    cuts = {int(i):tuple(map(F,v)) for i,v in c['half_angle_intervals_by_owner'].items()}
    need(cuts == {0:(F(5,16),F(5,12)),3:(F(5,48),F(43,48))}, 'Joint cover')
    need((1+F(5,12))**2 > 2, 'Root upper cover')
    for d in (a,b,c):
        for stage in d['stages']:
            j = read(stage['journal'])
            need(j['case']==6 and j['groups']==gs and j['symmetry_restricted'], 'Branch context')
            N=j['bins']
            actual = {int(i):(F(lo,N),F(hi,N)) for i,lo,hi in j.get('cuts',[j.get('branch')])}
            expected = cuts if d is c else {0:tuple(map(F,d['half_angle_interval']))}
            need(actual==expected, 'Stage angle interval mismatch')
            if j.get('base'):
                need(bind(resolve(j['base']))==j['base_sha256'], 'Angle base mismatch')
    record('angle-complement-join', ['fresh closed exclusions of the ten named angle stages',
           'case6 symmetry: common-owner halfangle <= sqrt(2)-1'],
           {'G':'5/16 < t <= sqrt(2)-1', 'C2':'[0,5/48) union (43/48,1]',
            'closed_branch_intervals_recomputed_from_integer_bins':True})

    root_name='exploration/corner-global-root-N96.json'
    root=read(root_name)
    need(root['case']==6 and root['groups']==gs and root['base'] is None
         and root['branch']==[0,30,40] and root['bins']==96 and len(root['history'])==7,
         'Canonical root context')
    inherited={}
    for own,marker in [(3,2),(4,3)]:
        h=[tuple(map(F,p)) for p in root['history'][-1]['hulls'][own]]
        need(len(h)==7, 'Unexpected inherited corner hull')
        for x,y in h:
            need(S-A_LO<=y<=S, 'Inherited corner y')
            need(S-A_LO<=x<=S if own==3 else 0<=x<=A_LO, 'Inherited corner x')
        for i,(x,y) in enumerate(POINTS):
            inward=(S-x,S-y) if own==3 else (x,S-y)
            need(all(0<v<A_LO for v in inward) if i==marker else any(v>=A_HI for v in inward),
                 'Replacement marker ownership')
        inherited[str(own)]={'vertices':len(h),'contained_in_common_canonical_A_LO_rectangle':True,
                             'ownership_preserved_for_all_A_LO<a<A_HI':True}
    need(2*A_HI<S, 'Canonical corners intersect')
    # Numerical constants of the first support/separating-line proof.
    need(A_HI*A_HI/2<F(71,100)**2, 'Circumradius')
    need(F(43,25)-F(71,100)>A_HI and F(54,25)+F(71,100)<S-A_HI, 'Remote squares')
    need(F(26,25)-F(1,2)*F(2,25)==1<A_LO, 'Non-inward separator')
    need(1-F(2,25)**2>F(249,250)**2, 'Near vertical separator')
    need(F(249,250)*F(13,10)-F(2,25)>F(6,5), 'I3 support')
    need(F(11,10)>F(26,25), 'Support contradiction')
    record('normalization-inheritance', ['fresh seven-round root hull theorem',
           'first-corner coarse bounds and geometric support proof',
           'W2 obstruction exclusion and I2 inward separator proof'],
           {'owners':inherited,'corners_disjoint_for_entire_side_interval':True,
            'first_corner_proof_constants_checked':True,
            'containment_type':'closed; canonical wall vertices are not interior points',
            'cover_invariant':'regenerate after each existence-preserving replacement'})

    snapshot=json.loads(args.snapshot.read_text())
    for name in sorted(snapshot['nodes']):
        d=read(name)
        method=d.get('method')
        if method=='exact_spatial_branch_seed':
            parent=d['root']; base=read(parent); cut=d['spatial_cut']; owners=[]
            need(len(cut['inequalities'])==1, 'Relative-neighborhood branch premise')
            for own,ps in enumerate(base['owners']):
                out=[]
                for p in ps:
                    co,si=F(p['c']),F(p['s']); poly=[tuple(map(F,z)) for z in p['poly']]
                    if own==cut['owner']:
                        for nx,ny,z in cut['inequalities']:
                            nx,ny,z=F(nx),F(ny),F(z)
                            poly=clip(poly,(nx*co+ny*si,-nx*si+ny*co),z)
                    if area2(poly)>0:out.append({**p,'poly':[[str(x),str(y)] for x,y in poly]})
                owners.append(out)
            need(owners==d['owners'],'Fresh spatial clip mismatch '+name)
            need(all(d[k]==base[k] for k in FIELDS if k!='owners'),'Spatial inheritance '+name)
            record('spatial-clip:'+name,[parent,'relative-neighborhood clipping lemma'],
                   {'exact_geometric_equality':True,'cut':cut},name)
        elif method=='exact_two_corner_seed' and d.get('rectangle_core_parent'):
            parent=d['rectangle_core_parent']; base=read(parent)
            labels=[tuple(g) for g in base['groups']]
            hs={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(labels,base['hulls'])}
            poses=[]; dom=[]
            for owner in base['owners']:
                ids=set()
                for p in owner:
                    poly=[tuple(map(F,z)) for z in p['poly']]
                    ids.add(len(poses));poses.append({'k':p['k'],'c':F(p['c']),'s':F(p['s']),
                                                      'poly':poly,'own':bounds(poly)})
                dom.append(ids)
            hs,records=rectangle_cores(poses,dom,labels,hs,base['bins'])
            hh=[[[str(x),str(y)] for x,y in hs[g]] for g in labels]
            need(hh==d['hulls'] and records==d['rectangle_core_records'],'Rectangle cores '+name)
            need(all(base[k]==d[k] for k in FIELDS if k!='hulls'),'Rectangle inheritance')
            for owner,x,y in d.get('verified_points',[]):
                need(contains(hs[labels[int(owner)]],(F(x),F(y))),'Requested point')
            record('rectangle-cores:'+name,[parent,'rectangle core containment lemma'],
                   {'exact_geometric_equality':True,'records_equal':True},name)
        elif method=='exact_two_corner_seed' and d.get('unbounded_root'):
            parent=d['unbounded_root']; bp=d['global_spatial_bounds'];base=read(parent);br=read(bp)
            owners=[]
            for own,ps in enumerate(base['owners']):
                out=[]
                for p in ps:
                    co,si=F(p['c']),F(p['s']);poly=[tuple(map(F,z)) for z in p['poly']]
                    for b in br['necessary_halfplanes']:
                        if b['owner']==own:
                            need(b['strict'] is True,'Fresh bound requires strict conclusion')
                            nx,ny=map(F,b['normal']);poly=clip(poly,(nx*co+ny*si,-nx*si+ny*co),F(b['upper']))
                    if area2(poly)>0:out.append({**p,'poly':[[str(x),str(y)] for x,y in poly]})
                owners.append(out)
            need(owners==d['owners'],'Bound clipping mismatch '+name)
            need(all(d[k]==base[k] for k in FIELDS if k!='owners'),'Bound inheritance')
            record('global-bounds-clip:'+name,[parent,bp,'strict-bound relative-neighborhood lemma'],
                   {'exact_geometric_equality':True},name)
        elif method=='exact_two_corner_seed' and d.get('global_retained_parent'):
            parent=d['global_retained_parent'];base=read(parent)
            for nx,ny,z in base['spatial_cut']['inequalities']:
                need(F(nx)==F(ny)==0 and F(z)>=0,'Non-vacuous global promotion')
            need(all(d[k]==base[k] for k in FIELDS),'Global promotion mismatch '+name)
            record('vacuous-promotion:'+name,[parent],{'exact_geometric_equality':True},name)
        elif method=='exact_two_corner_seed':
            # Full pose regeneration is a separate (more expensive) producer.
            hs=[hull([tuple(map(F,p)) for p in h]) for h in root['history'][-1]['hulls']]
            for own in (3,4):
                xx=(S-A_LO,S) if own==3 else (F(0),A_LO)
                hs[own]=hull(hs[own]+[(x,y) for x in xx for y in (S-A_LO,S)])
            need(d['groups']==gs and d['hulls']==[[[str(x),str(y)] for x,y in h] for h in hs],
                 'Canonical seed inherited hull construction')
            record('canonical-seed-hulls:'+name,['normalization-inheritance'],
                   {'hulls_exactly_regenerated':True,'owner_pose_domains_not_replayed_here':True},name)
        elif 'necessary_halfplanes' in d:
            for b in d['necessary_halfplanes']:
                er=read(b['exclusion']); cut=er['spatial_cut']
                need(len(cut['inequalities'])==1 and cut['owner']==b['owner'],'Bound owner/cut')
                nx,ny,z=map(F,cut['inequalities'][0])
                need(list(map(F,b['normal']))==[-nx,-ny] and F(b['upper'])==-z and b['strict'] is True,
                     'Closed exclusion complement')
            record('closed-complement:'+name,[b['exclusion'] for b in d['necessary_halfplanes']],
                   {'strict_bounds':len(d['necessary_halfplanes']),
                    'conclusion':'all strict complements of excluded closed branches'},name)

    for mod in list(sys.modules.values()):
        f=getattr(mod,'__file__',None)
        if f and Path(f).suffix=='.py' and Path(f).resolve().is_relative_to(source):bind(Path(f).resolve())
    for p,h in observed.items():need(sha(source/p)==h,'Archive changed during checks')
    result={'verdict':'PASS_FRESH_CONDITIONAL_ANCESTRY_INTERFACES',
            'scope':'Root arithmetic and exact producer implications only. Expensive parent journals, normalization predicates, and original marker geometric lemmas are not freshly discharged here.',
            'checks':results,'source_inputs':observed,'harness_sha256':sha(__file__),
            'snapshot_sha256':sha(args.snapshot),'archive_files_verified_unchanged':len(observed),
            'seconds':time.monotonic()-started,'global_ancestry_complete':False}
    (output/'interface-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['verdict'],len(results),'checks',round(result['seconds'],3),'seconds',flush=True)

if __name__=='__main__':
    main()
