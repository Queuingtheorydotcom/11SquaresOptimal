#!/usr/bin/env python3
"""Freshly re-run both compact support interfaces without changing old outputs."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,hashlib,importlib.util,json,subprocess

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    if not __debug__:raise RuntimeError('Python -O forbidden')
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    source=a.source.resolve();out=a.output.resolve()
    if out.is_relative_to(source):raise ValueError('Output in archive')
    out.mkdir(parents=True,exist_ok=True)
    work=Path(__file__).resolve().parents[3]
    column=work/'global-simplification/separators/check_compact_envelopes.py'
    bottom=work/'paper-simplification/separators/check_bottom_row_envelope.py'
    subprocess.run([sys.executable,'-B',str(column),'--source',str(source),'--output',str(out/'compact-column.json')],check=True)
    spec=importlib.util.spec_from_file_location('fresh_compact_bottom',bottom)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.BASE=source;module.SOURCE=source/'exploration/virtual-column-global-N192-certified-seed.json';module.OUT=out/'compact-bottom.json'
    module.main()
    c=json.loads((out/'compact-column.json').read_text());b=json.loads((out/'compact-bottom.json').read_text())
    inputs={**c['source_hashes'],b['source']:b['source_sha256']}
    for name,h in inputs.items():
        if sha(source/name)!=h:raise ValueError('Source changed '+name)
    result={'verdict':'PASS_FRESH_COMPACT_SUPPORT_INTERFACES','harness_sha256':sha(__file__),
            'checker_sha256':{str(column.relative_to(work)):sha(column),str(bottom.relative_to(work)):sha(bottom)},
            'source_inputs':inputs,
            'outputs':{n:sha(out/n) for n in ['compact-column.json','compact-bottom.json']},
            'scope':'Exact envelope and scalar predicates only; accepted pose covers and continuous separator/strip proofs remain typed parent premises.'}
    (out/'compact-support-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['verdict'])
if __name__=='__main__':main()
