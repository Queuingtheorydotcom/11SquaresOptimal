"""Fail-closed composition of six freshly produced ownership-case receipts.

No pose replay is performed here. The outer runner must execute every
checker into fresh output locations before invoking this acceptance step.
This step validates input/code hashes, complete ancestry record structure,
and the mandatory terminal contradiction for each of cases 0 through 5.
"""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Do not run with Python -O')
HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
MODULES = ['marker_cases.py', 'forced_markers.py', 'exact_poses.py',
           'exact_arc_hulls.py', 'exact_pair_regions.py']
JOURNALS = {
    0: 'exploration/journal-case-0-N96.json',
    1: 'exploration/regions-case-1-from-initial-N96.json',
    2: 'exploration/regions-case-2-N384.json',
    4: 'exploration/arc-case-4-from-initial-N96.json',
}
BASE2 = 'exploration/regions-case-2-from-initial-N96.json'
POINT_COUNTS = {0: 794, 1: 170, 2: 643, 4: 356}
RECORD_COUNTS = {0: 142, 1: 4, 2: 16, 4: 8}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def bind_map(record, paths):
    require(set(record) == set(paths), 'Missing or unexpected hash-bound input')
    for name, path in paths.items():
        require(record[name] == sha(path), 'Hash mismatch: '+str(path))


def parsed_hulls(data, gs, round_index):
    return {g: hull([tuple(map(F, p)) for p in points])
            for g, points in zip(gs, data['history'][round_index]['hulls'])}


def initial(gs):
    return {g: hull(owned_points(g)) for g in gs}


def owner_records(records, targets):
    require(len(records) == len(targets), 'Wrong owner-check count')
    for record, (group, points) in zip(records, targets):
        require(record['group'] == list(group), 'Owner-check label mismatch')
        require(type(record['points']) is int and record['points'] == points, 'Wrong promoted-point count')
        require(type(record['poses']) is int and record['poses'] >= 0, 'Invalid pose count')


def geometry_header(data, case):
    gs = groups(all_cases()[0][case])
    require(data['case'] == case and data['groups'] == [list(g) for g in gs], 'Wrong ownership case')
    require(not data.get('branch'), 'Unexpected spatial branch')
    return gs


def arc_records(records, data, gs, hs, terminal):
    require(len(records) == len(data['history'])+int(terminal), 'Incomplete arc ancestry')
    promoted = 0
    for index, record in enumerate(records):
        require(record['round'] == index, 'Arc rounds out of order')
        for key in ('initial', 'active'):
            require(len(record[key]) == len(gs) and all(type(n) is int and n >= 0 for n in record[key]), 'Malformed owner domains')
        if index < len(data['history']):
            require(all(record['active']), 'Promotion from an already empty domain')
            new = parsed_hulls(data, gs, index)
            count = sum(not contains(hs[g], p) for g in gs for p in new[g])
            require(record['checked_new_vertices'] == count, 'Arc promotion does not match journal')
            promoted += count
            hs = new
        else:
            require(0 in record['active'], 'Missing empty-domain terminal')
            require('checked_new_vertices' not in record, 'Terminal mislabeled as a promotion')
    return promoted


def other_case(case, args):
    result_path = args.other_results_dir/f'case{case}-fresh-replay.json'
    result = read(result_path)
    require(result['status'] == 'FRESH EXACT CASE EXCLUSION FROM INITIAL MARKER HULLS' and result['case'] == case, 'Missing fresh case verdict')
    require(result['source_journal'] == JOURNALS[case], 'Wrong source journal')
    input_names = MODULES+list(JOURNALS.values())+[BASE2]
    paths = {name: args.source/name for name in input_names}
    bind_map(result['source_sha256'], paths)
    snapshot = args.other_results_dir/'selected_source'
    for name, digest in result['source_sha256'].items():
        require(sha(snapshot/name) == digest, 'Changed replay snapshot input')
    require(result['wrapper_sha256'] == sha(args.other_checker), 'Changed ownership replay harness')
    name = JOURNALS[case]+'.verified-exclusion.json'
    fresh_paths = {name: snapshot/name}
    if case == 2:
        name2 = BASE2+'.verified-prefix.json'
        fresh_paths[name2] = snapshot/name2
    bind_map(result['fresh_receipt_sha256'], fresh_paths)
    verdict = read(fresh_paths[name])
    data = read(args.source/JOURNALS[case])
    gs = geometry_header(data, case)
    require(verdict['verdict'] == 'VERIFIED CASE EXCLUSION' and verdict['case'] == case, 'Conditional or wrong terminal verdict')
    require(not verdict.get('branch') and not verdict.get('base_assumed'), 'Conditional ownership case cannot be accepted')
    require(verdict['journal_sha256'] == sha(args.source/JOURNALS[case]), 'Terminal bound to wrong journal')
    checks = verdict['checks']
    count = 0
    record_count = len(checks)
    if case == 0:
        require(data['bins'] == 96 and len(data['history']) == 14 and data['symmetry_restricted'], 'Wrong case-0 scope')
        require(verdict['terminal_group'] == [9] and verdict['rounds'] == 14 and verdict['symmetry_restricted'], 'Wrong case-0 terminal')
        require(result['terminal'] == {'kind': 'empty_owner_pose_cover', 'source_record': {'owner': [9], 'poses': 0}}, 'Missing case-0 empty-domain record')
        hs = initial(gs)
        expected = []
        for r in range(len(data['history'])):
            new = parsed_hulls(data, gs, r)
            for g in gs:
                added = sum(not contains(hs[g], p) for p in new[g])
                if added:
                    expected.append((r, g, added))
                    count += added
            hs = new
        owner_records(checks, [(g, n) for _, g, n in expected])
        require([c['round'] for c in checks] == [r for r, _, _ in expected], 'Incomplete case-0 round ancestry')
    else:
        hs = initial(gs)
        require(data['symmetry_restricted'] and data['bins'] == (384 if case == 2 else 96), 'Wrong arc-case scope')
        if case == 2:
            base_data = read(args.source/BASE2)
            base = read(snapshot/(BASE2+'.verified-prefix.json'))
            require(data['base'] == BASE2 and data['base_sha256'] == sha(args.source/BASE2), 'Wrong case-2 base link')
            require(verdict['base_sha256'] == sha(args.source/BASE2) == base['journal_sha256'], 'Unbound fresh case-2 base')
            require(not base.get('base_assumed') and not base_data.get('base') and not base_data.get('terminal'), 'Case-2 base not initial and unconditioned')
            require(base['completed_round'] == len(base_data['history'])-1 == 13, 'Incomplete case-2 base')
            require(geometry_header(base_data, case) == gs and base_data['bins'] == 96 and base_data['symmetry_restricted'], 'Wrong case-2 base scope')
            count += arc_records(base['checks'], base_data, gs, hs, False)
            record_count += len(base['checks'])
            hs = parsed_hulls(base_data, gs, len(base_data['history'])-1)
        else:
            require(not data.get('base') and not verdict.get('base_sha256'), 'Unexpected inherited base')
        count += arc_records(checks, data, gs, hs, True)
        require(result['terminal']['kind'] == 'empty_owner_domain_after_necessary_pair_pruning' and result['terminal']['source_record'] == checks[-1], 'Terminal summary does not bind checked record')
    require(count == result['promotion_points'] == POINT_COUNTS[case], 'Wrong complete promotion total')
    require(record_count == result['recorded_check_count'] == RECORD_COUNTS[case], 'Wrong complete check total')
    return {'case': case, 'receipt_sha256': sha(result_path), 'promoted_points': count,
            'terminal': 'empty_owner_domain', 'source_journal_sha256': sha(args.source/JOURNALS[case])}


def case3(args):
    result = read(args.case3)
    require(result['status'] == 'PASS: SHORTENED CASE-3 EXCLUSION FROM SOURCE INITIAL OWNED POINTS', 'Missing shortened case-3 verdict')
    require(result['case'] == all_cases()[0][3] and result['angle_bins'] == 96 and result['container_side'] == '97/25' and result['square_side_open_interval'] == ['4003/4000', '25019/25000'], 'Wrong case-3 scope')
    journal_name = 'exploration/journal-case-3-N96.json'
    paths = {n: args.source/n for n in MODULES[:3]+[journal_name]}
    paths['replay_compact.py'] = args.case3_checker
    bind_map(result['source_sha256'], paths)
    data = read(args.source/journal_name)
    gs = geometry_header(data, 3)
    require(result['groups'] == [list(g) for g in gs] and len(result['stages']) == 2, 'Wrong case-3 stages')
    hs = initial(gs)
    targets = [((0, 4), (8,), (9,), (10,), (11,)), ((2,), (8,), (10,), (11,))]
    counts = []
    for r, owners in enumerate(targets):
        stage = result['stages'][r]
        require(stage['stage'] == r and set(stage['promoted_hulls']) == {str(g) for g in owners}, 'Wrong case-3 promoted owners')
        new = parsed_hulls(data, gs, r)
        for g in owners:
            require([tuple(map(F, p)) for p in stage['promoted_hulls'][str(g)]] == new[g], 'Case-3 hull differs from bound journal')
        expected = [(g, sum(not contains(hs[g], p) for p in new[g])) for g in owners]
        owner_records(stage['checks'], expected)
        counts.extend(n for _, n in expected)
        hs.update({g: new[g] for g in owners})
    terminal = result['terminal']
    require(list(map(F, terminal['point'])) == [F(49, 25), F(73, 25)] and terminal['distinct_owners'] == [[11], [6]], 'Wrong case-3 common-point terminal')
    owner_records(terminal['checks'], [((11,), 1), ((6,), 1)])
    require(sum(counts)+2 == result['new_point_count'] == 62 and len(counts)+2 == result['owner_checks'] == 11, 'Wrong case-3 totals')
    return {'case': 3, 'receipt_sha256': sha(args.case3), 'promoted_points': 62,
            'terminal': 'common_point', 'point': ['49/25', '73/25']}


def case5(args):
    result, plan = read(args.case5), read(args.case5_plan)
    require(result['status'] == 'PASS: SHORTENED OWNERSHIP CASE EXCLUSION FROM SOURCE INITIAL PREMISES' and result['case'] == 5, 'Missing shortened case-5 verdict')
    require(result['container'] == '97/25' and result['side_interval_open'] == ['4003/4000', '25019/25000'] and result['symmetry_limits'] is None, 'Wrong case-5 scope')
    journal_name = 'exploration/journal-case-5-N96.json'
    paths = {n: args.source/n for n in MODULES[:3]+[journal_name]}
    paths.update({'sparse_chain.py': args.case5_checker, 'case5-plan.json': args.case5_plan})
    bind_map(result['source_sha256'], paths)
    require(plan['schema'] == 'sparse-ownership-chain-v1' and plan['case'] == 5 and plan['bins'] == 96 and plan['journal_sha256'] == sha(args.source/journal_name), 'Wrong case-5 plan')
    require(len(result['records']) == len(plan['steps']) == 5, 'Incomplete case-5 plan')
    data = read(args.source/journal_name)
    gs = geometry_header(data, 5)
    init, known, counts = initial(gs), set(), []
    for index, (record, step) in enumerate(zip(result['records'], plan['steps'])):
        require(record['step'] == step, 'Case-5 receipt differs from selected plan')
        r = step['premise_round']
        owners = [tuple(g) for g in step['premise_owners']]
        require(all(g in gs for g in owners), 'Unknown premise owner')
        require((r == -1 and not owners) or (0 <= r < len(data['history']) and all((r, g) in known for g in owners)), 'Unproved case-5 ancestry')
        prior = parsed_hulls(data, gs, r) if r >= 0 else init
        hs = {g: prior[g] if g in owners else init[g] for g in gs}
        target = step['conclusion']
        target_owners = [tuple(g) for g in target['owners']]
        require(len(set(target_owners)) == len(target_owners) and all(g in gs for g in target_owners), 'Malformed target owners')
        if index < 4:
            require(target['kind'] == 'hulls' and target['round'] == index, 'Wrong case-5 promotion stage')
            new = parsed_hulls(data, gs, index)
            expected = [(g, sum(not contains(hs[g], p) for p in new[g])) for g in target_owners]
            expected = [(g, n) for g, n in expected if n]
            known.update((index, g) for g in target_owners)
        else:
            require(target['kind'] == 'common_point' and target_owners == [(10,), (5,)] and list(map(F, target['point'])) == [F(29, 10), F(5, 2)], 'Wrong case-5 terminal')
            expected = [(g, 1) for g in target_owners]
        owner_records(record['checks'], expected)
        counts.extend(n for _, n in expected)
    require(sum(counts) == result['new_point_count'] == 170 and len(counts) == result['owner_checks'] == 32, 'Wrong case-5 totals')
    return {'case': 5, 'receipt_sha256': sha(args.case5), 'promoted_points': 170,
            'terminal': 'common_point', 'point': ['29/10', '5/2']}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--case3', type=Path, required=True)
    ap.add_argument('--case5', type=Path, required=True)
    ap.add_argument('--other-results-dir', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--case3-checker', type=Path, default=WORK/'global-simplification/kernels/replay_compact.py')
    ap.add_argument('--case5-checker', type=Path, default=WORK/'paper-simplification/exclusions/sparse_chain.py')
    ap.add_argument('--case5-plan', type=Path, default=WORK/'paper-simplification/exclusions/case5-plan.json')
    ap.add_argument('--other-checker', type=Path)
    args = ap.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    args.other_checker = args.other_checker or args.other_results_dir/'replay_remaining.py'
    require(not args.output.is_relative_to(args.source), 'Output must remain outside source')
    sys.path.insert(0, str(args.source))
    global groups, all_cases, hull, owned_points, contains
    from marker_cases import groups, all_cases, A_LO, A_HI, S
    from forced_markers import hull, owned_points
    from exact_poses import contains
    require((S, A_LO, A_HI) == (F(97, 25), F(4003, 4000), F(25019, 25000)), 'Wrong normalized interval')
    records = [other_case(c, args) for c in (0, 1, 2, 4)] + [case3(args), case5(args)]
    records.sort(key=lambda r: r['case'])
    require([r['case'] for r in records] == list(range(6)), 'Not all six required cases accepted')
    result = {'status': 'PASS: SIX OWNERSHIP EXCLUSIONS WITH BOUND ANCESTRY',
              'scope': 'Receipt composition only: every case 0 through 5 has the complete expected hash-bound ancestry and a mandatory terminal contradiction. Freshness requires the outer runner to have just executed every bound checker into fresh output locations. Marker foundation, initial hull and symmetry lemmas, opposite-inner case, surviving case 6, and the attaining construction are outside this result.',
              'container': '97/25', 'side_interval_open': ['4003/4000', '25019/25000'],
              'cases': records, 'acceptance_checker_sha256': sha(Path(__file__))}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(result['status'], flush=True)


if __name__ == '__main__':
    main()
