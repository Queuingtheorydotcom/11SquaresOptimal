#!/usr/bin/env python3
"""Run unchanged finite ending checks on a semantically matched reference.

Fresh propagation metadata may differ after relocation. Only exact geometry
identifies the fixed reference to which the readable envelope is attached.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,importlib.util,json

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not ok:raise ValueError(msg)
def main():
    need(__debug__,'Python -O forbidden')
    freshdir=HERE.parent/'capture/fresh';result=freshdir/'result.json'
    origin=json.loads(result.read_text());need(origin['verdict']=='PASS_FRESH_N384_CONDITIONAL_REPLAY','Fresh propagation missing')
    entry=next(x for x in origin['states'] if x['prefix']==5)
    actual=freshdir/entry['file'];need(sha(actual)==entry['sha256'],'Fresh prefix changed')
    reference=HERE/'selected-prefix-reference.json'
    a=json.loads(actual.read_text());b=json.loads(reference.read_text())
    for k in ('case','bins','groups','hulls','owners','normalized_corners','spatial_cut'):
        need(a[k]==b[k],'Fresh/reference geometry mismatch '+k)
    ending=HERE.parent/'early-ending';binding=ending/'portable-replay-binding.json'
    record={'states':[{'prefix':5,'file':'../ancestry/selected-prefix-reference.json',
              'sha256':sha(reference),'counts':[len(o) for o in b['owners']]}],
            'fresh_result_sha256':sha(result),'fresh_prefix_sha256':sha(actual),
            'selected_reference_sha256':sha(reference),'adapter_sha256':sha(__file__),
            'comparison':'EXACT_EQUALITY_OF_ALL_GEOMETRIC_FIELDS; provenance metadata excluded',
            'scope':'This binds a checked geometric reference; global parent validity is assembled separately.'}
    binding.write_text(json.dumps(record,indent=2)+'\n')
    checker=ending/'check_selected_prefix.py'
    spec=importlib.util.spec_from_file_location('selected_ending',checker)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    # Only data paths/binding metadata change. All finite geometric, interval,
    # support, and scalar assertions run unchanged in the reviewed checker.
    module.PREFIX=reference;module.PREFIX_SHA=sha(reference);module.REPLAY=binding
    module.main()
    print('PASS_PORTABLE_SEMANTIC_REFERENCE_BINDING')
if __name__=='__main__':main()
