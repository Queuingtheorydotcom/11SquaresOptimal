#!/usr/bin/env python3
"""Regenerate canonical, obstruction, and all selected refinement domains.

No geometric truth is inferred from archived PASS/ancestry fields. Each fresh
transition is conditional on its explicit parent geometry and mathematical
rule; exact equality binds the resulting geometry to downstream archived data.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,time

def need(ok,msg):
    if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    need(__debug__,'Python -O forbidden')
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--snapshot',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();source=args.source.resolve();out=args.output.resolve()
    need(not out.is_relative_to(source),'Output inside source');out.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(source))
    from marker_cases import S,A_LO,groups,all_cases
    from forced_markers import hull
    from exact_poses import clip,area2
    from exact_persistent_journal import bounds,cut_and_round
    from retained_spatial_state import serialize
    from two_corner_seed import owner_task
    from corner_obstruction_seed import constrained_owner
    observed={};checks=[];start=time.monotonic()
    def read(name):
        p=(source/name).resolve();need(p.is_relative_to(source),'Escaped path')
        h=sha(p);need(name not in observed or observed[name]==h,'Input changed')
        observed[name]=h;return json.loads(p.read_text())
    def emit(name,parents,facts):
        checks.append({'artifact':name,'sha256':observed[name],
            'verdict':'PASS_FRESH_CONDITIONAL_DOMAIN_PRODUCER',
            'premise_artifacts_not_discharged_here':parents,'facts':facts})
        print(name,'PASS',round(time.monotonic()-start,2),flush=True)
        (out/'domain-prefix.json').write_text(json.dumps({'checks':checks,'source_inputs':observed},indent=2)+'\n')

    root_name='exploration/corner-global-root-N96.json';root=read(root_name)
    need(root['case']==6 and root['bins']==96 and root['branch']==[0,30,40]
         and root['base'] is None and len(root['history'])==7,'Wrong root')
    gs=groups(all_cases()[0][6]);need([list(g) for g in gs]==root['groups'],'Root labels')
    base={g:hull([tuple(map(F,p)) for p in h]) for g,h in zip(gs,root['history'][-1]['hulls'])}
    names=['exploration/two-corner-global-certified-seed.json',
           'exploration/top-obstruction-certified-seed.json',
           'exploration/inner-obstruction-certified-seed.json']
    for name in names:
        d=read(name);N=d['bins'];need(N%48==0 and d['groups']==root['groups'],'Seed context')
        hs={g:list(h) for g,h in base.items()}
        normalized=[3,4] if d['method']=='exact_two_corner_seed' else [4]
        for own in normalized:
            xx=(S-A_LO,S) if own==3 else (F(0),A_LO)
            hs[gs[own]]=hull(hs[gs[own]]+[(x,y) for x in xx for y in (S-A_LO,S)])
        need(d['hulls']==[[[str(x),str(y)] for x,y in hs[g]] for g in gs],'Inherited hulls')
        owners=[]
        for own in range(11):
            print('START',name,'owner',own,flush=True)
            if normalized==[3,4]:fresh=owner_task((own,N,gs,hs))
            else:fresh=constrained_owner((own,N,gs,hs,d['obstructor']))
            need(fresh==d['owners'][own],'Owner domain geometry mismatch '+name+' '+str(own))
            owners.append(fresh)
        emit(name,[root_name,'angle-complement theorem','existence-preserving corner normalization'],
             {'all_owner_pose_domains_exact_equal':True,'owner_counts':[len(x) for x in owners],
              'compulsory_hulls_exact_equal':True,
              'condition':None if normalized==[3,4] else 'owner '+str(d['obstructor'])+' intersects proposed canonical C2 square'})

    snapshot=json.loads(args.snapshot.read_text())
    for name,node in sorted(snapshot['nodes'].items()):
        if node.get('method')!='exact_refined_spatial_seed':continue
        d=read(name);parent=d['parent_seed'];base=read(parent)
        need(d['case']==base['case']==6 and d['normalized_corners']==base['normalized_corners']==[3,4],
             'Refinement context')
        R=d['bins']//base['bins'];N=d['bins'];need(R>=2 and R*base['bins']==N,'Refinement factor')
        pp=[];dd=[]
        for owner in base['owners']:
            ids=[]
            for p in owner:
                ids.append(len(pp));pp.append({'k':p['k'],'c':F(p['c']),'s':F(p['s']),
                                               'poly':[tuple(map(F,z)) for z in p['poly']]})
            dd.append(ids)
        poses=[];dom=[]
        for own,ids in enumerate(dd):
            new=set()
            for i in ids:
                p=pp[i];C,T=p['c'],p['s']
                for k in range(p['k']*R,(p['k']+1)*R):
                    if own in (3,4) and k!=0:continue
                    t=F(2*k+1,2*N);co=(1-t*t)/(1+t*t);si=2*t/(1+t*t)
                    c=co*C+si*T;s=-si*C+co*T
                    need(c*c+s*s==1,'Non-isometric frame change')
                    poly=[(c*x-s*y,s*x+c*y) for x,y in p['poly']]
                    w=lambda z:(1+2*z-z*z)/(1+z*z)
                    wall=A_LO*min(w(F(k,N)),w(F(k+1,N)))/2
                    for normal,b in [((co,-si),S-wall),((-co,si),-wall),((si,co),S-wall),((-si,-co),-wall)]:
                        poly=clip(poly,normal,b)
                    if area2(poly)>0:
                        new.add(len(poses));poses.append({'k':k,'c':co,'s':si,'poly':poly,'own':bounds(poly)})
            dom.append(new)
        labels=[tuple(g) for g in base['groups']]
        hs={g:[tuple(map(F,p)) for p in h] for g,h in zip(labels,base['hulls'])}
        poses,dom=cut_and_round(poses,dom,labels,hs,N,10**8)
        need(serialize(poses,dom)==d['owners'],'Refinement owner geometry mismatch '+name)
        need(all(d[k]==base[k] for k in ('case','normalized_corners','groups','hulls','spatial_cut')),
             'Refinement inherited field mismatch')
        emit(name,[parent,'relative-neighborhood and closed angle cover lemmas'],
             {'factor':R,'denominator':10**8,'all_owner_pose_domains_exact_equal':True,
              'inherited_fields_exact_equal':True,'owner_counts':[len(x) for x in dom]})
    for mod in list(sys.modules.values()):
        p=getattr(mod,'__file__',None)
        if p and Path(p).suffix=='.py' and Path(p).resolve().is_relative_to(source):
            p=Path(p).resolve();observed[str(p.relative_to(source))]=sha(p)
    for p,h in observed.items():need(sha(source/p)==h,'Input changed '+p)
    result={'verdict':'PASS_ALL_SELECTED_DOMAIN_PRODUCERS','checks':checks,'source_inputs':observed,
            'seconds':time.monotonic()-start,'harness_sha256':sha(__file__),
            'snapshot_sha256':sha(args.snapshot),'global_ancestry_complete':False,
            'scope':'Fresh exact conditional transitions, not acceptance of parent journal/normalization premises.'}
    (out/'domain-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['verdict'],len(checks),round(result['seconds'],2),flush=True)

if __name__=='__main__':main()
