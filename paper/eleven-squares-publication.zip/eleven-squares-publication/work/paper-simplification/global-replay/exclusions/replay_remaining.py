"""Fresh exact ownership-case replays in an isolated selected-file copy.

No historical receipts are copied into the working tree or used as premises.
Source modules and journals are copied byte-for-byte, then source checkers
write new receipts only beside the isolated copies. Historical semantic
comparisons are performed only after the fresh exact replay has succeeded.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Do not run with Python -O')
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[2] / 'shared-final/n11-global-proof'
SNAPSHOT = HERE / 'selected_source'
MODULES = ['marker_cases.py', 'forced_markers.py', 'exact_poses.py',
           'exact_arc_hulls.py', 'exact_pair_regions.py']
JOURNALS = {
    0: 'journal-case-0-N96.json',
    1: 'regions-case-1-from-initial-N96.json',
    2: 'regions-case-2-N384.json',
    4: 'arc-case-4-from-initial-N96.json',
}
BASE2 = 'regions-case-2-from-initial-N96.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def semantics(value):
    if isinstance(value, dict):
        return {k: semantics(v) for k, v in value.items() if k != 'seconds'}
    if isinstance(value, list):
        return [semantics(v) for v in value]
    return value


def prepare():
    paths = MODULES + ['exploration/'+n for n in list(JOURNALS.values())+[BASE2]]
    hashes = {}
    for name in paths:
        original = SOURCE / name
        copied = SNAPSHOT / name
        raw = original.read_bytes()
        hashes[name] = hashlib.sha256(raw).hexdigest()
        copied.parent.mkdir(parents=True, exist_ok=True)
        if copied.exists():
            assert copied.read_bytes() == raw, ('Changed local input', name)
        else:
            copied.write_bytes(raw)
    return hashes


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--case', type=int, choices=JOURNALS, required=True)
    ap.add_argument('--jobs', type=int, default=4)
    args = ap.parse_args()
    assert 1 <= args.jobs <= 4
    start = time.monotonic()
    hashes = prepare()
    journal = SNAPSHOT / 'exploration' / JOURNALS[args.case]
    result_path = HERE / f'case{args.case}-fresh-replay.json'
    if result_path.exists():
        raise FileExistsError('Existing accepted result: choose an explicit new replay location before repeating.')
    terminal_path = Path(str(journal)+'.verified-exclusion.json')
    assert not terminal_path.exists(), 'No old terminal receipt may be present before this fresh run.'
    if args.case == 2:
        assert not Path(str(SNAPSHOT/'exploration'/BASE2)+'.verified-prefix.json').exists(), 'Case 2 base must be reconstructed freshly in this run.'
    checker = 'exact_poses.py' if args.case == 0 else 'exact_arc_hulls.py'
    command = [sys.executable, '-B', checker, 'exploration/'+JOURNALS[args.case], '--jobs', str(args.jobs)]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0')
    print(json.dumps({'event': 'fresh replay started', 'case': args.case, 'command': command,
                      'source_inputs': len(hashes), 'historical_receipts_used_as_premises': 0}), flush=True)
    subprocess.run(command, cwd=SNAPSHOT, env=env, check=True)
    assert terminal_path.exists(), 'Fresh terminal verdict was not produced'
    verdict = json.loads(terminal_path.read_bytes())
    assert verdict['verdict'] == 'VERIFIED CASE EXCLUSION'
    assert verdict['case'] == args.case
    assert verdict['journal_sha256'] == sha(journal)
    assert not verdict.get('branch') and not verdict.get('base_assumed')
    for name, digest in hashes.items():
        assert sha(SOURCE/name) == digest, ('Original source changed during replay', name)
        assert sha(SNAPSHOT/name) == digest, ('Local source changed during replay', name)
    checks = verdict['checks']
    historical_name = JOURNALS[args.case]+('.verified-implication.json' if args.case == 2 else '.verified-exclusion.json')
    historical = json.loads((SOURCE/'exploration'/historical_name).read_bytes())
    # Case 2's historical continuation was explicitly an assumed-base check;
    # only its geometric checks are compared. The fresh run supplies the base.
    assert semantics(checks) == semantics(historical['checks']), 'Fresh geometric checks differ from the historical record.'
    receipts = {str(terminal_path.relative_to(SNAPSHOT)): sha(terminal_path)}
    base_count = 0
    base_check_count = 0
    if args.case == 2:
        base_path = SNAPSHOT/'exploration'/BASE2
        base_prefix = Path(str(base_path)+'.verified-prefix.json')
        base = json.loads(base_prefix.read_bytes())
        data = json.loads(base_path.read_bytes())
        assert base['journal_sha256'] == sha(base_path) == verdict['base_sha256']
        assert base['completed_round'] == len(data['history'])-1
        assert not base.get('base_assumed')
        old_base = json.loads((SOURCE/'exploration'/(BASE2+'.verified-prefix.json')).read_bytes())
        assert semantics(base['checks']) == semantics(old_base['checks'])
        base_count = sum(c.get('checked_new_vertices', 0) for c in base['checks'])
        base_check_count = len(base['checks'])
        receipts[str(base_prefix.relative_to(SNAPSHOT))] = sha(base_prefix)
    result = {
        'status': 'FRESH EXACT CASE EXCLUSION FROM INITIAL MARKER HULLS',
        'case': args.case,
        'scope': 'Fresh execution of the source rational geometry checks and terminal contradiction, conditional on the initial marker ownership foundation, applicable symmetry normalization, and mathematical soundness of the source enclosure/pruning rules. No saved PASS record was used as a premise. No other case or global capture is asserted.',
        'source_journal': 'exploration/'+JOURNALS[args.case],
        'source_sha256': hashes,
        'wrapper_sha256': sha(Path(__file__)),
        'fresh_receipt_sha256': receipts,
        'historical_semantic_comparison': 'All fresh geometric checks match historical checks after removing elapsed seconds; comparison occurred after acceptance.',
        'terminal': {'kind': 'empty_owner_pose_cover' if args.case == 0 else 'empty_owner_domain_after_necessary_pair_pruning',
                     'source_record': checks[-1] if args.case else {'owner': verdict['terminal_group'], 'poses': 0}},
        'promotion_points': base_count + sum(c.get('points', c.get('checked_new_vertices', 0)) for c in checks),
        'recorded_check_count': base_check_count+len(checks),
        'elapsed_seconds': time.monotonic()-start,
    }
    result_path.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: result[k] for k in ('status', 'case', 'promotion_points', 'recorded_check_count', 'elapsed_seconds')}), flush=True)


if __name__ == '__main__':
    main()
