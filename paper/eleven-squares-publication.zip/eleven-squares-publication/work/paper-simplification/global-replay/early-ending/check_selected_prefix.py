#!/usr/bin/env python3
"""Fresh finite checks for the selected five-round ending of the global cover.

This replays the support/feature checks, not the upstream pose-cover journal.
The separate fresh journal replay and its input assumptions remain explicit.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import os
import subprocess
import time

if not __debug__:raise RuntimeError('Do not run with Python -O')
HERE=Path(__file__).resolve().parent
PREFIX=HERE.parent/'capture/fresh/states/prefix-05.json'
PREFIX_SHA='bfc0cc47c5752ba2e182174110182b785106450129af8f024ac88d7ab3e01ba4'
BOX=HERE/'prefix05-box-1000.json'
REPLAY=HERE.parent/'capture/fresh/result.json'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    started=time.monotonic()
    assert sha(PREFIX)==PREFIX_SHA
    # This binds the selected exported file to the independently executed
    # semantic replay. Its PASS flag is not used as a substitute for replay.
    origin=json.loads(REPLAY.read_text())
    entry=next(x for x in origin['states'] if x['prefix']==5)
    assert entry['sha256']==PREFIX_SHA
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    tasks=[('geometry','check_geometric_prefix.py',
            ['--seed',str(PREFIX),'--expected-seed-sha256',PREFIX_SHA,
             '--box',str(BOX),'--output',str(HERE/'selected-geometric.json')]),
           ('mixed','check_mixed_prefix.py',
            ['--seed',str(BOX),'--splits','4','--output',str(HERE/'selected-mixed.json')]),
           ('equalities','check_block_equalities_prefix.py',[])]
    for name,script,args in tasks:
        with (HERE/f'selected-{name}.log').open('w') as log:
            p=subprocess.run([sys.executable,str(HERE/script),*args],cwd=HERE,env=env,
                             stdout=log,stderr=subprocess.STDOUT)
        assert p.returncode==0,(name,(HERE/f'selected-{name}.log').read_text()[-2500:])
    geo=json.loads((HERE/'selected-geometric.json').read_text())
    mix=json.loads((HERE/'selected-mixed.json').read_text())
    eq=json.loads((HERE/'selected-block-equalities.json').read_text())
    assert geo['verdict']=='PASS_EXACT_MIXED_SUPPORT_GEOMETRIC_PREMISES'
    assert mix['verdict']=='PASS_MIXED_GLOBAL_ALIGNMENT'
    assert eq['verdict']=='PASS_SIX_SQUARE_EQUALITY_COROLLARY'
    assert mix['anchor_splits']==4 and len(mix['checks'])==4
    assert geo['source_sha256']['input_pose_cover']==PREFIX_SHA
    assert geo['source_sha256']['envelope']==sha(BOX)==mix['seed_sha256']
    assert all(F('-.1')<F(a)<=F(b)<F('.1') for a,b in mix['angle_offsets'].values())
    assert F(mix['angle_offsets']['F'][0])>=F('-.014')
    assert F(mix['angle_offsets']['F'][1])<=F('.021')
    beta=dict(zip(('AB','DE','BD','CD'),map(F,('1/10','1/20','7/100','1/10'))))
    gamma=dict(zip(('AB','DE','BD','CD'),map(F,('11/200','9/200','3/50','49/500'))))
    gains={k:beta[k]-gamma[k] for k in beta}
    assert list(gains.values())==list(map(F,('9/200','1/200','1/100','1/500')))
    constants=[]
    for index,part in enumerate(mix['checks']):
        for edge in beta:
            stage=part['stages'][edge]
            cap=F(stage['capacity']);deriv=max(abs(F(x)) for x in stage['derivative'])
            assert cap>=beta[edge] and deriv<=gamma[edge]
            constants.append({'anchor_interval':index,'edge':edge,
                              'capacity_slack':str(cap-beta[edge]),
                              'derivative_slack':str(gamma[edge]-deriv)})
        assert F(part['bridge_margin'])>F(3,20)
    assert F('.3127')<F(mix['mixture_weight_interval'][0])
    assert F(mix['mixture_weight_interval'][1])<F('.3128')
    bridge_gain_margin=F(3,40)*(1-F(21,1000)**2/6)-F(7,100)
    assert bridge_gain_margin>0
    files=[PREFIX,BOX,REPLAY,HERE/'check_geometric_prefix.py',HERE/'check_mixed_prefix.py',
           HERE/'prefix_angle_helpers.py',HERE/'check_block_equalities_prefix.py',Path(__file__),
           HERE/'selected-geometric.json',HERE/'selected-mixed.json',HERE/'selected-block-equalities.json']
    report={'verdict':'PASS_SELECTED_FIVE_ROUND_ENDING','prefix_rounds':5,'omitted_later_rounds':7,
            'readable_grid':1000,'anchor_intervals':4,
            'source_sha256':{str(p.relative_to(HERE.parent)) if p.is_relative_to(HERE.parent) else str(p):sha(p) for p in files},
            'fresh_replay_binding':entry,'beta':{k:str(v) for k,v in beta.items()},
            'derivative_upper':{k:str(v) for k,v in gamma.items()},
            'tree_stability_gains':{k:str(v) for k,v in gains.items()},
            'constant_checks':constants,'bridge_lower_bound':'3/20','bridge_stability_gain':'7/100',
            'bridge_gain_margin':str(bridge_gain_margin),'original_point_one_chart_satisfied':True,
            'seconds':time.monotonic()-started,
            'scope':'Fresh exact proof of the fifth-prefix enclosure in the displayed box, all selected geometric feature/sign/corner premises, mixed support bound, printed constants, and reference-block equalities. The separate fresh semantic prefix replay and its stated upstream marker/corner/virtual-obstacle assumptions remain explicit inputs; no unconditional global theorem is inferred merely from the input hash.'}
    (HERE/'selected-ending-result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['verdict'],round(report['seconds'],2),'seconds')


if __name__=='__main__':main()
