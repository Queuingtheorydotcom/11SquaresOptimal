#!/usr/bin/env python3
"""Exact geometric premise checks for the mixed support-cycle theorem.

The complete N=384 cover and the two virtual-obstacle theorems remain upstream
premises. This checker derives every selected separator family, wall formula,
angle-sign condition, and virtual-support formula needed from those premises.
No local-isolation theorem or LP capture certificate is read.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import argparse,hashlib,json,importlib.util

ROOT=Path(__file__).resolve().parents[4]
CORE=ROOT/'work/global-simplification/duals/check_global_interval_lp.py'
spec=importlib.util.spec_from_file_location('global_core',CORE)
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
I=g.I
SEED_SHA='1f283b174abec68ff57cd2b0195be9b6dd1c96a973894e1dd6e2387f33f5d6cb'
CORE_SHA='6557ccb055bf0de240a0eeaa53206b7ac8d28db347561824f1040494dcbdc23a'
OWN={'A':9,'B':7,'C':0,'D':10,'E':8,'F':1}
# Each signed feature is evaluated on global d=center_j-center_i, i<j.
EXPECTED={
 'AB':(7,9,{(7,1,-1),(9,1,-1)}),
 'AC':(0,9,{(0,0,1),(9,0,1)}),
 'BD':(7,10,{(7,0,-1),(10,0,-1)}),
 'DE':(8,10,{(8,0,1),(10,0,1)}),
 'CD':(0,10,{(0,1,1),(10,1,1)}),
 'Acorner':(3,9,{(9,0,-1)}),
 'Dcorner':(4,10,{(10,1,-1)}),
 'CF':(0,1,{(0,0,-1)}),
 'EF':(1,8,{(8,1,1)})}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def div(a,b):
 a=g.iv(a);b=g.iv(b);g.need(b.lo>0,'Nonpositive denominator')
 return a*I(1/b.hi,1/b.lo)
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,I):return [str(x.lo),str(x.hi)]
 if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,set)):return [enc(v) for v in x]
 return x

def normal_interval(phi,tilted):
 mid=phi.mid();rad=(phi.hi-phi.lo)/2;n=g.normal(mid,tilted)
 h=I(-rad,rad);error=I(-rad*rad/2,rad*rad/2)
 return tuple(x+y*h+error for x,y in zip(n,g.rot(n)))

def feature_checks(lo,hi,i,j):
 ref=[(a+b)/2 for a,b in zip(lo,hi)];r=[(b-a)/2 for a,b in zip(lo,hi)]
 ns=[g.normal(ref[3*k+2],k in g.TILTED) for k in range(11)]
 aa=ref[33];ra=r[33];dd=[ref[3*j+k]-ref[3*i+k] for k in range(2)]
 dR=sum(r[3*i+k]+r[3*j+k] for k in range(2));available=[];excluded=[]
 for owner,axis,sign in product([i,j],[0,1],[-1,1]):
  other=j if owner==i else i;n=ns[owner] if axis==0 else g.rot(ns[owner]);Ro=r[3*owner+2];Rp=r[3*other+2]
  remainder=dR*Ro+g.norm1(dd)*Ro*Ro/2+aa*(Ro+Rp)**2/2+ra*(Ro+Rp)
  corners=[]
  for qx,qy in product([F(-1,2),F(1,2)],repeat=2):
   V=g.add(g.scale(qx,ns[other]),g.scale(qy,g.rot(ns[other])))
   J=[I(0) for _ in range(34)]
   for k in range(2):J[3*i+k]=-sign*n[k];J[3*j+k]=sign*n[k]
   J[3*owner+2]=J[3*owner+2]+sign*g.dot(g.rot(n),dd)-aa*g.dot(V,g.rot(n))
   J[3*other+2]=J[3*other+2]-aa*g.dot(g.rot(V),n)
   J[33]=-F(1,2)-g.dot(V,n)
   value=sign*g.dot(dd,n)-aa/2-aa*g.dot(V,n)
   upper=value.hi+sum(g.iv(x).ab()*rr for x,rr in zip(J,r))+remainder
   corners.append((upper,qx,qy))
  upper,qx,qy=min(corners)
  if upper<0:excluded.append({'feature':[owner,axis,sign],'witness_corner':[qx,qy],'gap_upper':upper})
  else:available.append((owner,axis,sign))
 return available,excluded

def run(seed,box=None):
 g.need(sha(CORE)==CORE_SHA,'Changed exact interval arithmetic dependency')
 g.need(sha(seed)==SEED_SHA,'Input pose-cover hash differs from the requested prefix')
 data=json.loads(seed.read_text());oldlo,oldhi=g.initial_box(data)
 source=seed;lo,hi=oldlo,oldhi
 if box:
  d=json.loads(box.read_text());g.need(d['derived_from']['source_sha256']==sha(seed),'Box source mismatch')
  g.need(d['method']=='rational_capture_box' and d['case']==6 and d['normalized_corners']==[3,4] and d['groups']==data['groups'],'Wrong rational-box geometry')
  lo,hi=[[F(x) for x in side] for side in d['box']]
  g.need(len(lo)==len(hi)==34 and all(a<=b for a,b in zip(lo,hi)),'Invalid rational box')
  g.need(lo[33]>=g.ALO and hi[33]<=g.AHI,'Bad side interval')
  g.need(all(abs(v)<=F(1,4) for side in [lo,hi] for v in side[2:33:3]),'Angle chart exceeded')
  g.need(all(lo[k]==hi[k]==0 for k in [11,14]),'Corner angle not zero')
  g.need(all(a<=b and c<=d for a,b,c,d in zip(lo,oldlo,oldhi,hi)),'Box omits cover');source=box
 checks={}
 for name,(i,j,wanted) in EXPECTED.items():
  available,excluded=feature_checks(lo,hi,i,j)
  g.need(bool(available) and set(available)<=wanted,f'Wrong feature family {name}: {available}')
  checks[name]={'pair':[i,j],'surviving_features':available,'excluded_features':excluded}
 a=I(g.ALO,g.AHI);L=div(g.SIDE,a);centers={};angles={}
 for name,owner in OWN.items():
  centers[name]=tuple(div(I(g.SIDE-hi[3*owner+k],g.SIDE-lo[3*owner+k]),a) for k in range(2))
  angles[name]=I(lo[3*owner+2],hi[3*owner+2])
 signs={}
 for name in 'ABCDE':
  n=normal_interval(angles[name],True);g.need(n[0].lo>0 and n[1].lo>0,'Tilted angle outside first quadrant')
  signs[name]={'cos':n[0],'sin':n[1]}
 for name in 'CE':
  relative=angles[name]-angles['F'];n=normal_interval(relative,True)
  g.need(n[0].lo>0 and n[1].lo>0,'Bridge relative angle outside first quadrant')
  signs[name+'-F']={'cos':n[0],'sin':n[1]}
 fcos=normal_interval(angles['F'],False)[0];g.need(fcos.lo>0,'Bridge cosine not positive')
 virtual={}
 for name,owner,m,ncoef in [('C',0,2,1),('A',9,1,2)]:
  dd=(I(g.SIDE)-m*a-I(lo[3*owner],hi[3*owner]),ncoef*a-I(lo[3*owner+1],hi[3*owner+1]))
  n=normal_interval(angles[name],True);parallel=g.dot(n,dd);normal=g.dot(g.rot(n),dd)
  g.need(parallel.ab()<g.ALO/2,'Virtual corner not strictly inside transverse strip')
  g.need(normal.hi<0,'Virtual corner on wrong side')
  virtual[name]={'parallel_projection':parallel,'normal_projection':normal,'strip_margin':g.ALO/2-parallel.ab(),
    'global_obstacle_corner':[f'S-{m}a',f'{ncoef}a']}
 return {'verdict':'PASS_EXACT_MIXED_SUPPORT_GEOMETRIC_PREMISES','source_sha256':{'input_pose_cover':sha(seed),'envelope':sha(source),'checker':sha(Path(__file__)),'interval_arithmetic':sha(CORE)},
  'closed_envelope_contains_source_cover':True,'pair_checks':checks,'unit_owner_map':OWN,'unit_transform':'(x,y)=((S-X)/a,(S-Y)/a); L=S/a; canonical axes unchanged modulo pi',
  'unit_centers':centers,'angle_offsets':angles,'container':L,'angle_sign_checks':signs,'bridge_cosine':fcos,'virtual_corner_checks':virtual,
  'derived_supports':{
   'Acorner':'e_A dot (A-(1,1)) >= 1/2',
   'Dcorner':'m_D dot (D-(L-1,1)) >= 1/2',
   'Avirtual':'-m_A dot (A-(1,L-2)) >= 1/2',
   'Cvirtual':'-m_C dot (C-(2,L-1)) >= 1/2',
   'Bwall':'y_B >= (cos(theta_B)+sin(theta_B))/2',
   'Ewall':'L-x_E >= (cos(theta_E)+sin(theta_E))/2',
   'Fwall':'L-y_F >= (cos(phi)+abs(sin(phi)))/2',
   'CF':'e_C dot (F-C) >= (1+cos(theta_C-phi)+sin(theta_C-phi))/2',
   'EF':'m_E dot (F-E) >= (1+cos(theta_E-phi)+sin(theta_E-phi))/2'},
  'scope':'Exact necessary separator-family and angle-sign checks, plus closed-envelope containment and virtual-corner strip/sign checks. Assumes an actual legal packing in the named hash-bound prefix cover, its two stated normalized corners, and the two upstream virtual-obstacle theorems. Does not replay initial case exclusions, pose-cover completeness, or virtual-obstacle proofs. The mean-angle support consequence is the analytic corrected mean-axis lemma.'}

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--seed',type=Path,required=True);p.add_argument('--box',type=Path);p.add_argument('--expected-seed-sha256',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 SEED_SHA=args.expected_seed_sha256
 result=run(args.seed,args.box);args.output.write_text(json.dumps(enc(result),indent=2)+'\n');print(result['verdict'])
 print('Features excluded:',sum(len(d['excluded_features']) for d in result['pair_checks'].values()))
 print('Minimum exclusion margin:',float(min(-x['gap_upper'] for d in result['pair_checks'].values() for x in d['excluded_features'])))
