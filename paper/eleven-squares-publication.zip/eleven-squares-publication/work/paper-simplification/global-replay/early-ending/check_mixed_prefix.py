"""Research checker for direct support-cycle optimality on a coarse envelope.

The geometric input is conditional: a complete envelope, the specified corner
and virtual supports, and the relevant separator families. All interval/sign
checks in this file use exact rational arithmetic; no optimization is used.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import argparse,json,hashlib,time,importlib.util,contextlib,io
if not __debug__:
 raise RuntimeError('This exact checker requires assertions; do not run with python -O.')
from prefix_angle_helpers import (g,I,div,hull,sub,vadd,vscale,nderiv_vector,
    interval_angle_normal,arc_project,angle_sin,encode,load)

COM=Path(__file__).resolve().parents[4]
ALGEBRA=COM/'work/global-simplification/structural/support_algebra.py'
spec=importlib.util.spec_from_file_location('cycles',ALGEBRA)
algebra=importlib.util.module_from_spec(spec)
saved_argv=sys.argv
try:
 sys.argv=[str(ALGEBRA),'--output',str(Path(__file__).with_name('support-algebra-replay.json'))]
 with contextlib.redirect_stdout(io.StringIO()):spec.loader.exec_module(algebra)
finally:sys.argv=saved_argv

EDGES=[('AB','B','A',1),('AC','A','C',0),('BD','B','D',0),('DE','D','E',0),('CD','D','C',1)]
STAGES=[('AB',set('A'),'A','B'),('DE',set('E'),'E','D'),('BD',set('AB'),'B','D'),('CD',set('ABDE'),'D','C')]

def peval(p,x):
 y=I(0)
 for v in reversed(p):y=y*x+v
 return y
def rat_eval(f,x):return div(peval(f.p,x),peval(f.q,x))
def root_mix():
 p=algebra.P;a=F(36,100);b=F(37,100)
 def ev(t):return sum(q*t**i for i,q in enumerate(p))
 assert ev(a)<0<ev(b)
 assert peval([i*x for i,x in enumerate(p)][1:],I(a,b)).lo>0
 for _ in range(90):
  m=(a+b)/2
  if ev(m)<0:a=m
  else:b=m
 u=I(a,b);d1=rat_eval(algebra.f1.diff(),u);d2=rat_eval(algebra.f2.diff(),u)
 rho=div(-d2,d1-d2)
 rho=I(g.down(rho.lo,10**15),g.up(rho.hi,10**15))
 assert 0<rho.lo<rho.hi<1
 convex={}
 for name,fn in [('F1',algebra.f1),('F2',algebra.f2)]:
  dd=fn.diff().diff();bs=algebra.bernstein(dd.p,F(17,50),F(19,50))
  ds=algebra.bernstein(dd.q,F(17,50),F(19,50))
  assert (min(bs)>0 and min(ds)>0) or (max(bs)<0 and max(ds)<0)
  convex[name]={'second_derivative_numerator_bernstein':bs,'second_derivative_denominator_bernstein':ds}
 return u,rho,convex

def run(seed,splits):
 assert type(splits) is int and splits>0
 boxes,angles,L,data=load(seed);u,rho,convex=root_mix();alo,ahi=angles['C'].lo,angles['C'].hi
 # The scalar convexity interval is in the true half-angle parameter.
 at=lambda t:2*g.atan_small((t-g.BASE_T)/(1+t*g.BASE_T))
 assert at(F(17,50)).hi<alo<ahi<at(F(19,50)).lo
 allphi=hull(angles['A'],angles['B'])
 for name in 'CDE':allphi=hull(allphi,angles[name])
 # Extended chart, with the monotonicity/sign hypotheses made explicit.
 # theta0 in (.69,.73) and offsets in (-.25,.25) put all tilted
 # angles in (.44,.98), and bridge relative angles in (.19,1.23).
 # All are strictly in the first quadrant. Half-differences along
 # every cluster path lie in (-.25,.25), where sin is increasing.
 assert allphi.lo>F(-1,4) and allphi.hi<F(1,4) and angles['F'].ab()<F(1,4)
 base=2*g.atan_small(g.BASE_T)
 assert F(69,100)<base.lo<base.hi<F(73,100)
 for interval in [allphi,angles['C']-angles['F'],angles['E']-angles['F']]:
  for endpoint in [interval.lo,interval.hi]:
   nn=g.normal(endpoint,True)
   assert nn[0].lo>0 and nn[1].lo>0
 max_half_difference=(allphi.hi-allphi.lo)/2
 assert max_half_difference<F(1,4) and 1-max_half_difference**2/2>0
 results=[]
 for k in range(splits):
  anchor=I(alo+(ahi-alo)*k/splits,alo+(ahi-alo)*(k+1)/splits)
  cc,ss=interval_angle_normal(anchor);den=1+div(cc*cc*cc,ss)+div(ss,cc)
  mix2=div(1-rho,den);mix1=div(rho,cc+ss)
  W={'Acorner':mix2*div(ss*ss,cc),'Avirtual':mix2*div(cc*cc,ss),'Bwall':mix2*div(cc,ss),'Ewall':mix2,'Fwall':mix2*div(ss,cc),
     'CF':mix2*div(ss*ss,cc),'EF':mix2*ss,'AB':mix2*div(cc*cc,ss),'AC':mix2*div(ss*ss,cc),'BD':mix2*cc,'DE':mix2*cc,
     'Dcorner':mix1,'Cvirtual':mix1,'CD':mix1}
  capacity={};etas={}
  for title,p,q,axis in EDGES:
   mean=I((angles[p].lo+angles[q].lo)/2,(angles[p].hi+angles[q].hi)/2)
   rel=I((angles[q].lo-angles[p].hi)/2,(angles[q].hi-angles[p].lo)/2)
   tangential=arc_project(mean,sub(boxes[q],boxes[p]),1-axis).ab()
   eta=1-rel.ab()**2/2-tangential
   assert eta>0
   capacity[title]=W[title].lo*eta/2;etas[title]=eta
  stages={}
  for edge,nodes,child,parent in STAGES:
   parentangle=anchor if parent=='C' else angles[parent]
   moving=hull(angles[child],parentangle)
   V=(I(0),I(0))
   if 'A' in nodes:
    V=vadd(V,vscale(W['Acorner'],nderiv_vector(sub(boxes['A'],(I(1),I(1))),0)))
    V=vadd(V,vscale(W['Avirtual'],sub(boxes['A'],(I(1),L-2))))
   if 'D' in nodes:V=vadd(V,vscale(-W['Dcorner'],sub(boxes['D'],(L-1,I(1)))))
   if 'B' in nodes:V=vadd(V,(-W['Bwall']*F(1,2),W['Bwall']*F(1,2)))
   if 'E' in nodes:
    V=vadd(V,(-W['Ewall']*F(1,2),W['Ewall']*F(1,2)))
    V=vadd(V,vscale(W['EF'],vadd(vscale(F(-1),sub(boxes['F'],boxes['E'])),(I(F(-1,2)),I(F(1,2))))))
   cross=[]
   for title,p,q,axis in EDGES:
    inp,inq=p in nodes,q in nodes
    if inp and inq:V=vadd(V,vscale(W[title],nderiv_vector(sub(boxes[q],boxes[p]),axis)))
    elif inp or inq:
     outside=q if inp else p
     outangle=anchor if outside=='C' else angles[outside]
     mean=I((moving.lo+outangle.lo)/2,(moving.hi+outangle.hi)/2)
     rel=I((outangle.lo-moving.hi)/2,(outangle.hi-moving.lo)/2)
     if inq:rel=-rel
     dd=sub(boxes[q],boxes[p]);deriv=arc_project(mean,dd,1-axis)
     if axis:deriv=-deriv
     sr=angle_sin(rel);skew=int(inq)-int(inp)
     cross.append(W[title]*(deriv+skew*sr)*F(1,2))
   total=arc_project(moving,V,0)+sum(cross,I(0))
   stages[edge]={'cluster':sorted(nodes),'moving_angle':moving,'derivative':total,'capacity':capacity[edge],'margin':capacity[edge]-total.ab()}
  # Bridge angle phi can be replaced by0 in the weighted functional.
  ec,es=interval_angle_normal(angles['E'])
  AA=W['Fwall']+W['CF']*(cc+ss)+W['EF']*(ec+es)
  vv=W['CF']*(cc-ss)+W['EF']*(ec-es)
  Bmin=min((W['Fwall']-vv).lo,(W['Fwall']+vv).lo)
  phi=angles['F'].ab();tanhalf=phi/2/(1-(phi/2)**2/2)
  bridge=Bmin-AA.hi*tanhalf
  results.append({'anchor':anchor,'stages':stages,'bridge_margin':bridge,'eta_bounds':etas})
 worst={edge:min(x['stages'][edge]['margin'] for x in results) for edge,_,_,_ in STAGES}
 out={'verdict':'PASS_MIXED_GLOBAL_ALIGNMENT' if min(worst.values())>=0 and min(x['bridge_margin'] for x in results)>=0 else 'MIXED_ALIGNMENT_NOT_ESTABLISHED',
      'seed_sha256':hashlib.sha256(seed.read_bytes()).hexdigest(),'seed_name':seed.name,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'root_interval':u,'mixture_weight_interval':rho,'convexity_interval_half_angle':['17/50','19/50'],'convexity_checks':convex,'anchor_splits':splits,
      'boxes':boxes,'angle_offsets':angles,'container':L,'minimum_cluster_margins':worst,'minimum_bridge_margin':min(x['bridge_margin'] for x in results),'checks':results,
      'scope':'Conditional analytic direct-optimality implication from this envelope and the named support/separator premises. Upstream completeness and geometric premise discharge are not established by this checker.'}
 return out

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--seed',type=Path,required=True);p.add_argument('--splits',type=int,default=16);p.add_argument('--output',type=Path,required=True);a=p.parse_args();start=time.time()
 out=run(a.seed,a.splits);a.output.write_text(json.dumps(encode(out),indent=2)+'\n')
 print(out['verdict']);print('rho',[float(out['mixture_weight_interval'].lo),float(out['mixture_weight_interval'].hi)])
 print('clusters',{k:float(v) for k,v in out['minimum_cluster_margins'].items()});print('bridge',float(out['minimum_bridge_margin']),'seconds',round(time.time()-start,1))
 if out['verdict']!='PASS_MIXED_GLOBAL_ALIGNMENT':sys.exit(1)
