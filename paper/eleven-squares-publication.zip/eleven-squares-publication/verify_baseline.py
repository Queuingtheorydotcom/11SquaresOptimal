#!/usr/bin/env python3
"""Portable selected proof runner: quick components or a fresh full replay."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,time,uuid

ROOT=Path(__file__).resolve().parent
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,d):
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.writing');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(p)
def verify_inputs():
    p=ROOT/'manifest.json';m=read(p)
    need(m['schema']=='eleven-squares-full-selected-replay-v1','Unknown packet manifest')
    for name,item in m['files'].items():
        q=ROOT/name;need(q.is_file() and not q.is_symlink(),'Missing/symbolic input '+name)
        need(q.stat().st_size==item['bytes'] and sha(q)==item['sha256'],'Changed immutable input '+name)
    archive=ROOT/'work/shared-final/n11-global-proof'
    copies=[ROOT/'work/paper-simplification/global-replay'/p/'selected_source'
            for p in ('root-corner','exclusions')]
    for q in ROOT.rglob('*'):
        need(not q.is_symlink(),'Symbolic path in packet: '+str(q.relative_to(ROOT)))
        if not q.is_file():continue
        name=str(q.relative_to(ROOT))
        if name in m['files'] or q==p:continue
        # Additional archive data could alter a dynamic lookup. Additional
        # Python/native import files could shadow a reviewed module. The only
        # generated source modules are byte-identical copies made by two
        # unchanged replay wrappers; all other runtime outputs are data/logs.
        need(not q.is_relative_to(archive),'Unlisted archived input '+name)
        if q.suffix.lower() in {'.py','.pyc','.pyo','.so','.pyd','.dll','.dylib','.pth'}:
            origin=next((archive/q.relative_to(folder) for folder in copies
                         if q.is_relative_to(folder)),None)
            need(origin is not None and str(origin.relative_to(ROOT)) in m['files']
                 and origin.is_file() and q.read_bytes()==origin.read_bytes(),
                 'Unlisted or changed executable input '+name)
    return sha(p),m

def interrupted_ownership_cleanup(step):
    # These receipts were created only inside this packet's selected_source.
    # Source archive and completed steps are never touched.
    case=step['id'].removeprefix('ownership-')
    names={'0':'journal-case-0-N96','1':'regions-case-1-from-initial-N96',
           '2':'regions-case-2-N384','4':'arc-case-4-from-initial-N96'}
    if case not in names:return
    folder=ROOT/'work/paper-simplification/global-replay/exclusions/selected_source/exploration'
    stems=[names[case]]+(['regions-case-2-from-initial-N96'] if case=='2' else [])
    for stem in stems:
        for p in folder.glob(stem+'.json.verified-*.json'):
            need(p.is_file() and not p.is_symlink(),'Unexpected generated receipt')
            p.unlink()

def main():
    need(__debug__,'Run without Python -O')
    ap=argparse.ArgumentParser(description=__doc__)
    mode=ap.add_mutually_exclusive_group();mode.add_argument('--check-inputs',action='store_true');mode.add_argument('--quick',action='store_true');mode.add_argument('--full',action='store_true')
    ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--resume',action='store_true')
    a=ap.parse_args();need(1<=a.jobs<=4,'jobs must be between 1 and 4')
    digest,manifest=verify_inputs();print('PASS: all immutable packet inputs match',flush=True)
    if not a.quick and not a.full:return
    need(not a.resume or a.full,'--resume applies to full mode')
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONOPTIMIZE':'0'}
    env.pop('PYTHONPATH',None)
    if a.quick:
        subprocess.run([sys.executable,'-B','run_all.py','--optional','--jobs',str(a.jobs)],cwd=ROOT/'quick',env=env,check=True)
        print('QUICK COMPONENT CHECKS COMPLETE. Full global ancestry was not replayed in this mode.',flush=True);return
    plan=read(ROOT/'full-run-plan.json');steps=plan['commands'];ledger_path=ROOT/'verification/ledger.json'
    need(len(steps)==manifest['full_step_count'] and len({x['id'] for x in steps})==len(steps),'Invalid step inventory')
    if ledger_path.exists():
        need(a.resume,'A full run already exists. Use --full --resume, or a fresh extraction.')
        ledger=read(ledger_path);need(ledger['manifest_sha256']==digest,'Cannot resume changed packet')
        need(ledger['plan_sha256']==sha(ROOT/'full-run-plan.json'),'Cannot resume changed plan')
    else:
        need(not a.resume,'No prior run to resume')
        # Freshness is a runtime condition, not a property inferred from a PASS
        # string. Refuse prepopulated completion artifacts before starting.
        for s in steps:need(not (ROOT/s['completion_artifact']).exists(),'Pre-existing completion artifact: '+s['completion_artifact'])
        ledger={'schema':'fresh-selected-proof-run-v1','run_id':str(uuid.uuid4()),
                'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'manifest_sha256':digest,'plan_sha256':sha(ROOT/'full-run-plan.json'),
                'jobs':a.jobs,'steps':{},'status':'RUNNING'}
        save(ledger_path,ledger)
    for number,step in enumerate(steps,1):
        key=step['id'];receipt=ROOT/step['completion_artifact'];old=ledger['steps'].get(key)
        if old and old.get('status')=='PASS':
            need(receipt.is_file() and sha(receipt)==old['receipt_sha256'],'Completed result changed: '+key)
            if step['category']!='assembler':
                print('REUSE THIS RUN',key,flush=True);continue
            # Recheck all dependent states, manifests and subsidiary receipts
            # on every resume, rather than trusting an unchanged top-level
            # assembler report after one of its inputs may have changed.
        if old:
            interrupted_ownership_cleanup(step)
            receipt.unlink(missing_ok=True)
        command=[x.replace('{python}',sys.executable).replace('{jobs}',str(a.jobs)) for x in step['argv']]
        log=ROOT/'verification/logs'/(key+'.log');log.parent.mkdir(parents=True,exist_ok=True)
        ledger['steps'][key]={'status':'RUNNING','command':command,'receipt':step['completion_artifact'],
                              'log':str(log.relative_to(ROOT)),'run_id':ledger['run_id']}
        save(ledger_path,ledger);print(f'CHECK {number}/{len(steps)} {key}',flush=True);start=time.monotonic()
        try:
            with log.open('w') as f:
                child=subprocess.run(command,cwd=ROOT/step['cwd'],env=env,stdout=f,stderr=subprocess.STDOUT)
            need(child.returncode==0,'Checker failed: '+key)
            d=read(receipt);need(d.get(step['completion_field'])==step['completion_value'],'Unexpected completion: '+key)
            ledger['steps'][key].update(status='PASS',receipt_sha256=sha(receipt),seconds=time.monotonic()-start)
            save(ledger_path,ledger);print('PASS',key,round(time.monotonic()-start,2),'seconds',flush=True)
        except BaseException as exc:
            ledger['steps'][key].update(status='INTERRUPTED_OR_FAILED',error=str(exc),seconds=time.monotonic()-start)
            ledger['status']='INCOMPLETE';save(ledger_path,ledger)
            print('Stopped at',key,'; inspect',log.relative_to(ROOT),flush=True)
            raise
    verify_inputs()
    need(set(ledger['steps'])=={s['id'] for s in steps} and all(x['status']=='PASS' for x in ledger['steps'].values()),'Incomplete execution ledger')
    ancestry=read(ROOT/'work/paper-simplification/global-replay/ancestry/acceptance-status.json')
    need(ancestry['graph_closed'] and ancestry['verdict']=='PASS_FRESH_CASE6_ANCESTRY_CLOSED','Case6 semantic ancestry remains open')
    ownership=read(ROOT/'work/paper-simplification/global-replay/ancestry/fresh/ownership-result.json')
    # Its exact reviewed schema/verdict has already been required by the last
    # command. Preserve the complete result instead of guessing another flag.
    ledger['status']='PASS_FRESH_COMPLETE_SELECTED_PROOF';save(ledger_path,ledger)
    report={'verdict':'PASS_FRESH_COMPLETE_SELECTED_PROOF','run_id':ledger['run_id'],
            'manifest_sha256':digest,'ledger_sha256':sha(ledger_path),'executed_or_resumed_steps':len(steps),
            'case6_graph_nodes':ancestry['total_nodes'],'case6_graph_closed':True,
            'ownership_acceptance':ownership,'attaining_construction':'Fresh foundation execution in this ledger.',
            'trust_model':'Ordinary displayed geometric/analytic lemmas plus fresh exact-rational Python computations; no Lean proof-kernel replay.',
            'scope':'All selected computational ownership exclusions, surviving-case ancestry, and five-round direct-support endpoint were executed in this manifest-bound run. Mathematical lemmas remain explicit displayed proofs.'}
    save(ROOT/'verification/overall-result.json',report)
    print(report['verdict'],flush=True)

if __name__=='__main__':main()
